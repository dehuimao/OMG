var gamedata = {
	imageFiles : [ 
		"library/alienbomb.png", 
		"library/starfightersheet.gif", 
		"library/characterset.gif", 
		"library/entities.png", 
		"library/explosion.png", 
		"library/gamebackdrop.gif", 
		"library/earth.gif", 
		"library/gameover.png", 
		"library/hiscore.png", 
		"library/level.png", 
		"library/levelcomplete.png", 
		"library/levelflag.png", 
		"library/marker.png", 
		"library/monstersheet.png", 
		"library/numbers.png", 
		"library/playericon.png", 
		"library/playermissile.png", 
		"library/playersheet.png", 
		"library/playpause.png", 
		"library/pregame.gif", 
		"library/spark.png", 
		"library/star.png", 
		"library/staricon.png", 
		"library/titlescreen.png", 
		"library/volumecontrols.png",
		"library/splash.png"
	],
	audioFiles : [ 
	]
};