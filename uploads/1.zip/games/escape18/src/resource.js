//diretory

var res_enemy01 = "res/enemy_01.png";
var res_enemy02 = "res/enemy_02.png";
var res_enemy03 = "res/enemy_03.png";
var res_enemy04 = "res/enemy_04.png";
var res_player = "res/player.png";
var res_ad2 ="res/ad02.png";
var res_agin_btn = "res/agin_btn.png";
var res_background = "res/background.jpg";
var res_contents = "res/contents.png";
var res_dialog_bg = "res/dialog_bg.png";
var res_k_head = "res/k_head.png";
var res_k_head2 = "res/k_head2.png";
var res_more_btn = "res/more_btn.png";
var res_share_btn = "res/share_btn.png";
var res_start = "res/start.png";
var res_share = "res/share.png";
var res_tiptitle = "res/tiptitle.png";
var sound_click = "res/click.mp3";
var sound_death = "res/death.mp3";
var sound_restart = "res/restart.mp3";
var sound_start = "res/start.mp3";

var res_f_head = "res/f_head.png";
var res_f_head1 = "res/f_head_1.png";
var res_f_head2 = "res/f_head2.png";
var res_k_head1 = "res/k_head_1.png";
var res_f_head3 = "res/f_head_3.jpg";
var res_k_head3 = "res/k_head_3.jpg";
var g_resources = [
    {src:res_enemy01},
    {src: res_enemy02},
    {src: res_enemy03},
    {src: res_enemy04},
    {src:res_player},
    {src:res_ad2},
    {src:res_agin_btn},
    {src:res_background},
    {src:res_contents},
    {src:res_dialog_bg},
    {src:res_k_head},
    {src:res_k_head2},
    {src:res_more_btn},
    {src:res_share_btn},
    {src:res_start},
    {src:res_share},
    {src:res_tiptitle},
    {src:res_f_head},
    {src:res_f_head2},
    {src:res_f_head1},
    {src:res_k_head1},{src:res_k_head3},{src:res_f_head3}


];