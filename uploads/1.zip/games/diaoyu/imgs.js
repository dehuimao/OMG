{"frames": {

"fish.png":
{
	"frame": {"x":145,"y":2,"w":64,"h":58},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":64,"h":58},
	"sourceSize": {"w":64,"h":58}
},
"fishman.png":
{
	"frame": {"x":2,"y":2,"w":267,"h":141},
	"rotated": true,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":267,"h":141},
	"sourceSize": {"w":267,"h":141}
},
"hook.png":
{
	"frame": {"x":211,"y":2,"w":20,"h":20},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":20,"h":20},
	"sourceSize": {"w":20,"h":20}
},
"rope.png":
{
	"frame": {"x":233,"y":2,"w":2,"h":900},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":2,"h":900},
	"sourceSize": {"w":2,"h":900}
}},
"meta": {
	"app": "http://www.codeandweb.com/texturepacker ",
	"version": "1.0",
	"image": "imgs.png",
	"format": "RGBA8888",
	"size": {"w":256,"h":1024},
	"scale": "1",
	"smartupdate": "$TexturePacker:SmartUpdate:90aaf2d0af9f3d0ddfd73ba0c614b030:7d51f5b72e924482a65ad12d0a52bff4:b2a319a0fd4740ebbfe4a4452a196eb5$"
}
}
