/*var s_XiaoxinStatus1 = "res/xiaoxin_1.png";
var s_XiaoxinStatus3 = "res/xiaoxin_4.png";
var s_XiaoxinStatus4 = "res/xiaoxin_3.png";
var m_hit = "res/hit100.mp3";
var s_XiaoxinHong = "res/hongyin.png";
var s_XiaoxinTurn = "res/xiaoxin_2.png";*/
var m_hit = "res/hit100.mp3";
var p_Xiaoxin ="res/xiaoxin.plist";
var s_Xiaoxin ="res/xiaoxin.png";
var s_ui1 ="res/anjian.png";
var s_ui2 ="res/anxia.png";


var g_resources = [
    //image
    s_Xiaoxin,
    s_ui1,
    s_ui2,
    //plist
    p_Xiaoxin,

    //fnt

    //tmx

    //bgm
    m_hit
    //effect
];