var gamedata = {
	imageFiles : [ 
		"library/titlescreen.png", 
		"library/splash.png",
		"library/playersheet.gif",
		"library/playpause.png",
		"library/platforms.gif",
		"library/jumppad.gif",
		"library/aliensheet.gif",
		"library/gameback1.gif",
		"library/gameback2.gif",
		"library/gameback3.gif",
		"library/fireswirl.gif"
	],
	audioFiles : [ 
	]
};
